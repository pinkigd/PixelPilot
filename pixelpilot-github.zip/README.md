# PixelPilot — Next.js landing page

Next.js 16 (App Router) · React 19 · TypeScript · Tailwind CSS v4 — coded from the Figma file
"PixelPilot – AI SaaS Landing Page" (desktop frame 1920, plus tablet / phone layouts).

```bash
npm install
npm run dev      # http://localhost:3000
npm run build && npm start
```

## Structure

```
app/
  layout.tsx        metadata, head script that sets --k before first paint
  page.tsx          the 14 sections in order
  globals.css       Tailwind import, @theme tokens, self-hosted fonts, tablet/phone/midsize variants
  mockups.css       pixel-exact product mockups (windows, phones, cards) — `@layer components`
components/
  sections/         Hero, Logos, Problem, Solution, CommandCenter, DesignSystem, Flow,
                    Responsive, Variations, Proof, Pricing, Faq, Philosophy, CtaFooter
  mockups/          the Figma product UI illustrations as JSX (one component per mockup)
  ui/               Section, Eyebrow, H2, Button, ZoomDiv, FitBox, Seg, Scaler
public/fonts/       Geist, Inter, Geist Mono, Fraunces, DM Serif Display (latin woff2, SIL OFL)
```

## How the layout works

* **≥1680px** – 1680px content rail with 120px gutters (the Figma 1920 frame), absolute-positioned mockups.
* **1100–1679px** (`midsize:`) – the whole rail is zoomed to fit; `--k` = viewport / 1680 (head script + `<Scaler />`).
* **≤1099px** (`tablet:`) – sections stack; fixed-size mockups shrink with `zoom` to the width they get
  (`<ZoomDiv>` / `<FitBox>`).
* **≤767px** (`phone:`) – tighter spacing; the responsive demo shows the mobile frame only.

Custom variants live in `globals.css`: `midsize`, `tablet`, `phone`.

## Interactions (React state)

Mobile menu (`Nav`), segmented control in the generated-UI mockup (`Seg`), monthly/yearly pricing (`Pricing`),
"Use this" variation picker (`Variations`). The FAQ is a native exclusive accordion (`<details name="faq">`).

## Things to check before shipping

* **Photos** are real crops from the Figma design (see the `assets/` folder: `cc-*`, `fl-*`, `rs-*`, `vr-*`, `ds-*`, `hero-*`, `pr-*`). They are 1× crops, so they look soft on retina screens —
  re-export them from Figma at 2× and overwrite the files with the same name.
* **FAQ answers 2–6** are placeholder copy (Figma only defines answer 1).
* **Monthly prices** (Pro $30, Team $24) are derived from the yearly prices in Figma at 20% off.
* Some footer links point to `#`.
* Pages: `/` (landing), `/product`, `/features`, `/pricing`.

## Product page (`/product`)

`app/product/page.tsx` — Figma node `64:130` (7 sections: hero, capabilities, edit by conversation, every breakpoint,
what's included, enterprise ready, CTA + footer). Sections live in `components/sections/product/`; the chat panel
(`components/mockups/ChatPanel.tsx`) is interactive. TODOs: swap the gradient photo placeholders for exported images and
replace the hand-drawn shield art (`components/mockups/ShieldArt.tsx`) with the exported vectors.

## Features page (`/features`)

`app/features/page.tsx` — Figma node `70:790` (1920 × 8369: hero, six alternating feature rows — generate, conversation,
design system, responsive, variations, handoff — "everything else" grid, compact CTA + footer). Sections live in
`components/sections/features/`. Landing mockups are re-used at smaller scale through `components/ui/Z.tsx` (CSS `zoom` +
the `.zb` rules at the end of `app/mockups.css`); the chat panel is interactive (`<ChatPanel wide />`). The hero pills and
footer links deep-link to the section ids (`#generate`, `#conversation`, `#design-system`, `#responsive`, `#variations`,
`#handoff`). TODO: swap the gradient photo/avatar placeholders and hand-drawn vectors for exported Figma assets.

## Cross-page links

Nav and footer link `/`, `/product`, `/features` and `/pricing`. For the static artifact build, `EXPORT=1 npx next build` writes
`.next-export/`; the pages are renamed to `home.html` / `product.html` / `features.html` / `pricing.html` and hrefs rewritten accordingly.

## Pricing page (`/pricing`)

`app/pricing/page.tsx` — Figma node `67:258` (1920 × 6781: plans + billing toggle, compare table, "in every plan",
results, billing FAQ, CTA + footer). Shared with other pages: `components/sections/pricing/PlanCards.tsx` (plan cards and the
Monthly/Yearly toggle, also used by the landing page), `product/Included.tsx` (comparison table, now parametrised),
`Proof.tsx` → `StatGrid`, and `Faq.tsx` (now takes `qas` / `title`). The footer's Pricing link and the nav's Pricing
link both point to `/pricing`. TODO: Figma only defines the answer to FAQ question 1 — answers 2–6 are placeholder copy.

## Hero window

`components/mockups/HeroWindow.tsx` is matched to the supplied 1452-wide hero design. The mountain photo and the avatar strip are
cropped from that image (`assets/hero-photo.jpg`, `assets/hero-avatars.png`) — replace them with the Figma exports if you have them.
The same window is used on the landing and Product heroes.

## Hero tour animation

`<HeroWindow tour />` (landing hero only) plays a 14.5s looping product tour: a 3D camera pans/zooms inside the window while a cursor
selects the Image layer, runs "Change the mood" and sends the prompt ("more minimal and modern"). The engine is
`components/mockups/HeroTour.tsx` (one rAF loop; keyframes in `CAM` / `CUR`, click times as constants) and the states are plain
CSS in `app/mockups.css` (`.win[data-sel|data-mood|data-min]`). It pauses off-screen / in background tabs and is skipped for
`prefers-reduced-motion`. Remove the `tour` prop to get the static window back.

## AI Command Center animation

`components/mockups/WorkspaceTour.tsx` animates the "Design with conversation" dashboard (`<Workspace tour />`): a cursor clicks
**More editorial** and **Increase contrast**, the AI panel "thinks" and answers, a glowing sweep runs across the canvas flipping the six
screens column by column (serif headlines / high contrast), layers ping, "Updated" tags pop back in, and a 3D camera follows. It loops
every 16s. Timings live in the constants at the top of the file (`CAM`, `CUR`, `CLICK1/2`, `SWEEP1/2`, `RESET`); the visual states are the
`.ws[data-tour]` rules at the end of `app/mockups.css`. Same safety rules as the hero tour: no JS / reduced-motion / off-screen = static design.

## Landing section animations (`components/fx/`, `app/fx.css`)

Five landing sections animate when scrolled into view (`runFx` in `components/fx/engine.ts` marks the section with `data-fx` / `data-in`; the
per-section scripts are in `components/fx/SectionFx.tsx`, the visual states in `app/fx.css`):

- **The new way** — prompt types itself, chips pop in, button is pressed, the wireframe is replaced by the generated dashboard (wipe, count-up, chart draw). 13s loop.
- **Your design system** — the Primary token cycles colour (coral → blue → green), connectors light up, the generated Horizon site updates live (`--ds-p` / `--ds-p2`). 12s loop.
- **From idea to interface** — the four screens build up in order, the prototype link draws, then a playhead cycles through the steps.
- **Responsive by default** — "Make this mobile-first." is typed and sent; desktop → tablet → mobile update one after another. 11s loop.
- **Pricing** — cards, feature rows and checks stagger in, prices count up (and roll when Monthly/Yearly changes), Pro card floats, CTA shines.

Headings use `data-rv` (rise + fade). Without JS, with `prefers-reduced-motion`, or off-screen, the static design is shown unchanged.

### "Your design system" visuals
The Horizon site card (also reused on the Features page) uses real photo crops from the supplied design (`assets/ds-hero.jpg`, `ds-card-1..3.jpg`, `ds-avatar.png`), SVG search / menu / diamond icons, an SVG dashed selection frame, and the variable **Fraunces with the optical-size axis** (`public/fonts/fraunces-opsz-latin-normal.woff2`, family "Fraunces Opsz") so the serif headline matches the design's width exactly.

### "AI Command Center" visuals
The Workspace mockup (`components/mockups/Workspace.tsx`) uses real photo crops from the supplied design: `assets/cc-home.jpg`, `cc-alps.jpg` (the "Swiss Alps" card, with the baked-in caption removed so the live text sits on top), `cc-dest.jpg`, `cc-thumb.png`, `cc-portrait.png`, the AI-panel avatar `cc-me.png` and the top-bar collaborator strip `cc-avatars.png`. Photos sit inside `.photo` boxes (`<Pic>` helper), so the tour's colour-grade filters ("More editorial", "Increase contrast") still apply to them. Sidebar / toolbar icons and the chevrons are inline SVG. Crops are 1× – on retina screens they look slightly soft; swap in higher-resolution files with the same names.

### "From idea to interface" visuals
The four phones (`components/mockups/FlowPhones.tsx`) use real photo crops from the supplied design (`assets/fl-hero.jpg`, `fl-t1..3.jpg`, `fl-av.png`; the thumbnails have the tab-bar tint removed so it isn't applied twice). The wireframe is drawn with SVG: 1px dashes (6 on / 4 off), solid diagonals clipped to the rounded frame. Tab-bar icons, the "On tap → Destination" arrow, the hotspot ring (20% accent fill) and the prototype link (a path traced from the design, with arrowheads at both ends) are inline SVG. The link draws itself in the loop animation; the tail arrowhead appears with it. Eyebrow dots in this and the Command Center section use `#932f28` (`dotClassName` prop on `Eyebrow`).

## Responsive by default visuals

The three "Horizon" device mockups (Desktop 1440 / Tablet 768 / Mobile 390) live in `components/mockups/Devices.tsx` and are shared by the landing
"Responsive by default" stage and the Product page "Every breakpoint" section (which just zooms them down).

- Photos are real crops in `assets/rs-d-*` (desktop), `rs-t-*` (tablet) and `rs-m-*` (mobile) rendered through the `Pic` helper inside the clipped `.photo` boxes
  — swap a file to change a picture; the device frames, text and icons stay live markup.
- Search, burger, arrow, chevron and tab-bar icons are inline SVGs using `currentColor`.
- The red dashed divider is `.rsp__vdiv` in `app/mockups.css`; the animation (typing, 1440 → 768 → 390 highlight, "3 breakpoints updated" counter) is `ResponsiveFx`
  in `components/fx/SectionFx.tsx` and still hooks the same class names (`.rm--d/--t/--m`, `[data-n]`, `[data-prompt]`).
- Desktop hero and card regions hidden behind the tablet/mobile frames in the reference were synthesised; crops are 1× so they are soft on retina screens.

## "Don't settle on the first idea" visuals

The three direction cards are `components/mockups/VariationMinimal|Editorial|Expressive.tsx` (styles `.vc--min/--ed/--ex` in `app/mockups.css`), shared by the landing
section and the Features "Variations" block (`.zb` zoom wrapper).

- Photos are real crops: `assets/vr-min-*` (mono hero + 4 thumbs), `vr-ed-band` (editorial landscape strip), `vr-ex-rock` (dune pill, pre-rotated, the CSS applies `rotate(5deg)`)
  and `vr-ex-c1..4` (colour cards); rendered through the shared `components/mockups/Pic.tsx` inside the clipped `.photo` boxes.
- The expressive card's blobs are plain circles/ellipses with the exact reference colours (#bfe0ff, #ffb1d8, #2f5bff, #ff7a45, #ffc2de).
- The editorial card content sits 3px right/down inside its border (`.vc--ed > * { translate: 3px 3px }`) to match the design.
- "Selected" pill now has `z-10` so it stays above the card border; "Use this" buttons still move the selection.
- Crops are 1× so they are soft on retina screens.


## Testimonial (Maya Chen) visuals

`components/sections/Proof.tsx` — the quote card at the end of the Results section.

- The portrait is a real crop (`assets/pr-maya.jpg`, 154×154) shown in a 158px circle with a 2px lilac-grey ring (`border-[#4b4b66]`); on tablet/phone it scales to 84px with a 1px ring.
- Quote text is Inter 44px / 63px line-height / regular weight, tracking −1.1px (matches the design's glyph height and line widths); the card is 1600px wide (`-mx-px`) on desktop.
- The crop is 1× so it is soft on retina screens.
