import type { CSSProperties, ReactNode } from "react";
import { cn } from "@/lib/cn";

type Props = {
  /** position inside the surrounding `.fit` stage (px, at 1680 canvas scale) */
  x: number;
  y: number;
  /** zoom factor applied to the mockup */
  s: number;
  /** natural (landing) size of the mockup; the placed box ends up w*s × h*s */
  w: number;
  h?: number;
  className?: string;
  style?: CSSProperties;
  children: ReactNode;
};

/**
 * Places one of the landing mockups at a smaller scale. The Features page re-uses the exact same mockup markup as the
 * landing (wireframe, generated UI, token panel, devices…) but at the sizes the Features frames use (0.78, 0.62, 0.7 …).
 */
export function Z({ x, y, s, w, h, className, style, children }: Props) {
  return (
    <div
      className={cn("absolute", className)}
      style={{ left: x, top: y, width: w * s, height: h ? h * s : undefined, ...style }}
    >
      <div className="zb" style={{ zoom: s, width: w, height: h }}>
        {children}
      </div>
    </div>
  );
}
