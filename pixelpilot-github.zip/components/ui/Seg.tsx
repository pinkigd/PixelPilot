"use client";

import { useState } from "react";
import { cn } from "@/lib/cn";

const OPTIONS = ["Wireframe", "Layout", "Polished"] as const;

/** Segmented control inside the generated-UI mockup (Wireframe / Layout / Polished). */
export function Seg() {
  const [active, setActive] = useState<(typeof OPTIONS)[number]>("Polished");
  return (
    <div className="seg">
      {OPTIONS.map((o) => (
        <button key={o} type="button" className={cn(active === o && "is-on")} onClick={() => setActive(o)}>
          {o}
        </button>
      ))}
    </div>
  );
}
