import type { ComponentPropsWithoutRef, ReactNode } from "react";
import { cn } from "@/lib/cn";

/** Section headline (Geist 56/1.06). Wrap the second line in <Dim> for the muted tone. */
export function H2({ children, className, ...rest }: { children: ReactNode; className?: string } & Omit<ComponentPropsWithoutRef<"h2">, "children" | "className">) {
  return (
    <h2
      className={cn(
        "font-display text-[56px] leading-[1.06] font-medium tracking-[-1.68px] text-white",
        "tablet:text-[length:clamp(34px,7.4vw,56px)] tablet:tracking-[-0.03em]",
        className,
      )}
      {...rest}
    >
      {children}
    </h2>
  );
}

export function Dim({ children, className }: { children: ReactNode; className?: string }) {
  return <span className={cn("block text-muted", className)}>{children}</span>;
}
