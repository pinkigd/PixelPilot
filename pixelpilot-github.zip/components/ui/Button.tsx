import type { ComponentPropsWithoutRef } from "react";
import { cn } from "@/lib/cn";

const base =
  "inline-flex items-center rounded-full whitespace-nowrap transition duration-200 hover:-translate-y-px";

const variants = {
  primary: "gap-3 bg-white px-9 py-5 text-[19px] font-semibold text-ink",
  ghost: "gap-4 border border-white/30 bg-panel py-5 pr-10 pl-[34px] text-[19px] font-medium text-white hover:border-white/55",
} as const;

type Props = ComponentPropsWithoutRef<"a"> & { variant?: keyof typeof variants };

export function Button({ variant = "primary", className, ...rest }: Props) {
  // leading-none goes last: tailwind-merge would otherwise drop it whenever a caller passes a text-size class
  return <a className={cn(base, variants[variant], className, "leading-none")} {...rest} />;
}
