import type { ComponentPropsWithoutRef, ReactNode } from "react";
import { cn } from "@/lib/cn";

type Props = {
  id?: string;
  as?: "section" | "header";
  /** classes for the outer, full-width band */
  className?: string;
  /** classes for the 1680px rail (heights, padding overrides) */
  inner?: string;
  /** rendered in the full-bleed band, outside the (clipped, zoomed) rail — e.g. a hairline that spans the gutters */
  bleed?: ReactNode;
  children: ReactNode;
} & Omit<ComponentPropsWithoutRef<"section">, "className" | "children">;

/**
 * A page band: full-bleed dark gutter with a 1680px content rail (120px gutters at 1920).
 * 1100–1679px → the whole rail is zoomed to fit (`midsize:` + --k). ≤1099px → it stacks.
 */
export function Section({ as: Tag = "section", className, inner, bleed, children, ...rest }: Props) {
  return (
    <Tag
      className={cn(
        "relative bg-gutter after:pointer-events-none after:absolute after:inset-x-0 after:top-0 after:z-[2] after:h-px after:bg-white/7 after:content-['']",
        className,
      )}
      {...rest}
    >
      <div
        className={cn(
          "relative mx-auto max-w-[1680px] overflow-hidden border-x border-white/8 bg-bg px-10 pt-[140px] pb-[160px]",
          "midsize:[zoom:var(--k,1)]",
          "tablet:h-auto tablet:border-x-0 tablet:px-(--pad) tablet:pt-[88px] tablet:pb-24 phone:pt-[72px] phone:pb-20",
          inner,
        )}
      >
        {children}
      </div>
      {bleed}
    </Tag>
  );
}
