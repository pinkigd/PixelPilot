"use client";

import { useEffect } from "react";

/**
 * Keeps --k (= viewport / 1680) up to date for the 1100–1679px "zoom the whole canvas" tier.
 * The same formula runs in the inline head script (see layout.tsx) so there is no flash before hydration.
 */
export function Scaler() {
  useEffect(() => {
    const root = document.documentElement;
    const update = () => {
      const vw = root.clientWidth;
      root.style.setProperty("--k", (vw >= 1100 && vw < 1680 ? (vw - 2) / 1680 : 1).toFixed(4));
    };
    update();
    window.addEventListener("resize", update);
    window.addEventListener("orientationchange", update);
    document.fonts?.ready.then(update);
    return () => {
      window.removeEventListener("resize", update);
      window.removeEventListener("orientationchange", update);
    };
  }, []);
  return null;
}
