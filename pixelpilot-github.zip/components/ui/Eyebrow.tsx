import type { ComponentPropsWithoutRef, ReactNode } from "react";
import { cn } from "@/lib/cn";

export function Dot({ accent = true, className }: { accent?: boolean; className?: string }) {
  return <i className={cn("inline-block size-[9px] shrink-0 rounded-full", accent ? "bg-[#c4382d]" : "bg-muted", className)} />;
}

/** Small uppercase label with a status dot. */
export function Eyebrow({
  children,
  dot = "accent",
  dotClassName,
  className,
  ...rest
}: { children: ReactNode; dot?: "accent" | "muted" | false; dotClassName?: string; className?: string } & Omit<ComponentPropsWithoutRef<"span">, "children" | "className">) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-3 text-[15px] leading-none font-medium tracking-[0.6px] text-muted tablet:text-[14px]",
        className,
      )}
      {...rest}
    >
      {children}
      {dot && <Dot accent={dot === "accent"} className={dotClassName} />}
    </span>
  );
}
