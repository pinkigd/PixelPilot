"use client";

import { useEffect, useRef, type ComponentPropsWithoutRef } from "react";
import { cn } from "@/lib/cn";

type Props = ComponentPropsWithoutRef<"div"> & {
  /** natural (designed) width of the mockup in px */
  zoomW: number;
  /** when the mockup sits in a grid with N equal columns, pass N */
  zoomCols?: number;
};

/**
 * Fixed-size mockups keep their designed pixel size on desktop. Below 1100px the
 * layout stacks and this component shrinks them with CSS `zoom` (--z) to the width
 * their container gives them, so nothing overflows on tablet / phone.
 */
export function ZoomDiv({ zoomW, zoomCols = 1, className, children, ...rest }: Props) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const small = window.matchMedia("(max-width: 1099px)");
    let raf = 0;

    const apply = () => {
      const parent = el.parentElement;
      if (!parent || !small.matches) {
        el.style.removeProperty("--z");
        return;
      }
      const cs = getComputedStyle(parent);
      let avail = parent.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight);
      if (zoomCols > 1) avail = (avail - (zoomCols - 1) * (parseFloat(cs.columnGap) || 0)) / zoomCols;
      const z = Math.min(1, avail / zoomW);
      el.style.setProperty("--z", (Number.isFinite(z) && z > 0 ? z : 1).toFixed(4));
    };
    const schedule = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(apply);
    };

    apply();
    window.addEventListener("resize", schedule);
    window.addEventListener("orientationchange", schedule);
    document.fonts?.ready.then(apply);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", schedule);
      window.removeEventListener("orientationchange", schedule);
    };
  }, [zoomW, zoomCols]);

  return (
    <div ref={ref} className={cn("tablet:[zoom:var(--z,1)]", className)} {...rest}>
      {children}
    </div>
  );
}
