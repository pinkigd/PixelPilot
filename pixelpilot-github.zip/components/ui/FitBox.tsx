"use client";

import { useEffect, useRef, type CSSProperties, type ReactNode } from "react";
import { cn } from "@/lib/cn";

type Props = {
  /** position + natural size on the 1680px canvas */
  /** a number (px) or any CSS length expression, e.g. a calc() that reacts to the viewport */
  x: number | string;
  y: number;
  w: number;
  h: number;
  className?: string;
  children: ReactNode;
};

/**
 * Absolutely-positioned mockup on desktop (`.fitw`, see mockups.css). On tablet it
 * becomes a normal block and its `.fit` child is zoomed (--s) to the available width.
 */
export function FitBox({ x, y, w, h, className, children }: Props) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const small = window.matchMedia("(max-width: 1099px)");
    let raf = 0;

    const apply = () => {
      if (!small.matches) {
        el.style.removeProperty("--s");
        return;
      }
      const s = Math.min(1, el.clientWidth / w);
      el.style.setProperty("--s", (Number.isFinite(s) && s > 0 ? s : 1).toFixed(4));
    };
    const schedule = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(apply);
    };

    apply();
    window.addEventListener("resize", schedule);
    window.addEventListener("orientationchange", schedule);
    document.fonts?.ready.then(apply);
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", schedule);
      window.removeEventListener("orientationchange", schedule);
    };
  }, [w]);

  const style = { "--x": typeof x === "number" ? `${x}px` : x, "--y": `${y}px`, "--w": `${w}px`, "--h": `${h}px` } as CSSProperties;
  return (
    <div ref={ref} className={cn("fitw", className)} style={style}>
      {children}
    </div>
  );
}
