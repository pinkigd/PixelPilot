import { Section } from "@/components/ui/Section";
import { cn } from "@/lib/cn";

const COLUMNS = {
  product: [
    "Generate",
    "Edit by chat",
    "Design system",
    "Responsive",
    "|",
    "Pricing",
    "Integrations",
    "Figma plugin",
    "Changelog",
    "Security",
  ],
  madeFor: ["Product designers", "Design teams", "Founders who design"],
  company: ["About", "Customers", "Partners", "Careers"],
  resources: [
    "Documentation",
    "Templates",
    "Community",
    "Help Center  ↗",
    "Trust Center  ↗",
    "Loom alternative",
    "LLMs",
  ],
  connect: ["Contact us", "LinkedIn", "X", "YouTube"],
};

/** footer links that point at real routes / sections; everything else stays a "#" placeholder */
const HREFS: Record<string, string> = {
  Generate: "/features#generate",
  "Edit by chat": "/features#conversation",
  "Design system": "/features#design-system",
  Responsive: "/features#responsive",
  Pricing: "/pricing",
  Security: "/product#enterprise",
  "Trust Center  ↗": "/product#enterprise",
};

function FooterCol({ title, items, href }: { title: string; items: string[]; href?: string }) {
  return (
    <nav>
      <h4 className="mb-3.5 text-[17px] leading-[normal] font-semibold text-white">
        {href ? <a href={href}>{title}</a> : title}
      </h4>
      <ul>
        {items.map((it, i) =>
          it === "|" ? (
            <li key={i} className="mt-[18px] mb-8 h-px w-[70px] bg-white/14" />
          ) : (
            <li key={it} className="mb-3.5 text-[16px] leading-[normal]">
              <a
                href={HREFS[it] ?? "#"}
                className="whitespace-pre text-white/62 transition-colors hover:text-white"
              >
                {it}
              </a>
            </li>
          ),
        )}
      </ul>
    </nav>
  );
}

export function CtaFooter({
  title = ["Stop staring at the canvas.", "Start designing."],
  accentGuide = false,
  compact = false,
  legalBar = "default",
}: {
  title?: [string, string];
  /** the Features page uses a shorter variant (1329px): card at y=70, no hatch / guide, footer 140px under the card */
  compact?: boolean;
  /** accent-coloured dashed guide: `true` = the Product page's (1px / 45%), `"col"` = the Pricing page's 1.5px / 55% column divider */
  accentGuide?: boolean | "col";
  /** the Pricing frame sets the legal bar 28px further right and 2px lower than the Product frame */
  legalBar?: "default" | "pricing";
}) {
  return (
    <Section
      id="cta"
      inner={cn(
        "px-10 pb-0 tablet:pt-[88px] tablet:pb-14",
        compact ? "h-[1329px] pt-[70px]" : "h-[1479px] pt-[140px]",
      )}
      bleed={
        // full-bleed hairline above the legal bar; sits at 1245px of the canvas, so it follows the zoom (--k)
        <i
          aria-hidden="true"
          className={cn(
            "absolute inset-x-0 z-[1] h-px bg-white/8 tablet:hidden",
            compact ? "top-[calc(1175px*var(--k,1))]" : "top-[calc(1245px*var(--k,1))]",
          )}
        />
      }
    >
      {!compact && (
        <>
          <div
            aria-hidden="true"
            className="hatch pointer-events-none absolute inset-x-0 top-0 h-[58px]"
          />
          <i
            aria-hidden="true"
            className={cn(
              "pointer-events-none absolute top-[200px] h-[1035px] tablet:hidden",
              accentGuide === "col"
                ? "vdash-col left-[809px] w-[1.5px]"
                : cn("left-[810px] w-px", accentGuide ? "vdash-accent" : "vdash"),
            )}
          />
        </>
      )}

      <div className="relative z-[1] flex h-[486px] flex-col items-center rounded-[34px] border border-accent/40 bg-[#171514] pt-[77px] text-center tablet:h-auto tablet:rounded-[28px] tablet:px-6 tablet:pt-14 tablet:pb-12">
        <p className="font-mono text-[17px] leading-[normal] tracking-[3.06px] text-white/85 tablet:text-[13px] tablet:tracking-[0.18em]">
          YOUR NEXT DESIGN STARTS HERE
        </p>
        <h2 className="mt-[29px] font-display text-[66px] leading-[1.06] font-medium tracking-[-1.98px] tablet:text-[length:clamp(34px,8.4vw,66px)] tablet:tracking-[-0.03em]">
          <span className="block">{title[0]}</span>
          <span className="block text-muted">{title[1]}</span>
        </h2>
        <a
          href="#"
          className="mt-[34px] inline-flex items-center gap-3 rounded-full bg-white px-12 py-6 text-[26px] leading-none whitespace-nowrap text-ink transition-transform hover:-translate-y-0.5 tablet:mt-7 tablet:px-[30px] tablet:py-5 tablet:text-[19px]"
        >
          <span className="font-display font-medium tracking-[-0.52px]">
            Start designing — it’s free
          </span>
          <b className="font-semibold">→</b>
        </a>
        <p className="mt-[46px] text-[21px] whitespace-pre text-white/85 tablet:mt-7 tablet:text-[16px] tablet:leading-[1.6] tablet:whitespace-normal">
          14 days free{"  "}·{"  "}No credit card{"  "}·{"  "}Works inside Figma
        </p>
      </div>

      <footer className="relative z-[1] mt-[140px] grid grid-cols-[470px_320px_320px_340px_1fr] pl-2.5 tablet:mt-16 tablet:grid-cols-2 tablet:gap-x-6 tablet:gap-y-10 tablet:pl-0">
        <div className="flex flex-col items-start gap-[26px] tablet:col-span-full">
          <span className="grid size-11 place-items-center rounded-full bg-white text-[20px] font-semibold text-[#111]">
            ✦
          </span>
          <span className="flex items-center gap-3 text-[17px] font-medium text-[#4ade9e]">
            <i className="size-[9px] rounded-full bg-[#4ade9e] shadow-[0_0_8px_rgba(74,222,158,.6)]" />
            All systems operational
          </span>
          <a href="#" className="text-[16px] whitespace-pre text-white/55">
            Report a vulnerability{"  "}↗
          </a>
        </div>
        <FooterCol title="Product" items={COLUMNS.product} href="/product" />
        <div className="flex flex-col gap-[46px]">
          <FooterCol title="Made for" items={COLUMNS.madeFor} />
          <FooterCol title="Company" items={COLUMNS.company} />
        </div>
        <FooterCol title="Resources" items={COLUMNS.resources} />
        <FooterCol title="Connect" items={COLUMNS.connect} />
      </footer>

      <div
        className={cn(
          "absolute left-[50px] z-[1] flex items-center justify-between gap-6 tablet:static tablet:mt-12 tablet:flex-col tablet:items-start tablet:gap-5 tablet:border-t tablet:border-white/8 tablet:pt-7",
          // the Features frame puts the compliance badges 28px further right (x 1428 → 1785 on the 1920 canvas)
          compact
            ? "top-[1209px] right-[14px]"
            : legalBar === "pricing"
              ? "top-[1275px] right-[14px]"
              : "top-[1273px] right-[42px]",
        )}
      >
        <div className="flex flex-wrap items-center gap-[26px] text-[16px] leading-[normal] tablet:gap-x-5 tablet:gap-y-2.5 tablet:text-[15px]">
          <b className="font-semibold">©2026 PixelPilot Ltd</b>
          {["Terms", "Privacy", "Cookies", "Subprocessors", "Sitemap"].map(
            (l) => (
              <a key={l} href="#" className="text-white/62 hover:text-white">
                {l}
              </a>
            ),
          )}
        </div>
        <div className={cn("flex gap-3.5 tablet:flex-wrap", legalBar === "pricing" && "translate-y-[2.5px] tablet:translate-y-0")}>
          {["SOC2", "ISO 27001", "GDPR"].map((c) => (
            <span
              key={c}
              className="inline-flex items-center gap-2.5 rounded-full border border-white/12 bg-card px-[18px] py-2.5 text-[15px] leading-[normal] font-medium whitespace-nowrap text-white/90"
            >
              <i className="text-[14px] font-normal not-italic text-white/80">
                ⛉
              </i>
              {c}
            </span>
          ))}
        </div>
      </div>
    </Section>
  );
}
