"use client";

import { useState } from "react";
import { PricingFx } from "@/components/fx/SectionFx";
import { Eyebrow } from "@/components/ui/Eyebrow";
import { H2 } from "@/components/ui/H2";
import { Section } from "@/components/ui/Section";
import { BillingToggle, PlanCards, type Period } from "@/components/sections/pricing/PlanCards";

export function Pricing() {
  const [period, setPeriod] = useState<Period>("yearly");

  return (
    <Section id="pricing" inner="pb-[160px]">
      <div className="flex flex-col items-center text-center">
        <Eyebrow data-rv>PRICING</Eyebrow>
        <H2 className="mt-[19px] whitespace-nowrap tablet:whitespace-normal" data-rv>
          Simple pricing. <em className="not-italic text-muted">Serious</em> output.
        </H2>
        <div className="mt-3" data-rv>
          <BillingToggle period={period} onChange={setPeriod} />
        </div>
      </div>

      <PlanCards period={period} guides className="mt-[38px] tablet:mt-9" />

      <p data-rv className="mt-[37px] text-center text-[19px] text-white/70 tablet:mt-7 tablet:text-[16px]">All plans work inside Figma. Cancel anytime.</p>
      <PricingFx />
    </Section>
  );
}
