import { HeroWindow } from "@/components/mockups/HeroWindow";
import { Button } from "@/components/ui/Button";
import { Section } from "@/components/ui/Section";
import { Nav } from "./Nav";

export function Hero() {
  return (
    <Section as="header" id="top" inner="h-[1081px] p-0 tablet:px-(--pad) tablet:pt-0 tablet:pb-[72px] phone:pt-0">
      <Nav />

      <div className="absolute inset-x-0 top-[176px] flex flex-col items-center px-6 text-center tablet:relative tablet:top-auto tablet:px-0 tablet:pt-14">
        <h1 className="font-display text-[80px] leading-[1.06] font-medium tracking-[-2.4px] tablet:text-[length:clamp(42px,11.5vw,80px)]">
          Design faster.
          <span className="block text-muted">Think beyond pixels.</span>
        </h1>
        <p className="mt-[26px] text-[24px] text-white/78 tablet:text-[length:clamp(17px,3.6vw,24px)]">
          Your AI copilot inside Figma — from prompt to polished UI.
        </p>
        <div className="mt-10 flex gap-5 tablet:flex-wrap tablet:justify-center tablet:gap-3">
          <Button href="#cta" className="tablet:px-7 tablet:py-[18px] tablet:text-[17px]">
            Start designing <span className="text-[20px]">→</span>
          </Button>
          <Button href="#demo" variant="ghost" className="tablet:px-7 tablet:py-[18px] tablet:text-[17px]">
            <span className="text-[18px] font-normal">▶</span> Watch demo
          </Button>
        </div>
      </div>

      {/* Product window (Figma "Hero / Product window") */}
      <HeroWindow tour />
    </Section>
  );
}
