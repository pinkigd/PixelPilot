import { Dim, H2 } from "@/components/ui/H2";
import { Eyebrow } from "@/components/ui/Eyebrow";
import { Section } from "@/components/ui/Section";
import { ZoomDiv } from "@/components/ui/ZoomDiv";
import { cn } from "@/lib/cn";

const CARDS = [
  {
    n: "01",
    title: "Start from zero",
    text: "Blank canvas. Endless decisions.",
    ill: <div className="ill-blank" />,
  },
  {
    n: "02",
    title: "Repeat the same work",
    text: "Resize. Duplicate. Align. Repeat.",
    ill: [0, 1, 2, 3, 4].map((i) => <i key={i} />),
    illClass: "ill-phones",
  },
  {
    n: "03",
    title: "Lose the system",
    text: "Small inconsistencies become big problems.",
    ill: [0, 1, 2].map((i) => (
      <span key={i} className="ill-btn">
        Button
      </span>
    )),
  },
];

export function Problem() {
  return (
    <Section id="product">
      <div className="flex items-end justify-between gap-10 tablet:flex-col tablet:items-start tablet:gap-5">
        <div className="flex flex-col gap-7">
          <Eyebrow>THE OLD WAY</Eyebrow>
          <H2>
            Great ideas shouldn’t get stuck
            <Dim>in the blank canvas.</Dim>
          </H2>
        </div>
        <p className="max-w-[420px] pb-3 text-[20px] leading-[1.6] text-white/80 tablet:max-w-none tablet:pb-0 tablet:text-[18px]">
          Designers spend most of their day on setup, repetition and fixing small inconsistencies — not on ideas.
        </p>
      </div>

      <div className="relative mt-14 flex gap-[26px] tablet:mt-10 tablet:flex-col tablet:gap-4">
        {CARDS.map((c) => (
          <article
            key={c.n}
            className="min-w-0 flex-1 overflow-hidden rounded-[26px] border border-white/10 bg-card px-[42px] pt-14 pb-11 tablet:px-6 tablet:pt-8 tablet:pb-7"
          >
            <ZoomDiv zoomW={450} className={cn("card__ill", c.illClass)}>
              {c.ill}
            </ZoomDiv>
            <div className="flex flex-col gap-2 pt-9 tablet:pt-6">
              <p className="text-[18px] text-white/80">{c.n}</p>
              <h3 className="font-display text-[31px] font-medium tracking-[-0.62px] tablet:text-[26px]">{c.title}</h3>
              <p className="text-[20px] text-white/80 tablet:text-[18px]">{c.text}</p>
            </div>
          </article>
        ))}
      </div>
    </Section>
  );
}
