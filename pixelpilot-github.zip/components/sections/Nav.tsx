"use client";

import { useState } from "react";
import { cn } from "@/lib/cn";

const LINKS = [
  { href: "/product", label: "Product", key: "product" },
  { href: "/features", label: "Features", key: "features" },
  { href: "/pricing", label: "Pricing", key: "pricing" },
] as const;

/** `active` marks the current page's link (100% white, the rest dimmed — as in the Figma "Nav" component). */
export function Nav({ active }: { active?: (typeof LINKS)[number]["key"] }) {
  const [open, setOpen] = useState(false);
  const close = () => setOpen(false);

  return (
    <nav className="absolute top-6 right-10 left-10 z-[5] flex h-[60px] items-center justify-between tablet:relative tablet:inset-x-auto tablet:top-auto tablet:-mx-(--pad) tablet:h-[76px] tablet:px-(--pad)">
      <a className="flex items-center gap-3.5 font-display text-[26px] font-medium tracking-[-0.52px]" href="/" onClick={close}>
        <i className="size-3.5 rounded-full bg-[#c4382d]" />
        PixelPilot
      </a>

      <div
        className={cn(
          "flex gap-14 text-[17px] font-medium",
          active ? "text-white/55" : "text-white/85",
          open
            ? "tablet:absolute tablet:inset-x-(--pad) tablet:top-[76px] tablet:z-10 tablet:flex-col tablet:gap-0 tablet:rounded-[20px] tablet:border tablet:border-white/12 tablet:bg-card tablet:px-[22px] tablet:py-2 tablet:text-[18px]"
            : "tablet:hidden",
        )}
      >
        {LINKS.map((l, i) => (
          <a
            key={l.href}
            href={l.href}
            onClick={close}
            aria-current={l.key === active ? "page" : undefined}
            className={cn(
              "transition-colors hover:text-white",
              l.key === active && "text-white",
              "tablet:border-b tablet:border-white/8 tablet:py-4",
              i === LINKS.length - 1 && "tablet:border-b-0",
            )}
          >
            {l.label}
          </a>
        ))}
      </div>

      <a
        href="#cta"
        onClick={close}
        className={cn(
          "rounded-full bg-white px-[26px] py-3.5 text-[16px] leading-none font-semibold text-ink",
          open ? "tablet:absolute tablet:inset-x-(--pad) tablet:top-[266px] tablet:z-10 tablet:block tablet:p-[18px] tablet:text-center" : "tablet:hidden",
        )}
      >
        Start designing
      </a>

      <button
        type="button"
        aria-label="Menu"
        aria-expanded={open}
        onClick={() => setOpen((o) => !o)}
        className="hidden size-11 place-content-center gap-1.5 rounded-full border border-white/20 tablet:grid"
      >
        <i className={cn("block h-[1.5px] w-[18px] bg-white transition-transform", open && "translate-y-[3.75px] rotate-45")} />
        <i className={cn("block h-[1.5px] w-[18px] bg-white transition-transform", open && "-translate-y-[3.75px] -rotate-45")} />
      </button>
    </nav>
  );
}
