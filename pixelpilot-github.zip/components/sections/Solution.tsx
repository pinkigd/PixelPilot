import { GenWindow } from "@/components/mockups/GenWindow";
import { WireWindow } from "@/components/mockups/WireWindow";
import { Button } from "@/components/ui/Button";
import { Eyebrow } from "@/components/ui/Eyebrow";
import { Dim, H2 } from "@/components/ui/H2";
import { SolutionFx } from "@/components/fx/SectionFx";
import { Section } from "@/components/ui/Section";
import { ZoomDiv } from "@/components/ui/ZoomDiv";

const CHIPS = ["Revenue", "Invoices", "Cash flow", "Team activity"];

export function Solution() {
  return (
    <Section inner="h-[1140px] p-0 tablet:px-(--pad)">
      <div className="absolute top-[268px] left-10 w-[695px] tablet:static tablet:w-full">
        <Eyebrow data-rv>THE NEW WAY</Eyebrow>
        <H2 className="mt-[30px]" data-rv>
          Give your idea
          <Dim>a starting point.</Dim>
        </H2>
        <p data-rv className="mt-[34px] text-[21px] whitespace-nowrap text-white/85 tablet:text-[19px] tablet:whitespace-normal">
          Describe what you need. PixelPilot builds the first version in seconds.
        </p>

        <div data-rv className="mt-[52px] flex w-[695px] flex-col gap-5 rounded-[26px] border border-white/14 bg-card p-7 tablet:mt-8 tablet:w-full tablet:p-5">
          <p className="text-[19px] text-white/70">Prompt</p>
          <div className="flex flex-col gap-5 rounded-[14px] border border-white/10 bg-panel px-4 py-5">
            <p data-prompt className="text-[21px] text-white tablet:text-[18px]">
              <span data-ty-a>Create a fintech dashboard for small business owners.</span>
              <i className="fx-caret" />
              <span data-ty-b className="fx-ghost" />
            </p>
            <div className="flex flex-wrap gap-2.5">
              {CHIPS.map((c) => (
                <span key={c} className="chip fx-pop">
                  {c}
                </span>
              ))}
            </div>
          </div>
          <div data-gen className="flex justify-end">
            <Button href="#cta" className="px-10 py-[22px] text-[21px] tablet:px-7 tablet:py-[18px] tablet:text-[17px]">
              <span>Generate interface</span>
              <span className="text-[22px]">→</span>
            </Button>
          </div>
        </div>

        <p data-meta className="mt-[30px] flex items-center gap-4 text-[18px] whitespace-pre text-white/70 tablet:flex-wrap tablet:text-[15px]">
          ✓{"   "}Uses your design system <i className="text-[14px] not-italic text-white/50">•</i> Ready in <span data-time>4.2s</span>
        </p>
      </div>

      {/* wireframe → generated UI (same coordinates as the 1920 canvas) */}
      <ZoomDiv
        zoomW={1038}
        className="pointer-events-none absolute inset-0 *:pointer-events-auto tablet:pointer-events-auto tablet:relative tablet:inset-auto tablet:mt-12 tablet:h-[873px] tablet:w-[1038px]"
      >
        <WireWindow />
        <GenWindow />
      </ZoomDiv>
      <i className="vdiv" style={{ left: 746 }} />
      <SolutionFx />
    </Section>
  );
}
