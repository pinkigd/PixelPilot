"use client";

import { useState, type CSSProperties } from "react";
import { VariationEditorial } from "@/components/mockups/VariationEditorial";
import { VariationExpressive } from "@/components/mockups/VariationExpressive";
import { VariationMinimal } from "@/components/mockups/VariationMinimal";
import { Section } from "@/components/ui/Section";
import { cn } from "@/lib/cn";

const OPTIONS = [
  { label: "01   MINIMAL", lx: 40, bx: 425.6, tag: { left: 443, top: 407 }, Card: VariationMinimal },
  { label: "02   EDITORIAL", lx: 582, bx: 970, tag: { left: 985, top: 389 }, Card: VariationEditorial },
  { label: "03   EXPRESSIVE", lx: 1124, bx: 1509.6, tag: { left: 1527, top: 407 }, Card: VariationExpressive },
];

export function Variations() {
  const [picked, setPicked] = useState(1);
  const tag = OPTIONS[picked].tag;

  return (
    <Section inner="h-[1240px] p-0 tablet:px-(--pad)">
      <div className="absolute inset-x-0 top-[140px] flex flex-col items-center text-center tablet:static">
        <span className="inline-flex items-center gap-3.5 rounded-full border border-white/20 bg-card py-3.5 pr-[25px] pl-[22px] whitespace-nowrap tablet:px-5 tablet:py-3">
          <i className="text-[22px] not-italic text-accent-soft">✦</i>
          <span className="text-[18px] font-medium text-white tablet:text-[16px]">Explore 3 visual directions</span>
        </span>
        <h2 className="mt-4 font-display text-[56px] leading-[1.06] font-medium tracking-[-1.55px] whitespace-nowrap text-white tablet:text-[length:clamp(34px,7.4vw,56px)] tablet:tracking-[-0.03em] tablet:whitespace-normal">
          Don’t settle on the <em className="not-italic text-muted">first</em> idea.
        </h2>
        <p className="mt-7 text-[23px] tracking-[0.05px] text-white/85 tablet:text-[18px] tablet:tracking-normal">Generate distinct directions from one prompt, then pick the one that fits.</p>
      </div>

      <span
        className="absolute z-10 rounded-full bg-white px-4 py-2 text-[14px] leading-none font-semibold text-ink tablet:hidden"
        style={{ left: tag.left, top: tag.top }}
      >
        Selected
      </span>
      <i className="vdash absolute top-[320px] left-[568px] h-[620px] w-px tablet:hidden" />
      <i className="vdash absolute top-[320px] left-[1098px] h-[620px] w-px tablet:hidden" />

      {OPTIONS.map(({ label, lx, bx, Card }, i) => (
        <div
          key={label}
          className="contents tablet:mx-auto tablet:mt-10 tablet:grid tablet:max-w-[515px] tablet:grid-cols-[1fr_auto] tablet:items-center tablet:gap-y-4"
          style={{ "--lx": `${lx}px`, "--bx": `${bx}px` } as CSSProperties}
        >
          <Card picked={picked === i} />
          <span className="absolute top-[1046px] left-(--lx) font-mono text-[17px] font-medium tracking-[1.02px] whitespace-pre text-white/80 tablet:static tablet:text-[15px]">
            {label}
          </span>
          <button
            type="button"
            onClick={() => setPicked(i)}
            className={cn(
              "absolute top-[1032px] left-(--bx) cursor-pointer rounded-full border-[1.2px] px-8 py-[15px] text-[16px] leading-none font-medium whitespace-nowrap transition-colors",
              "tablet:static tablet:px-[26px] tablet:py-[13px] tablet:text-[15px]",
              picked === i ? "border-white bg-white font-semibold text-ink" : "border-white/35 bg-transparent text-white hover:bg-white/10",
            )}
          >
            Use this
          </button>
        </div>
      ))}
    </Section>
  );
}
