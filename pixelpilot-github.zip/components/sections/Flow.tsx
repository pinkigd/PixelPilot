import { FlowPhones } from "@/components/mockups/FlowPhones";
import { FlowFx } from "@/components/fx/SectionFx";
import { Eyebrow } from "@/components/ui/Eyebrow";
import { Dim, H2 } from "@/components/ui/H2";
import { Section } from "@/components/ui/Section";
import { cn } from "@/lib/cn";

const STEPS = [
  { n: "01   WIREFRAME", t: "Sketch the idea" },
  { n: "02   STRUCTURE", t: "Shape the layout" },
  { n: "03   UI", t: "Apply your system" },
  { n: "04   PROTOTYPE", t: "Make it interactive", last: true },
];

export function Flow() {
  return (
    <Section inner="h-[1352px] pb-0 tablet:pb-24">
      <div className="flex flex-col items-center text-center">
        <Eyebrow data-rv dotClassName="bg-[#932f28]">FROM IDEA TO INTERFACE</Eyebrow>
        <H2 className="mt-[21px] text-center" data-rv>
          From rough idea
          <Dim>to real interface.</Dim>
        </H2>
        <p data-rv className="mt-[27px] text-[23px] text-white/85 tablet:text-[19px]">Watch one screen grow from a sketch into a working prototype.</p>
      </div>

      <div
        aria-hidden="true"
        className="relative mx-auto mt-[84px] flex w-[1392px] max-w-full justify-between gap-16 tablet:mt-12 tablet:grid tablet:w-full tablet:grid-cols-2 tablet:justify-items-center tablet:gap-x-4 tablet:gap-y-6 phone:gap-x-2.5 phone:gap-y-5"
      >
        <FlowPhones />
      </div>

      <div className="relative mx-auto mt-[52px] flex w-[1392px] max-w-full justify-between gap-16 before:absolute before:inset-x-[150px] before:top-[5px] before:h-px before:bg-white/18 before:content-[''] tablet:mt-12 tablet:grid tablet:w-full tablet:grid-cols-2 tablet:gap-x-4 tablet:gap-y-8 tablet:before:hidden">
        <i className="flowline" />
        {STEPS.map((s) => (
          <div key={s.n} data-step className="relative w-[300px] flex-none text-center tablet:w-auto tablet:text-left">
            <i
              className={cn(
                "relative mx-auto mb-[21px] block size-[11px] rounded-full bg-white/[.63] tablet:mx-0 tablet:mb-3.5",
                s.last && "bg-[#932f28]",
              )}
            />
            <b className="block font-mono text-[16px] font-medium tracking-[0.96px] whitespace-pre text-white/85 tablet:text-[14px]">{s.n}</b>
            <span className="mt-2.5 block text-[19px] text-white/65 tablet:text-[16px]">{s.t}</span>
          </div>
        ))}
      </div>
      <FlowFx />
    </Section>
  );
}
