import { DesignConnectors } from "@/components/mockups/DesignConnectors";
import { HorizonSite } from "@/components/mockups/HorizonSite";
import { Eyebrow } from "@/components/ui/Eyebrow";
import { FitBox } from "@/components/ui/FitBox";
import { Dim, H2 } from "@/components/ui/H2";
import { DesignSystemFx } from "@/components/fx/SectionFx";
import { Section } from "@/components/ui/Section";

const COLORS = [
  { name: "Primary", hex: "#FF7A59", style: { background: "var(--ds-p, #ff7a59)" } },
  { name: "Ink", hex: "#0F172A", style: { background: "#0f172a", border: "1px solid rgba(255,255,255,.2)" } },
  { name: "Sand", hex: "#F4EDE4", style: { background: "#f4ede4" } },
];
const COMPONENTS = [
  { name: "Button", on: true },
  { name: "Input" },
  { name: "Card", on: true },
  { name: "Modal" },
  { name: "Navigation" },
];

export function DesignSystem() {
  return (
    <Section id="design-system" inner="h-[1132px] p-0 tablet:px-(--pad)">
      <Eyebrow data-rv className="absolute top-[140px] left-10 tablet:static">YOUR DESIGN SYSTEM</Eyebrow>
      <H2 data-rv className="absolute top-[174px] left-10 tablet:static tablet:mt-5">
        Your design system.
        <Dim>Not ours.</Dim>
      </H2>
      <p data-rv className="absolute top-[206px] left-[1120px] w-[377px] text-[21px] leading-[1.45] text-white/85 tablet:static tablet:mt-5 tablet:w-auto tablet:text-[18px]">
        PixelPilot works with the components, <br className="tablet:hidden" />
        tokens and patterns you already use.
      </p>

      {/* token panel */}
      <div className="tokens fx-l">
        <div className="tokens__top">
          <span className="tokens__name">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <path d="M12 1.6L22.4 12 12 22.4 1.6 12Z" stroke="#fff" strokeWidth="1.7" strokeLinejoin="round" />
              <path d="M12 7.6L16.4 12 12 16.4 7.6 12Z" fill="#fff" stroke="#fff" strokeWidth="1.2" strokeLinejoin="round" />
            </svg>
            Horizon DS
          </span>
          <span className="tokens__sync">Synced ✓</span>
        </div>
        <hr />
        <p className="tokens__lbl">COLOR</p>
        {COLORS.map((c) => (
          <div key={c.name} className="tok">
            <i className="tok__sw" style={c.style} />
            <b>{c.name}</b>
            <span>{c.hex}</span>
          </div>
        ))}
        <hr />
        <p className="tokens__lbl">TYPE</p>
        <div className="tyk">
          <span className="tyk__aa tyk__aa--serif">Aa</span>
          <b>Display</b>
          <span>— Fraunces</span>
        </div>
        <div className="tyk">
          <span className="tyk__aa">Aa</span>
          <b>Body</b>
          <span>— Inter</span>
        </div>
        <hr />
        <p className="tokens__lbl">COMPONENTS</p>
        <div className="comps">
          {COMPONENTS.map((c) => (
            <span key={c.name} className={c.on ? "comp is-on" : "comp"}>
              {c.name}
            </span>
          ))}
        </div>
      </div>

      {/* generated site built from those tokens */}
      <FitBox x={670} y={312} w={970} h={660} className="fx-r">
        <HorizonSite />
      </FitBox>

      {/* dashed connectors from the token panel to the generated UI */}
      <DesignConnectors />
      <i className="vdiv" style={{ left: 625, height: 860 }} />
      <DesignSystemFx />
    </Section>
  );
}
