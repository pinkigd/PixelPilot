import { Section } from "@/components/ui/Section";

const LOGOS = ["Figma", "Linear", "Notion", "Framer", "Webflow", "Vercel"];

export function Logos() {
  return (
    <Section inner="flex h-[462px] flex-col items-center gap-10 px-10 pt-[140px] pb-0 tablet:h-auto tablet:gap-7 tablet:px-(--pad) tablet:py-[72px]">
      <p className="text-center text-[20px] font-medium text-white/80">Built for designers who think in systems.</p>
      <div className="flex h-[57px] w-full items-center justify-between px-[120px] font-display text-[26px] font-medium tracking-[-0.26px] text-white/60 tablet:h-auto tablet:flex-wrap tablet:justify-center tablet:gap-x-8 tablet:gap-y-3.5 tablet:p-0 tablet:text-[22px]">
        {LOGOS.map((l) => (
          <span key={l}>{l}</span>
        ))}
      </div>
      <div className="h-px w-full bg-white/12" />
      <div className="hatch absolute inset-x-[-1px] bottom-[60px] h-[50px] tablet:hidden" />
    </Section>
  );
}
