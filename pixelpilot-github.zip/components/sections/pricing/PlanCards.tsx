"use client";

import { type CSSProperties, useEffect, useRef, useState } from "react";
import { cn } from "@/lib/cn";

export type Period = "monthly" | "yearly";

type Plan = {
  name: string;
  desc: string;
  /** [yearly, monthly]; monthly is derived from the yearly price in Figma ($24 at 20% off ≈ $30) */
  price: [string, string];
  unit: string;
  cta: string;
  ctaGhost?: boolean;
  badge?: string;
  pro?: boolean;
  features: string[];
};

const PLANS: Plan[] = [
  {
    name: "Starter",
    desc: "For solo designers exploring AI.",
    price: ["$0", "$0"],
    unit: "/ month",
    cta: "Get started",
    ctaGhost: true,
    features: ["50 AI generations / month", "1 design system", "Desktop layouts", "Community support", "Figma plugin"],
  },
  {
    name: "Pro",
    desc: "For designers who ship every week.",
    price: ["$24", "$30"],
    unit: "/ month",
    cta: "Start 14-day trial",
    badge: "Most popular",
    pro: true,
    features: ["Unlimited generations", "Conversation editing", "Responsive breakpoints", "3 visual variations per prompt", "Priority support"],
  },
  {
    name: "Team",
    desc: "For design teams with a shared system.",
    price: ["$19", "$24"],
    unit: "/ seat / month",
    cta: "Talk to us",
    features: ["Everything in Pro", "Unlimited design systems", "Shared prompts & history", "Admin & SSO", "Dedicated onboarding"],
  },
];

/** Monthly / Yearly pill + "Save 20%" badge (Figma "Toggle row"). */
export function BillingToggle({ period, onChange }: { period: Period; onChange: (p: Period) => void }) {
  const [bumps, setBumps] = useState(0);
  return (
    <div className="flex items-center gap-3.5 tablet:flex-wrap tablet:justify-center">
      <div role="group" aria-label="Billing period" className="flex gap-1 rounded-full border border-white/20 bg-panel p-[5px]">
        {(["monthly", "yearly"] as const).map((p) => (
          <button
            key={p}
            type="button"
            aria-pressed={period === p}
            onClick={() => {
              if (p !== period) setBumps((n) => n + 1);
              onChange(p);
            }}
            className={cn(
              "rounded-full py-3 text-[17px] leading-[normal] capitalize transition-colors",
              "max-[480px]:text-[16px]",
              period === p
                ? "bg-white px-11 font-medium text-ink max-[480px]:px-[30px]"
                : "px-10 text-white/85 max-[480px]:px-[26px]",
            )}
          >
            {p}
          </button>
        ))}
      </div>
      <span key={bumps} className={cn("rounded-full bg-accent px-4 py-2 text-[15px] font-semibold text-ink tablet:whitespace-nowrap", bumps > 0 && "fx-bump")}>
        Save 20%
      </span>
    </div>
  );
}

/**
 * The big price number. Rolls from the previous value to the new one when the billing period changes and, on the landing page
 * (inside an `[data-fx]` section), counts up from $0 the first time the section is revealed.
 */
function Price({ value }: { value: string }) {
  const target = parseInt(value.replace(/\D/g, ""), 10) || 0;
  const [n, setN] = useState(target);
  const ref = useRef<HTMLElement>(null);
  const cur = useRef(target);
  const first = useRef(true);

  useEffect(() => {
    const el = ref.current;
    if (!el || window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      cur.current = target;
      setN(target);
      return;
    }
    let raf = 0;
    let mo: MutationObserver | undefined;
    const tween = (from: number, to: number, ms: number) => {
      const t0 = performance.now();
      const step = (now: number) => {
        const p = Math.min(1, (now - t0) / ms);
        const v = Math.round(from + (to - from) * (1 - Math.pow(1 - p, 3)));
        cur.current = v;
        setN(v);
        if (p < 1) raf = requestAnimationFrame(step);
      };
      raf = requestAnimationFrame(step);
    };

    if (first.current) {
      first.current = false;
      const host = el.closest<HTMLElement>("[data-fx]");
      if (host) {
        const go = () => {
          cur.current = 0;
          setN(0);
          tween(0, target, 1300);
        };
        if (host.hasAttribute("data-in")) go();
        else {
          mo = new MutationObserver(() => {
            if (host.hasAttribute("data-in")) {
              mo?.disconnect();
              go();
            }
          });
          mo.observe(host, { attributes: true, attributeFilter: ["data-in"] });
        }
      }
    } else tween(cur.current, target, 600);

    return () => {
      cancelAnimationFrame(raf);
      mo?.disconnect();
    };
  }, [target]);

  return (
    <b ref={ref} className="font-display text-[92px] leading-none font-semibold tracking-[-3.68px] tablet:text-[72px]">
      ${n}
    </b>
  );
}

/** The three plan cards. `guides` draws the dashed column guides of the landing page. */
export function PlanCards({ period, guides = false, className }: { period: Period; guides?: boolean; className?: string }) {
  return (
    <div className={cn("relative grid grid-cols-3 items-stretch gap-7 tablet:mx-auto tablet:max-w-[560px] tablet:grid-cols-1 tablet:gap-5", className)}>
      {guides && ["calc((100% - 56px)/3 + 14px)", "calc((100% - 56px)*2/3 + 42px)"].map((left) => (
        <i key={left} className="vdash pointer-events-none absolute -top-[39px] h-[700px] w-px tablet:hidden" style={{ left } as CSSProperties} />
      ))}

      {PLANS.map((p) => (
        <article
          key={p.name}
          className={cn(
            "fx-card relative z-[1] rounded-[26px] bg-card tablet:px-7 tablet:py-9",
            p.pro && "fx-card--pro",
            p.pro
              ? "border-[3px] border-accent px-[52px] pt-[52px] pb-[58px] shadow-[18px_10px_70px_rgba(255,75,62,.35),-18px_0_70px_rgba(255,75,62,.35)]"
              : "border border-white/16 px-[52px] pt-[58px] pb-[52px]",
          )}
        >
          <div className="flex items-start justify-between">
            <h3 className="font-display text-[40px] leading-[normal] font-medium tracking-[-1.4px] tablet:text-[32px]">{p.name}</h3>
            {p.badge && <span className="fx-badge rounded-full bg-accent px-4 py-2 text-[15px] font-semibold text-ink">{p.badge}</span>}
          </div>
          <p className="mt-3 text-[22px] whitespace-nowrap text-white/85 tablet:text-[18px] tablet:whitespace-normal">{p.desc}</p>
          <p className="mt-[26px] flex items-baseline gap-3.5 whitespace-nowrap">
            <Price value={period === "yearly" ? p.price[0] : p.price[1]} />
            <span className="text-[22px] text-white/75 tablet:text-[18px]">{p.unit}</span>
          </p>
          <a
            href="#cta"
            className={cn(
              "relative mt-[30px] block overflow-hidden rounded-full px-6 py-5 text-center text-[20px] transition-transform hover:-translate-y-px",
              p.pro && "fx-cta",
              p.ctaGhost ? "border-[1.5px] border-[rgba(201,210,255,.5)] bg-transparent font-medium text-white" : "bg-white font-semibold text-ink",
            )}
          >
            {p.cta}
          </a>
          <hr className="mt-[30px] mb-[26px] h-px border-0 bg-white/12" />
          <ul className="flex flex-col gap-[22px]">
            {p.features.map((f) => (
              <li key={f} className="fx-li flex items-center gap-5 text-[20px] text-white/90 tablet:gap-4 tablet:text-[18px]">
                <span
                  aria-hidden="true"
                  className={cn(
                    "fx-ck grid size-7 flex-none place-items-center rounded-full border-[1.8px] text-[14px] font-bold",
                    p.pro ? "border-accent bg-accent text-ink" : "border-white/85 text-white",
                  )}
                >
                  ✓
                </span>
                {f}
              </li>
            ))}
          </ul>
        </article>
      ))}
    </div>
  );
}
