"use client";

import { useState } from "react";
import { Nav } from "@/components/sections/Nav";
import { Eyebrow } from "@/components/ui/Eyebrow";
import { Section } from "@/components/ui/Section";
import { BillingToggle, PlanCards, type Period } from "./PlanCards";

/** Pricing 01 · Plans (Figma 67:259) — headline, billing toggle and the three plan cards. */
export function PricingHero() {
  const [period, setPeriod] = useState<Period>("yearly");

  return (
    <Section
      as="header"
      id="top"
      inner="h-[1497px] pt-[172px] pb-0 tablet:h-auto tablet:pt-0 tablet:pb-20 phone:pt-0"
    >
      <Nav active="pricing" />

      <div className="flex flex-col items-center text-center tablet:pt-14">
        <Eyebrow>PRICING</Eyebrow>
        <h1 className="mt-[29px] font-display text-[72px] leading-[1.06] font-medium tracking-[-2.16px] tablet:mt-6 tablet:text-[length:clamp(40px,10.5vw,72px)] tablet:tracking-[-0.03em]">
          Pick a plan.
          <span className="block text-muted">Change it whenever.</span>
        </h1>
        <p className="mt-[18px] w-[760px] text-[22px] leading-[1.55] text-white/75 tablet:mt-4 tablet:w-full tablet:max-w-[560px] tablet:text-[18px]">
          Per editor, billed monthly or yearly. Every plan runs inside Figma — no separate app, no seats you can’t reassign.
        </p>
        <div className="mt-4 tablet:mt-7">
          <BillingToggle period={period} onChange={setPeriod} />
        </div>
      </div>

      <PlanCards period={period} className="mt-[33px] overflow-clip tablet:mt-9 tablet:overflow-visible" />

      <p className="mt-[50px] text-center text-[19px] text-white/70 tablet:mt-7 tablet:text-[16px]">
        All plans work inside Figma. Cancel anytime.
      </p>
    </Section>
  );
}
