import { Eyebrow } from "@/components/ui/Eyebrow";
import { Dim, H2 } from "@/components/ui/H2";
import { Section } from "@/components/ui/Section";
import { cn } from "@/lib/cn";

const ITEMS = [
  { t: "Runs inside Figma", d: "No separate app, no export step. Your file stays the source of truth." },
  { t: "Your design system", d: "Tokens and components come from your own library on every plan." },
  { t: "Nothing trains on you", d: "Your frames are never used to train models. Ever." },
  { t: "Cancel any time", d: "Monthly plans stop at the end of the cycle. No exit call needed." },
];

/** Column widths from Figma (380 / 420 / 420 / 420) and the dashed dividers' x on the rail. */
const WIDTHS = ["w-[380px]", "w-[420px]", "w-[420px]", "w-[420px]"];
const DIVIDERS = [449, 859, 1269];

/** Pricing 03 · In every plan (Figma 68:258) */
export function InEveryPlan() {
  return (
    <Section id="included" inner="h-[659px] p-0 tablet:h-auto tablet:px-(--pad) tablet:pt-[88px] tablet:pb-20">
      <div className="absolute top-[140px] left-10 tablet:static">
        <Eyebrow className="flex">IN EVERY PLAN</Eyebrow>
        <H2 className="mt-[27px] whitespace-nowrap tablet:mt-5 tablet:whitespace-normal">
          The parts we <Dim className="inline">don’t charge extra for.</Dim>
        </H2>
      </div>

      <ul className="absolute top-[360px] left-10 flex w-[1640px] tablet:static tablet:mt-10 tablet:grid tablet:w-full tablet:grid-cols-2 tablet:gap-x-8 tablet:gap-y-10 phone:grid-cols-1">
        {ITEMS.map((it, i) => (
          <li
            key={it.t}
            className={cn(
              "flex flex-none flex-col gap-4 tablet:w-auto tablet:px-0",
              WIDTHS[i],
              i === 0 ? "pr-10" : "px-10",
            )}
          >
            <span aria-hidden="true" className="text-[22px] leading-none text-accent">✓</span>
            <h3 className="w-[324px] font-display text-[24px] leading-[normal] font-medium tracking-[-0.48px] text-white tablet:w-auto">{it.t}</h3>
            <p className="w-[324px] text-[17px] leading-[1.6] text-white/60 tablet:w-auto">{it.d}</p>
          </li>
        ))}
      </ul>

      {DIVIDERS.map((left) => (
        <i
          key={left}
          aria-hidden="true"
          className="vdash-col pointer-events-none absolute top-[350px] h-[179px] w-[1.5px] tablet:hidden"
          style={{ left }}
        />
      ))}
    </Section>
  );
}
