import { DesktopDevice, MobileDevice, TabletDevice } from "@/components/mockups/Devices";
import { FitBox } from "@/components/ui/FitBox";
import { Section } from "@/components/ui/Section";
import { Z } from "@/components/ui/Z";
import { ColumnGuide, FeatureText } from "./FeatureText";

/** Features 05 · Responsive (Figma 71:933) — Desktop 0.70 / Mobile 0.72 / Tablet 0.55 of the landing devices */
export function ResponsiveFeature() {
  return (
    <Section id="responsive" inner="h-[900px] p-0 tablet:px-(--pad) tablet:pt-[88px] tablet:pb-24">
      <FeatureText
        side="right"
        eyebrow="RESPONSIVE"
        title={["Desktop, tablet, phone —", "from the same idea."]}
        body="Ask once and layout, type scale and spacing rebalance for every breakpoint, with auto-layout intact."
        bullets={["1440 / 768 / 390, or your own sizes", "Auto-layout preserved on every frame", "Components stay linked across sizes"]}
        bodyW={520}
        bulletW={460}
      />

      <FitBox x={50} y={200} w={703} h={549} className="tablet:mt-12 phone:h-auto">
        <div className="fit relative" aria-hidden="true">
          <Z x={0} y={0} s={0.7} w={860} h={610}>
            <DesktopDevice />
          </Z>
          <Z x={530} y={180} s={0.72} w={240} h={512}>
            <MobileDevice />
          </Z>
          <Z x={360} y={260} s={0.55} w={332} h={512}>
            <TabletDevice />
          </Z>
        </div>
      </FitBox>

      <ColumnGuide x={940} />
    </Section>
  );
}
