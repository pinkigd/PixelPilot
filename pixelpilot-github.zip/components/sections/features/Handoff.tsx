import { PhoneUI } from "@/components/mockups/PhoneUI";
import { FitBox } from "@/components/ui/FitBox";
import { Section } from "@/components/ui/Section";
import { Z } from "@/components/ui/Z";
import { ColumnGuide, FeatureText } from "./FeatureText";

/** Features 07 · Prototype & handoff (Figma 71:1183) — two phones at 0.78, the second with a tap hotspot + interaction tag */
export function Handoff() {
  return (
    <Section id="handoff" inner="h-[900px] p-0 tablet:px-(--pad) tablet:pt-[88px] tablet:pb-24">
      <FeatureText
        side="right"
        eyebrow="HANDOFF"
        title={["Flows and redlines,", "without the busywork."]}
        body="Turn approved screens into a clickable flow with hotspots, then export specs developers can actually read."
        bullets={["Hotspots generated from real components", "Specs list tokens, not raw hex values", "One link for review and for build"]}
        bodyW={520}
        bulletW={460}
      />

      <FitBox x={100} y={180} w={564} h={484} className="tablet:mt-12 phone:h-auto">
        <div className="fit relative" aria-hidden="true">
          <Z x={0} y={0} s={0.78} w={300} h={620}>
            <PhoneUI />
          </Z>
          <Z x={330} y={0} s={0.78} w={300} h={620}>
            <PhoneUI hotspot />
          </Z>
          <span className="absolute top-[380px] left-[420px] rounded-lg bg-accent px-3 py-[7px] text-[13px] leading-[normal] font-medium whitespace-nowrap text-ink">
            On tap → Destination
          </span>
        </div>
      </FitBox>

      <ColumnGuide x={940} />
    </Section>
  );
}
