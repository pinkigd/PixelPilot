import { HorizonSite } from "@/components/mockups/HorizonSite";
import { FitBox } from "@/components/ui/FitBox";
import { Section } from "@/components/ui/Section";
import { Z } from "@/components/ui/Z";
import { ColumnGuide, FeatureText } from "./FeatureText";

const COLORS = [
  { name: "Primary", hex: "#FF7A59", style: { background: "#ff7a59" } },
  { name: "Ink", hex: "#0F172A", style: { background: "#0f172a", border: "1px solid rgba(255,255,255,.2)" } },
  { name: "Sand", hex: "#F4EDE4", style: { background: "#f4ede4" } },
];
const COMPONENTS = [{ name: "Button", on: true }, { name: "Input" }, { name: "Card", on: true }, { name: "Modal" }, { name: "Navigation" }];

/** Features 04 · Design system (Figma 71:818): token panel (0.62) with the generated Horizon site (0.508) overlapping it */
export function DesignSystemFeature() {
  return (
    <Section id="design-system" inner="h-[900px] p-0 tablet:px-(--pad) tablet:pt-[88px] tablet:pb-24">
      <FeatureText
        side="left"
        eyebrow="DESIGN SYSTEM"
        title={["Your tokens.", "Your components."]}
        body="PixelPilot reads the library you already publish — colors, type and components — and builds only with those."
        bullets={["Reads published Figma libraries", "Flags anything off-system before you ship", "Swap a token, regenerate every screen"]}
        bodyW={580}
        bulletW={480}
      />

      <FitBox x={1040} y={250} w={633.2} h={415.6} className="tablet:mt-12 phone:h-auto">
        <div className="fit relative" aria-hidden="true">
          <Z x={0} y={0} s={0.62} w={560}>
            <div className="tokens">
              <div className="tokens__top">
                <span className="tokens__name">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                    <path d="M12 1.6L22.4 12 12 22.4 1.6 12Z" stroke="#fff" strokeWidth="1.7" strokeLinejoin="round" />
                    <path d="M12 7.6L16.4 12 12 16.4 7.6 12Z" fill="#fff" stroke="#fff" strokeWidth="1.2" strokeLinejoin="round" />
                  </svg>
                  Horizon DS
                </span>
                <span className="tokens__sync">Synced ✓</span>
              </div>
              <hr />
              <p className="tokens__lbl">COLOR</p>
              {COLORS.map((c) => (
                <div key={c.name} className="tok">
                  <i className="tok__sw" style={c.style} />
                  <b>{c.name}</b>
                  <span>{c.hex}</span>
                </div>
              ))}
              <hr />
              <p className="tokens__lbl">TYPE</p>
              <div className="tyk">
                <span className="tyk__aa tyk__aa--serif">Aa</span>
                <b>Display</b>
                <span>— Fraunces</span>
              </div>
              <div className="tyk">
                <span className="tyk__aa">Aa</span>
                <b>Body</b>
                <span>— Inter</span>
              </div>
              <hr />
              <p className="tokens__lbl">COMPONENTS</p>
              <div className="comps">
                {COMPONENTS.map((c) => (
                  <span key={c.name} className={c.on ? "comp is-on" : "comp"}>
                    {c.name}
                  </span>
                ))}
              </div>
            </div>
          </Z>
          <Z x={140} y={80} s={0.5084} w={970} h={660}>
            <HorizonSite />
          </Z>
        </div>
      </FitBox>

      <ColumnGuide x={980} />
    </Section>
  );
}
