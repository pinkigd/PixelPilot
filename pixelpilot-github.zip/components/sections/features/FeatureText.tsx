import { Eyebrow } from "@/components/ui/Eyebrow";
import { Dim, H2 } from "@/components/ui/H2";
import { cn } from "@/lib/cn";

type Props = {
  /** which column the copy sits in (the mockup takes the other one) */
  side: "left" | "right";
  eyebrow: string;
  title: [string, string];
  body: string;
  bullets: string[];
  /** paragraph / bullet text widths at 1680 canvas scale */
  bodyW: number;
  bulletW: number;
};

/** Copy column shared by every Features section: eyebrow + 56px headline @140/182, paragraph @340, bullets @480 (Figma frames 70:833 … 71:1183). */
export function FeatureText({ side, eyebrow, title, body, bullets, bodyW, bulletW }: Props) {
  const x = side === "left" ? "left-10" : "left-[1060px]";
  return (
    <>
      <div className={cn("absolute top-[140px] tablet:static", x)}>
        <Eyebrow className="flex">{eyebrow}</Eyebrow>
        <H2 className="mt-[27px] tablet:mt-5 tablet:text-balance">
          {title[0]}
          <Dim>{title[1]}</Dim>
        </H2>
      </div>
      <p
        className={cn("absolute top-[340px] text-[20px] leading-[1.6] text-white/62 tablet:static tablet:mt-6 tablet:w-full! tablet:text-[18px]", x)}
        style={{ width: bodyW }}
      >
        {body}
      </p>
      <ul className={cn("absolute top-[480px] flex flex-col gap-[18px] tablet:static tablet:mt-8", x)}>
        {bullets.map((b) => (
          <li key={b} className="flex items-start gap-3.5 text-[18px] leading-[1.6] text-white/70 tablet:text-[17px]">
            <i className="mt-[10px] ml-px size-[5px] flex-none rounded-full bg-accent" />
            <span className="tablet:w-auto!" style={{ width: bulletW }}>
              {b}
            </span>
          </li>
        ))}
      </ul>
    </>
  );
}

/** Dashed accent guide between the copy and the mockup (Figma "Column divider": 600px tall @ y=140). */
export function ColumnGuide({ x }: { x: number }) {
  return (
    <i
      aria-hidden="true"
      className="vdash-col pointer-events-none absolute top-[140px] h-[600px] w-[1.5px] tablet:hidden"
      style={{ left: x - 1 }}
    />
  );
}
