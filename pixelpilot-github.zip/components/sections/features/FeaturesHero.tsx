import { Nav } from "@/components/sections/Nav";
import { Button } from "@/components/ui/Button";
import { Eyebrow } from "@/components/ui/Eyebrow";
import { Section } from "@/components/ui/Section";

const ANCHORS = [
  { label: "Generate", href: "#generate" },
  { label: "Conversation", href: "#conversation" },
  { label: "Design system", href: "#design-system" },
  { label: "Responsive", href: "#responsive" },
  { label: "Variations", href: "#variations" },
  { label: "Handoff", href: "#handoff" },
];

/** Features 01 · Hero (Figma 70:791) */
export function FeaturesHero() {
  return (
    <Section as="header" id="top" inner="h-[740px] p-0 tablet:px-(--pad) tablet:pt-0 tablet:pb-[72px] phone:pt-0">
      <Nav active="features" />

      <div className="absolute inset-x-0 top-[180px] flex flex-col items-center px-6 text-center tablet:relative tablet:top-auto tablet:px-0 tablet:pt-14">
        <Eyebrow>FEATURES</Eyebrow>
        <h1 className="mt-[29px] font-display text-[72px] leading-[1.06] font-medium tracking-[-2.16px] tablet:mt-6 tablet:text-[length:clamp(40px,10.5vw,72px)] tablet:tracking-[-0.03em]">
          Six features.
          <span className="block text-muted">One uninterrupted flow.</span>
        </h1>
        <p className="mt-[17px] w-[790px] max-w-full text-[22px] leading-[1.55] text-white/75 tablet:text-[length:clamp(17px,3.4vw,22px)]">
          From the first prompt to the handoff link — each step hands work to the next without leaving your file.
        </p>
        <nav aria-label="Features" className="mt-[20px] flex gap-3 tablet:mt-8 tablet:flex-wrap tablet:justify-center">
          {ANCHORS.map((a) => (
            <a
              key={a.href}
              href={a.href}
              className="rounded-full border border-white/14 bg-card px-[22px] py-3 text-[16px] leading-none font-medium whitespace-nowrap text-white/85 transition-colors hover:border-white/40 hover:text-white tablet:px-[18px] tablet:py-[11px] tablet:text-[15px]"
            >
              {a.label}
            </a>
          ))}
        </nav>
        <div className="mt-12 flex gap-4 tablet:mt-9 tablet:flex-wrap tablet:justify-center tablet:gap-3">
          <Button href="#cta" className="tablet:px-7 tablet:py-[18px] tablet:text-[17px]">
            Start designing <span className="text-[20px] font-semibold">→</span>
          </Button>
          <Button href="#handoff" variant="ghost" className="tablet:px-7 tablet:py-[18px] tablet:text-[17px]">
            <span className="text-[18px] font-normal">▶</span> Watch the 2-min tour
          </Button>
        </div>
      </div>
    </Section>
  );
}
