import { ChatPanel } from "@/components/mockups/ChatPanel";
import { FitBox } from "@/components/ui/FitBox";
import { Section } from "@/components/ui/Section";
import { ColumnGuide, FeatureText } from "./FeatureText";

/** Features 03 · Edit by conversation (Figma 70:993) — copy on the right, chat panel on the left */
export function Conversation() {
  return (
    <Section id="conversation" inner="h-[900px] p-0 tablet:px-(--pad) tablet:pt-[88px] tablet:pb-24">
      <FeatureText
        side="right"
        eyebrow="CONVERSATION"
        title={["Change six screens", "with one sentence."]}
        body="Select the frames, say what should change, and the edit lands everywhere at once — with a diff you can undo."
        bullets={["Works across up to 50 frames", "Shows what moved before applying", "Undo restores the exact state"]}
        bodyW={520}
        bulletW={460}
      />

      <FitBox x={40} y={140} w={620} h={694} className="tablet:mt-12 phone:h-auto">
        <ChatPanel wide />
      </FitBox>

      <ColumnGuide x={940} />
    </Section>
  );
}
