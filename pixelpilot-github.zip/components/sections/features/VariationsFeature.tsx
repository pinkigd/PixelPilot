import { VariationEditorial } from "@/components/mockups/VariationEditorial";
import { VariationExpressive } from "@/components/mockups/VariationExpressive";
import { VariationMinimal } from "@/components/mockups/VariationMinimal";
import { FitBox } from "@/components/ui/FitBox";
import { Section } from "@/components/ui/Section";
import { Z } from "@/components/ui/Z";
import { ColumnGuide, FeatureText } from "./FeatureText";

/** Features 06 · Variations (Figma 71:1061) — three landing variation cards at 0.414; Editorial is the picked one */
export function VariationsFeature() {
  return (
    <Section id="variations" inner="h-[900px] p-0 tablet:px-(--pad) tablet:pt-[88px] tablet:pb-24">
      <FeatureText
        side="left"
        eyebrow="VARIATIONS"
        title={["Three directions,", "not three days."]}
        body="One prompt returns distinct visual directions — minimal, editorial, expressive — each built from the same content."
        bullets={["Pick one and keep iterating on it", "Directions stay on your design system", "Share all three for a decision"]}
        bodyW={580}
        bulletW={480}
      />

      <FitBox x={1030} y={250} w={643.2} h={270} className="tablet:mt-12 phone:h-auto">
        <div className="fit relative" aria-hidden="true">
          <Z x={0} y={20} s={0.414} w={515} h={591}>
            <VariationMinimal />
          </Z>
          <Z x={215} y={0} s={0.414} w={515} h={601}>
            <VariationEditorial picked />
          </Z>
          <Z x={430} y={20} s={0.414} w={515} h={591}>
            <VariationExpressive />
          </Z>
        </div>
      </FitBox>

      <ColumnGuide x={980} />
    </Section>
  );
}
