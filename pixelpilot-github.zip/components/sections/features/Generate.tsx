import { GenWindow } from "@/components/mockups/GenWindow";
import { WireWindow } from "@/components/mockups/WireWindow";
import { FitBox } from "@/components/ui/FitBox";
import { Section } from "@/components/ui/Section";
import { Z } from "@/components/ui/Z";
import { ColumnGuide, FeatureText } from "./FeatureText";

/** Features 02 · Prompt to interface (Figma 70:833). The generated window runs past the right rail (x 1180 → 1866 on the 1920 frame). */
export function Generate() {
  return (
    <Section id="generate" className="overflow-x-clip" inner="h-[900px] overflow-visible p-0 tablet:overflow-hidden tablet:px-(--pad) tablet:pt-[88px] tablet:pb-24">
      <FeatureText
        side="left"
        eyebrow="GENERATE"
        title={["Describe it once.", "Get a real screen."]}
        body="Type what the screen needs to do. PixelPilot assembles it from your components, with real copy and data instead of grey boxes."
        bullets={[
          "Uses your library, not a generic kit",
          "Wireframe, layout and polished states",
          "Ready in about four seconds",
        ]}
        bodyW={580}
        bulletW={480}
      />

      {/* the window overhangs the rail by 66px (into the 120px gutter at 1920); on narrower screens there is no gutter, so it slides back inside */}
      <FitBox
        x="calc(1060px - clamp(0px, 66px - (100vw - 1680px) / 2, 66px))"
        y={163.5} w={686.4}
        h={651.3}
        className="tablet:mt-12 phone:h-auto"
      >
        <div className="fit relative" aria-hidden="true">
          <Z x={20} y={0} s={0.8} w={497} h={348}>
            <WireWindow />
          </Z>
          <Z x={0} y={136.5} s={0.78} w={880} h={660}>
            <GenWindow />
          </Z>
        </div>
      </FitBox>

      <ColumnGuide x={980} />
    </Section>
  );
}
