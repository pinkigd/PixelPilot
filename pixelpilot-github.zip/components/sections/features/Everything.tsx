import { Eyebrow } from "@/components/ui/Eyebrow";
import { Section } from "@/components/ui/Section";
import { cn } from "@/lib/cn";

const ITEMS = [
  { icon: "⌘", title: "Command palette", body: "Trigger any action from ⌘K without leaving the canvas." },
  { icon: "⟲", title: "Version history", body: "Every generation is a restore point, not a new file." },
  { icon: "◫", title: "Frame selection rules", body: "Run on a page, a section or just the frames you picked." },
  { icon: "⚑", title: "Content placeholders", body: "Real copy and data, or your own strings from a sheet." },
  { icon: "⚙", title: "Team presets", body: "Save prompts and settings the whole team can reuse." },
  { icon: "↗", title: "Dev Mode ready", body: "Specs and tokens land where engineers already look." },
];

/** Features 08 · Everything else (Figma 71:1246): 3 × 2 grid, 1640px wide, 44px cell padding, hairline dividers */
export function Everything() {
  return (
    <Section id="more" inner="h-[900px] p-0 tablet:px-(--pad) tablet:pt-[88px] tablet:pb-24">
      <div className="absolute top-[140px] left-10 tablet:static">
        <Eyebrow className="flex">EVERYTHING ELSE</Eyebrow>
        <h2 className="mt-[27px] font-display text-[56px] leading-[1.06] font-medium tracking-[-1.68px] whitespace-nowrap text-white tablet:mt-5 tablet:text-[length:clamp(34px,7.4vw,56px)] tablet:tracking-[-0.03em] tablet:whitespace-normal">
          The small things <span className="text-muted">that keep the flow going.</span>
        </h2>
      </div>

      <div className="absolute top-[380px] left-10 grid w-[1640px] grid-cols-[562px_561px_1fr] tablet:static tablet:mt-12 tablet:w-full tablet:grid-cols-1 phone:grid-cols-1">
        {ITEMS.map((it, i) => {
          const row = Math.floor(i / 3);
          return (
            <div
              key={it.title}
              className={cn(
                "flex flex-col gap-4",
                // text columns start at x = 160 / 722 / 1283 on the 1920 frame (measured on the Figma render)
                row === 0 ? "pb-[44px]" : "py-[44px]",
                "tablet:border-t tablet:border-white/10 tablet:py-8",
              )}
            >
              <span className="text-[24px] leading-none text-accent">{it.icon}</span>
              <h3 className="font-display text-[24px] leading-[normal] font-medium tracking-[-0.48px] text-white">{it.title}</h3>
              <p className="text-[17px] leading-[1.6] whitespace-nowrap text-white/60 tablet:whitespace-normal">{it.body}</p>
            </div>
          );
        })}
      </div>

      {/* column dividers + row divider (Figma 71:1278 / 71:1279 / 71:1280) */}
      <i aria-hidden="true" className="vdash-col pointer-events-none absolute top-[370px] left-[585.67px] h-[390px] w-[1.5px] tablet:hidden" />
      <i aria-hidden="true" className="vdash-col pointer-events-none absolute top-[370px] left-[1132.33px] h-[390px] w-[1.5px] tablet:hidden" />
      <i aria-hidden="true" className="absolute top-[538px] left-10 h-px w-[1640px] bg-white/10 tablet:hidden" />
    </Section>
  );
}
