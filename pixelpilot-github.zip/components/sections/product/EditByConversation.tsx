import { ChatPanel } from "@/components/mockups/ChatPanel";
import { Eyebrow } from "@/components/ui/Eyebrow";
import { FitBox } from "@/components/ui/FitBox";
import { Dim, H2 } from "@/components/ui/H2";
import { Section } from "@/components/ui/Section";

const BULLETS = [
  "Works across up to 50 selected frames",
  "Shows a diff before anything is applied",
  "Undo restores the exact previous state",
];

/** Product 03 · Edit by conversation (Figma 65:130) */
export function EditByConversation() {
  return (
    <Section
      id="edit"
      inner="h-[960px] p-0 tablet:px-(--pad) tablet:pt-[88px] tablet:pb-24"
    >
      <div className="absolute top-[160px] left-10 tablet:static">
        <Eyebrow>EDIT BY CONVERSATION</Eyebrow>
        <H2 className="mt-[27px] tablet:mt-5">
          Talk to the canvas,
          <Dim>not to the layer list.</Dim>
        </H2>
      </div>
      <p className="absolute top-[372px] left-10 w-[560px] text-[20px] leading-[1.6] text-white/62 tablet:static tablet:mt-6 tablet:w-full tablet:text-[18px]">
        Select the screens, say what should change, and watch the edit land
        everywhere at once. Every change is reversible and shows exactly what
        moved.
      </p>
      <ul className="absolute top-[510px] left-10 flex flex-col gap-[18px] tablet:static tablet:mt-8">
        {BULLETS.map((b) => (
          <li
            key={b}
            className="flex items-start gap-3.5 text-[18px] leading-[1.6] text-white/70 tablet:text-[17px]"
          >
            <i className="mt-[10px] ml-px size-[5px] flex-none rounded-full bg-accent" />
            <span className="w-[480px] tablet:w-auto">{b}</span>
          </li>
        ))}
      </ul>

      <FitBox
        x={960}
        y={140}
        w={560}
        h={690}
        className="tablet:mt-12 phone:h-auto"
      >
        <ChatPanel />
      </FitBox>

      <i
        aria-hidden="true"
        className="vdash-accent pointer-events-none absolute top-[140px] left-[900px] h-[620px] w-px tablet:hidden"
      />
    </Section>
  );
}
