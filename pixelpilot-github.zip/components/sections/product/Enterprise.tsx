import { ShieldArt } from "@/components/mockups/ShieldArt";
import { FitBox } from "@/components/ui/FitBox";
import { H2 } from "@/components/ui/H2";
import { Section } from "@/components/ui/Section";

/** Product 06 · Enterprise ready (Figma 66:351) */
export function Enterprise() {
  return (
    <Section
      id="enterprise"
      inner="h-[930px] p-0 tablet:px-(--pad) tablet:pt-[88px] tablet:pb-24"
    >
      <i
        aria-hidden="true"
        className="hatch pointer-events-none absolute inset-x-0 top-px h-[90px] tablet:h-10"
      />

      <H2 className="absolute top-[140px] left-10 whitespace-nowrap tablet:static tablet:whitespace-normal">
        Enterprise ready.{" "}
        <span className="text-muted">
          SOC2,
          <br className="tablet:hidden" /> ISO27001 &amp; GDPR.
        </span>
      </H2>
      <p className="absolute top-[150px] left-[880px] w-[532px] text-[20px] leading-[1.6] text-white/62 tablet:static tablet:mt-6 tablet:w-full tablet:text-[18px]">
        SOC 2, ISO 27001, GDPR and UK GDPR compliant, with the controls larger
        teams need to roll out PixelPilot across the org.
      </p>

      <div className="absolute top-[550px] left-[880px] flex gap-3.5 tablet:static tablet:mt-8 tablet:flex-wrap">
        <a
          href="#"
          className="rounded-full border-[1.2px] border-accent/50 bg-[#2a1512] px-6 py-3.5 text-[16px] leading-none font-semibold whitespace-pre text-[#ff6a5a] transition-transform hover:-translate-y-px"
        >
          Visit Trust Center{"  "}↗
        </a>
        <a
          href="#"
          className="rounded-full border border-white/18 bg-card px-6 py-3.5 text-[16px] leading-none font-semibold whitespace-nowrap text-white transition-transform hover:-translate-y-px"
        >
          Security at PixelPilot
        </a>
      </div>

      <div className="absolute top-[640px] left-[880px] flex gap-3.5 tablet:static tablet:mt-5 tablet:flex-wrap">
        {["SOC2", "ISO 27001", "GDPR"].map((c) => (
          <span
            key={c}
            className="inline-flex items-center gap-2.5 rounded-full border border-white/12 bg-card px-[18px] py-2.5 text-[15px] leading-[normal] font-medium whitespace-nowrap text-white/90"
          >
            <i className="text-[14px] font-normal not-italic text-white/80">
              ⛉
            </i>
            {c}
          </span>
        ))}
      </div>

      <FitBox
        x={100}
        y={330}
        w={640}
        h={440}
        className="tablet:mt-12 phone:h-auto"
      >
        <ShieldArt />
      </FitBox>

      <i
        aria-hidden="true"
        className="vdash-accent pointer-events-none absolute top-[200px] left-[820px] h-[620px] w-px tablet:hidden"
      />
    </Section>
  );
}
