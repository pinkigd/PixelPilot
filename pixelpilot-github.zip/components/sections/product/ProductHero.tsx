import { HeroWindow } from "@/components/mockups/HeroWindow";
import { Nav } from "@/components/sections/Nav";
import { Button } from "@/components/ui/Button";
import { Eyebrow } from "@/components/ui/Eyebrow";
import { Section } from "@/components/ui/Section";

/** Product 01 · Hero (Figma 64:131) */
export function ProductHero() {
  return (
    <Section
      as="header"
      id="top"
      inner="h-[1010px] p-0 tablet:px-(--pad) tablet:pt-0 tablet:pb-[72px] phone:pt-0"
    >
      <Nav active="product" />

      <div className="absolute inset-x-0 top-[150px] flex flex-col items-center px-6 text-center tablet:relative tablet:top-auto tablet:px-0 tablet:pt-14">
        <Eyebrow>PRODUCT</Eyebrow>
        <h1 className="mt-[31px] font-display text-[80px] leading-[1.06] font-medium tracking-[-2.4px] tablet:mt-6 tablet:text-[length:clamp(42px,11.5vw,80px)]">
          One copilot.
          <span className="block text-muted">Every step of the work.</span>
        </h1>
        <p className="mt-4 text-[23px] leading-[normal] text-white/80 tablet:text-[length:clamp(17px,3.6vw,23px)]">
          Generate, edit, adapt and hand off — without leaving your Figma file.
        </p>
        <div className="mt-9 flex gap-4 tablet:flex-wrap tablet:justify-center tablet:gap-3">
          <Button
            href="#cta"
            className="tablet:px-7 tablet:py-[18px] tablet:text-[17px]"
          >
            Start designing
          </Button>
          <Button
            href="#cta"
            variant="ghost"
            className="border-white/18 px-9 tablet:px-7 tablet:py-[18px] tablet:text-[17px]"
          >
            Book a walkthrough
          </Button>
        </div>
      </div>

      {/* Product window — same mockup as the landing hero, 560px tall here */}
      <HeroWindow className="h-[560px] min-[1100px]:top-[566px]" />
    </Section>
  );
}
