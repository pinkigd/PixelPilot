import type { ReactNode } from "react";
import { Eyebrow } from "@/components/ui/Eyebrow";
import { Dim, H2 } from "@/components/ui/H2";
import { Section } from "@/components/ui/Section";
import { cn } from "@/lib/cn";

/** string = text · "-" = not included · "✓" = included */
const ROWS: [string, string, string, string][] = [
  ["AI generations", "50 / month", "Unlimited", "Unlimited"],
  ["Edit by conversation", "-", "✓", "✓"],
  ["Design system sync", "1 library", "Unlimited", "Unlimited"],
  ["Responsive breakpoints", "Desktop only", "✓", "✓"],
  ["Visual variations", "-", "3 per prompt", "3 per prompt"],
  ["Prototype & handoff", "-", "✓", "✓"],
  ["Shared prompt history", "-", "-", "✓"],
  ["Admin & SSO", "-", "-", "✓"],
  ["Support", "Community", "Priority", "Dedicated"],
];

const COLS =
  "grid grid-cols-[680px_320px_320px_320px] items-center tablet:grid-cols-[1.5fr_1fr_1fr_1fr]";

function Cell({ v, pro }: { v: string; pro?: boolean }) {
  if (v === "-")
    return (
      <span className="text-[18px] text-white/35 tablet:text-[16px]">—</span>
    );
  if (v === "✓")
    return (
      <span
        className={cn(
          "grid size-[26px] place-items-center rounded-full text-[13px] leading-[normal] font-semibold text-white tablet:size-[22px] tablet:text-[12px]",
          pro ? "bg-accent" : "bg-white/10",
        )}
      >
        ✓
      </span>
    );
  return (
    <span className="text-[18px] leading-[normal] text-white/80 tablet:text-[15px] tablet:leading-tight phone:text-[13px]">
      {v}
    </span>
  );
}

/** Product 05 · What's included (Figma 66:238) */
export function Included({
  id = "plans",
  eyebrow = "WHAT’S INCLUDED",
  title = (
    <>
      Every plan, <Dim className="inline">side by side.</Dim>
    </>
  ),
  intro = "Pricing is per editor. Everything runs inside Figma — no separate app to install.",
}: {
  id?: string;
  eyebrow?: string;
  title?: ReactNode;
  intro?: string;
} = {}) {
  return (
    <Section
      id={id}
      inner="h-[1242px] p-0 tablet:px-(--pad) tablet:pt-[88px] tablet:pb-24"
    >
      <div className="absolute top-[140px] left-10 tablet:static">
        <Eyebrow className="flex">{eyebrow}</Eyebrow>
        <H2 className="mt-[27px] whitespace-nowrap tablet:mt-5 tablet:whitespace-normal">{title}</H2>
      </div>
      <p className="absolute top-[278px] left-10 w-[600px] text-[20px] leading-[1.6] text-white/62 tablet:static tablet:mt-6 tablet:w-full tablet:text-[18px]">
        {intro}
      </p>

      {/* "Pro" column highlight */}
      <i
        aria-hidden="true"
        className="absolute top-[380px] left-[1040px] h-[722px] w-[320px] rounded-2xl bg-accent/5 tablet:hidden"
      />

      <div
        role="table"
        aria-label="Plan comparison"
        className="absolute top-[400px] left-10 w-[1640px] tablet:static tablet:mt-12 tablet:w-full"
      >
        <div role="row" className={cn(COLS, "pb-6 text-center tablet:pb-4")}>
          <span
            role="columnheader"
            className="text-left text-[17px] leading-[normal] font-medium text-white/55 tablet:text-[15px]"
          >
            Capability
          </span>
          {["Starter", "Pro", "Team"].map((n) => (
            <span
              key={n}
              role="columnheader"
              className={cn(
                "flex items-center justify-center gap-3 font-display text-[24px] leading-[normal] font-medium tracking-[-0.48px] text-white tablet:text-[18px] tablet:tracking-normal phone:text-[16px]",
                n === "Pro" && "tablet:bg-accent/5",
              )}
            >
              {n}
              {n === "Pro" && (
                <b className="rounded-full bg-accent px-3 py-[5px] font-sans text-[12px] leading-[normal] font-semibold tracking-normal tablet:hidden">
                  Popular
                </b>
              )}
            </span>
          ))}
        </div>
        {ROWS.map(([label, ...vals]) => (
          <div
            key={label}
            role="row"
            className={cn(
              COLS,
              "border-t border-white/9 py-[22px] text-center tablet:py-4",
            )}
          >
            <span
              role="rowheader"
              className="pr-3 text-left text-[19px] leading-[normal] text-white tablet:text-[16px] tablet:leading-tight phone:text-[14px]"
            >
              {label}
            </span>
            {vals.map((v, i) => (
              <span
                key={i}
                role="cell"
                className={cn(
                  "flex items-center justify-center",
                  i === 1 && "tablet:bg-accent/5 tablet:py-1",
                )}
              >
                <Cell v={v} pro={i === 1} />
              </span>
            ))}
          </div>
        ))}
      </div>
    </Section>
  );
}
