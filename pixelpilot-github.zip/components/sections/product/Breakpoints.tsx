import { BreakpointStage } from "@/components/mockups/BreakpointStage";
import { Eyebrow } from "@/components/ui/Eyebrow";
import { FitBox } from "@/components/ui/FitBox";
import { Dim, H2 } from "@/components/ui/H2";
import { Section } from "@/components/ui/Section";

const BULLETS = [
  "1440 / 768 / 390 by default, or your own sizes",
  "Type scale and spacing rebalanced per size",
  "Auto-layout preserved on every frame",
];

/** Product 04 · Every breakpoint (Figma 65:200) — text on the right, device stage on the left */
export function Breakpoints() {
  return (
    <Section
      id="responsive"
      inner="h-[920px] p-0 tablet:px-(--pad) tablet:pt-[88px] tablet:pb-24"
    >
      <div className="absolute top-[140px] left-[1060px] tablet:static">
        <Eyebrow>RESPONSIVE</Eyebrow>
        <H2 className="mt-[27px] tablet:mt-5">
          One idea,
          <Dim>every breakpoint.</Dim>
        </H2>
      </div>
      <p className="absolute top-[352px] left-[1060px] w-[510px] text-[20px] leading-[1.6] text-white/62 tablet:static tablet:mt-6 tablet:w-full tablet:text-[18px]">
        Ask once and PixelPilot rebalances layout, type scale and spacing for
        desktop, tablet and mobile — using the same components.
      </p>
      <ul className="absolute top-[500px] left-[1060px] flex flex-col gap-[18px] tablet:static tablet:mt-8">
        {BULLETS.map((b) => (
          <li
            key={b}
            className="flex items-start gap-3.5 text-[18px] leading-[1.6] text-white/70 tablet:text-[17px]"
          >
            <i className="mt-[10px] ml-px size-[5px] flex-none rounded-full bg-accent" />
            <span className="w-[460px] tablet:w-auto">{b}</span>
          </li>
        ))}
      </ul>

      <FitBox
        x={60}
        y={142}
        w={780}
        h={620}
        className="tablet:mt-12 phone:h-auto"
      >
        <BreakpointStage />
      </FitBox>

      <i
        aria-hidden="true"
        className="vdash-accent pointer-events-none absolute top-[140px] left-[980px] h-[640px] w-px tablet:hidden"
      />
    </Section>
  );
}
