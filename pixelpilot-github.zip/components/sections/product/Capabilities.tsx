import { Eyebrow } from "@/components/ui/Eyebrow";
import { Dim, H2 } from "@/components/ui/H2";
import { Section } from "@/components/ui/Section";
import { cn } from "@/lib/cn";

const ITEMS = [
  {
    icon: "⚡",
    title: "Prompt to interface",
    body: "Describe the screen. PixelPilot builds a first version using your own components.",
  },
  {
    icon: "✦",
    title: "Edit by conversation",
    body: "Ask for a change in plain words and it lands across every selected frame at once.",
  },
  {
    icon: "◈",
    title: "Design system sync",
    body: "Colors, type and components come from your library — never from a generic kit.",
  },
  {
    icon: "⇅",
    title: "Responsive breakpoints",
    body: "One idea adapts to desktop, tablet and mobile with layout and type rebalanced.",
  },
  {
    icon: "◫",
    title: "Visual variations",
    body: "Three distinct directions from one prompt, so you never ship the first idea by default.",
  },
  {
    icon: "➤",
    title: "Prototype & handoff",
    body: "Hotspots, flows and redlines generated from the screens you just approved.",
  },
];

/** Product 02 · Capabilities (Figma 64:282) */
export function Capabilities() {
  return (
    <Section
      id="capabilities"
      inner="h-[1026px] p-0 tablet:px-(--pad) tablet:pt-[88px] tablet:pb-24"
    >
      <div className="absolute top-[140px] left-10 tablet:static">
        <Eyebrow>CAPABILITIES</Eyebrow>
        <H2 className="mt-[23px] tablet:mt-5">
          Six things it does
          <Dim>better than a blank canvas.</Dim>
        </H2>
      </div>
      <p className="absolute top-[196px] left-[1160px] w-[520px] text-[20px] leading-[1.55] text-white/62 tablet:static tablet:mt-6 tablet:w-full tablet:text-[18px]">
        Every capability works on the frames you select — nothing runs without
        you asking for it.
      </p>

      <ul className="absolute top-[420px] left-10 grid w-[1640px] grid-cols-[516px_562px_562px] tablet:static tablet:mt-12 tablet:w-full tablet:grid-cols-2 tablet:gap-x-8 phone:grid-cols-1">
        {ITEMS.map((it, i) => {
          const col = i % 3;
          const row = Math.floor(i / 3);
          return (
            <li
              key={it.title}
              className={cn(
                "flex flex-col gap-[18px] pr-[46px] pb-[46px]",
                col > 0 && "pl-[46px]",
                row > 0 && "pt-[46px]",
                "tablet:border-t tablet:border-white/10 tablet:px-0 tablet:pt-7 tablet:pb-8",
              )}
            >
              <span className="w-[460px] text-[26px] leading-none text-accent tablet:w-full">
                {it.icon}
              </span>
              <h3 className="w-[460px] font-display text-[26px] leading-[normal] font-medium tracking-[-0.52px] text-white tablet:w-full">
                {it.title}
              </h3>
              <p className="w-[460px] text-[18px] leading-[1.6] text-white/60 tablet:w-full tablet:text-[17px]">
                {it.body}
              </p>
            </li>
          );
        })}
      </ul>

      {/* guides (Figma "Column divider" ×2 + "Row divider"): drawn as in the design, not snapped to the cells */}
      <i
        aria-hidden="true"
        className="vdash-accent pointer-events-none absolute top-[430px] left-[586.67px] h-[368px] w-px tablet:hidden"
      />
      <i
        aria-hidden="true"
        className="vdash-accent pointer-events-none absolute top-[430px] left-[1133.33px] h-[368px] w-px tablet:hidden"
      />
      <i
        aria-hidden="true"
        className="absolute top-[591px] left-10 h-px w-[1640px] bg-white/10 tablet:hidden"
      />
    </Section>
  );
}
