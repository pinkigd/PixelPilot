import { Eyebrow } from "@/components/ui/Eyebrow";
import { Section } from "@/components/ui/Section";
import { cn } from "@/lib/cn";

const PILLS = [
  { icon: "✦", label: "Generate" },
  { icon: "⇄", label: "Refine" },
  { icon: "⧉", label: "Compare" },
  { icon: "▤", label: "Document" },
  { icon: "➤", label: "Prototype", accent: true },
];

export function Philosophy() {
  return (
    <Section inner="pb-[160px] text-center">
      <Eyebrow className="flex justify-center">OUR PHILOSOPHY</Eyebrow>
      <h2 className="mt-[39px] font-display text-[80px] leading-[1.06] font-medium tracking-[-2.4px] tablet:text-[length:clamp(34px,8.6vw,80px)] tablet:tracking-[-0.035em]">
        <span className="block text-muted">AI handles the pixels.</span>
        <span className="block">You make the decisions.</span>
      </h2>
      <p className="mt-7 text-[25px] text-white/85 tablet:text-[19px]">PixelPilot takes the repetitive work, so your time goes to taste, judgment and ideas.</p>

      <div className="mx-auto mt-[84px] flex flex-wrap justify-center gap-[26px] tablet:mt-11 tablet:gap-3">
        {PILLS.map((p) => (
          <span
            key={p.label}
            className="inline-flex items-center gap-4 rounded-full border border-white/20 bg-card py-6 pr-[34px] pl-[30px] leading-[normal] transition duration-200 hover:-translate-y-0.5 hover:border-white/45 tablet:gap-3 tablet:py-4 tablet:pr-[22px] tablet:pl-5"
          >
            <i className={cn("text-[22px] not-italic", p.accent && "text-accent-soft")}>{p.icon}</i>
            <span className="text-[21px] font-medium tablet:text-[17px]">{p.label}</span>
          </span>
        ))}
      </div>
    </Section>
  );
}
