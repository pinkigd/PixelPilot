import { Eyebrow } from "@/components/ui/Eyebrow";
import { Dim, H2 } from "@/components/ui/H2";
import { Section } from "@/components/ui/Section";
import maya from "@/assets/pr-maya.jpg";
import { cn } from "@/lib/cn";

export const STATS = [
  { co: "NORTHWIND", v: "11.4h", l: ["saved per designer,", "every week"] },
  { co: "LUMEN", v: "3.8×", l: ["faster from idea to", "first review"] },
  { co: "KESTREL", v: "96%", l: ["of screens matched", "the design system"] },
  { co: "ORBIT", v: "40+", l: ["variations explored", "per project"] },
];

/** Four result cards (Figma "Stats"). `guides` draws the dashed column guides used on the landing page. */
export function StatGrid({ guides = true, className }: { guides?: boolean; className?: string }) {
  return (
    <div className={cn("relative grid grid-cols-4 gap-5 tablet:grid-cols-2 tablet:gap-3.5 phone:grid-cols-1", className)}>
      {STATS.map((s, i) => (
        <div
          key={s.co}
          className="relative min-h-[331px] overflow-hidden rounded-3xl border border-white/16 bg-card px-9 pt-10 pb-[39px] tablet:min-h-0 tablet:px-6 tablet:py-7 phone:flex phone:flex-wrap phone:items-baseline phone:justify-between phone:gap-3"
        >
          <span className="block font-mono text-[16px] font-medium tracking-[0.96px] text-white/85">{s.co}</span>
          <span
            className={cn(
              "mt-[22px] block font-display text-[118px] leading-none font-semibold tracking-[-4.72px] whitespace-nowrap text-white",
              "tablet:mt-4 tablet:text-[length:clamp(54px,10vw,88px)] tablet:tracking-[-0.04em] phone:mt-0",
              i === 0 && "text-accent-soft",
            )}
          >
            {s.v}
          </span>
          <p className="mt-5 text-[25px] leading-[1.38] text-white/85 tablet:text-[18px]">
            {s.l[0]}
            <br />
            {s.l[1]}
          </p>
        </div>
      ))}
      {guides && ["calc(25% - 5px)", "50%", "calc(75% + 5px)"].map((left) => (
        <i key={left} className="vdash pointer-events-none absolute top-2 h-[330px] w-px tablet:hidden" style={{ left }} />
      ))}
    </div>
  );
}

export function Proof() {
  return (
    <Section>
      <div className="flex items-end justify-between gap-10 tablet:flex-col tablet:items-start tablet:gap-4">
        <div>
          <Eyebrow className="flex">RESULTS</Eyebrow>
          <H2 className="mt-[19px]">
            Teams ship more.
            <Dim>Stress less.</Dim>
          </H2>
        </div>
        <p className="pb-2.5 text-[21px] text-white/85 tablet:pb-0 tablet:text-[18px]">Measured across 1,200 design teams in their first 90 days.</p>
      </div>

      <StatGrid className="mt-[30px] tablet:mt-9" />

      <figure className="relative -mx-px mt-[47px] tablet:mx-0 flex min-h-[275px] items-center justify-between gap-10 overflow-hidden rounded-[26px] border border-accent/45 bg-card pr-[25px] pl-[62px] tablet:mt-8 tablet:flex-col tablet:items-start tablet:gap-7 tablet:px-7 tablet:pt-10 tablet:pb-8">
        <span
          aria-hidden="true"
          className="absolute top-[43px] left-[63px] font-display text-[110px] leading-[0.6] font-semibold tracking-[-4.4px] text-accent-soft tablet:top-6 tablet:left-6 tablet:text-[80px]"
        >
          “
        </span>
        <blockquote className="pt-[54px] text-[44px] leading-[63px] font-normal tracking-[-1.1px] tablet:leading-normal tablet:tracking-[-0.01em] text-white tablet:pt-10 tablet:text-[length:clamp(22px,4.6vw,34px)]">
          PixelPilot didn’t replace our designers.
          <br />
          It gave them their afternoons back.
        </blockquote>
        <figcaption className="flex flex-none items-center gap-[30px] tablet:gap-[18px]">
          <span className="block size-[158px] flex-none overflow-hidden rounded-full border-2 border-[#4b4b66] tablet:size-[84px] tablet:border">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={maya.src} width={maya.width} height={maya.height} alt="Maya Chen" draggable={false} className="block size-full object-cover" />
          </span>
          <div className="pt-[3px] tablet:pt-0">
            <p className="font-display text-[26px] font-medium tracking-[-0.52px] text-white tablet:text-[22px]">Maya Chen</p>
            <p className="mt-1.5 text-[20px] whitespace-nowrap text-white/85 tablet:text-[16px] tablet:whitespace-normal">Head of Design, Northwind</p>
          </div>
        </figcaption>
      </figure>
    </Section>
  );
}
