import { Eyebrow } from "@/components/ui/Eyebrow";
import { Dim, H2 } from "@/components/ui/H2";
import { Section } from "@/components/ui/Section";

// NOTE: Figma only defines the answer to question 1; answers 2–6 are placeholder copy — replace with real content.
const QAS = [
  {
    q: "Does PixelPilot use my designs to train AI?",
    a: "No. PixelPilot runs inside your Figma files and only reads the frames you select. Your designs are never used to train models.",
  },
  {
    q: "Will it follow my existing design system?",
    a: "Yes. Point PixelPilot at your library and it builds with your components, tokens and patterns instead of inventing new ones.",
  },
  {
    q: "Can I edit what PixelPilot generates?",
    a: "Everything it generates is regular, editable Figma layers. Tweak it by hand or keep refining by conversation.",
  },
  {
    q: "Does it work with FigJam and Dev Mode?",
    a: "PixelPilot works in design files. Anything it generates can be handed off through Dev Mode like any other frame.",
  },
  {
    q: "How does team billing work?",
    a: "Team is billed per seat, per month. Add or remove seats whenever your team changes.",
  },
  {
    q: "What happens when my trial ends?",
    a: "You can continue on Pro, move to Starter, or cancel. Your files stay yours either way.",
  },
];

type Qa = { q: string; a: string };

export function Faq({
  qas = QAS,
  title = ["Questions,", "answered."],
  accentGuide = false,
  id,
}: {
  qas?: Qa[];
  title?: [string, string];
  /** the Pricing page draws its guide as the 1.5px accent dashed "column divider" */
  accentGuide?: boolean;
  id?: string;
}) {
  return (
    <Section id={id}>
      <i
        className={
          accentGuide
            ? "vdash-col pointer-events-none absolute top-20 left-[619px] h-[380px] w-[1.5px] tablet:hidden"
            : "vdash pointer-events-none absolute top-20 left-[620px] h-[380px] w-px tablet:hidden"
        }
      />
      <div className="flex items-start gap-[120px] tablet:flex-col tablet:gap-10">
        <div className="w-[520px] flex-none tablet:w-full">
          <Eyebrow className="flex">FAQ</Eyebrow>
          <H2 className="mt-7">
            {title[0]}
            <Dim>{title[1]}</Dim>
          </H2>
          <p className="mt-[30px] text-[21px] leading-normal text-white/80 tablet:text-[18px]">
            Can’t find what you need? Our team usually <br className="tablet:hidden" />
            replies within a few hours.
          </p>
          <a
            href="#cta"
            className="mt-9 inline-flex items-center gap-3 rounded-full border-[1.2px] border-white/30 px-[30px] py-[18px] text-[18px] leading-[normal] transition-colors hover:bg-white/8"
          >
            <span>Talk to the team</span>
            <b className="font-semibold">→</b>
          </a>
        </div>

        {/* native exclusive accordion: <details name="faq"> keeps one open at a time, no JS needed */}
        <div className="min-w-0 flex-1 tablet:w-full">
          {qas.map((qa, i) => (
            <details key={qa.q} name="faq" open={i === 0} className="group border-b border-white/14 first:border-t">
              <summary className="flex cursor-pointer list-none items-center justify-between gap-6 py-8 font-display text-[25px] font-medium tracking-[-0.5px] text-white tablet:py-6 tablet:text-[20px] [&::-webkit-details-marker]:hidden">
                {qa.q}
                <span
                  aria-hidden="true"
                  className="grid size-10 flex-none place-items-center rounded-full border-[1.2px] border-white/25 font-body text-[22px] font-medium text-white transition-colors group-open:border-accent group-open:bg-accent group-open:text-ink tablet:size-[34px] tablet:text-[20px]"
                >
                  <span className="group-open:hidden">+</span>
                  <span className="hidden group-open:inline">−</span>
                </span>
              </summary>
              <p className="-mt-3.5 max-w-[820px] pb-8 text-[20px] leading-[1.6] text-white/75 tablet:-mt-2 tablet:pb-6 tablet:text-[17px]">{qa.a}</p>
            </details>
          ))}
        </div>
      </div>
    </Section>
  );
}
