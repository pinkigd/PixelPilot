import { Workspace } from "@/components/mockups/Workspace";
import { Eyebrow } from "@/components/ui/Eyebrow";
import { Section } from "@/components/ui/Section";

export function CommandCenter() {
  return (
    <Section id="features" inner="h-[1042px] px-0 pt-[140px] pb-0 tablet:px-(--pad) tablet:pt-[88px] tablet:pb-24">
      <div className="flex flex-col items-center px-6 text-center tablet:px-0">
        <Eyebrow dotClassName="bg-[#932f28]">AI COMMAND CENTER</Eyebrow>
        <h2 className="mt-[18px] font-display text-[56px] leading-[1.06] font-medium tracking-[-1.68px] tablet:text-[length:clamp(34px,7.4vw,56px)]">
          Design with <span className="text-muted">conversation</span>.
        </h2>
        <p className="mt-5 text-[24px] text-white/85 tablet:text-[19px]">Make changes across every screen — without digging through layers.</p>
      </div>

      <Workspace tour />
    </Section>
  );
}
