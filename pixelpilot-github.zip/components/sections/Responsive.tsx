import { ResponsiveStage } from "@/components/mockups/ResponsiveStage";
import { ResponsiveFx } from "@/components/fx/SectionFx";
import { Eyebrow } from "@/components/ui/Eyebrow";
import { FitBox } from "@/components/ui/FitBox";
import { Dim, H2 } from "@/components/ui/H2";
import { Section } from "@/components/ui/Section";

export function Responsive() {
  return (
    <Section inner="h-[1094px] p-0 tablet:px-(--pad)">
      <div className="absolute top-[260px] left-10 w-[520px] tablet:static tablet:w-full">
        <Eyebrow data-rv>RESPONSIVE BY DEFAULT</Eyebrow>
        <H2 className="mt-[27px] tablet:mt-5" data-rv>
          One idea.
          <Dim>Every screen.</Dim>
        </H2>
        <p data-rv className="mt-8 text-[22px] leading-normal text-white/85 tablet:text-[19px]">
          Ask once. PixelPilot adapts layout, type <br className="tablet:hidden" />
          and spacing for every breakpoint.
        </p>

        <div data-rv className="mt-[39px] flex w-[500px] max-w-full items-center justify-between rounded-full border border-white/14 bg-card py-3.5 pr-3.5 pl-[22px] tablet:mt-7 tablet:p-2.5 tablet:pl-4">
          <div className="flex items-center gap-5 tablet:gap-3">
            <span className="grid size-9 place-items-center rounded-full bg-accent/12 text-[16px] font-semibold text-accent-soft tablet:size-[30px]">✦</span>
            <span data-prompt className="text-[21px] font-medium whitespace-nowrap text-white tablet:text-[16px] tablet:leading-tight tablet:whitespace-normal">
              <span data-ty-a>Make this mobile-first.</span>
              <i className="fx-caret" />
              <span data-ty-b className="fx-ghost" />
            </span>
          </div>
          <a
            href="#cta"
            aria-label="Apply"
            className="grid size-[62px] flex-none place-items-center rounded-full bg-accent text-[28px] font-semibold text-ink transition-transform hover:translate-x-0.5 tablet:size-[54px] tablet:text-[24px]"
          >
            <svg width="22" height="18" viewBox="0 0 22 18" fill="none" aria-hidden="true" className="tablet:size-[18px]">
              <path d="M1 9h19.5M12.5 1.5 20.5 9l-8 7.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </a>
        </div>

        <p data-meta className="mt-[34px] flex items-center gap-4 text-[18px] text-white/80 tablet:flex-wrap tablet:gap-x-3 tablet:gap-y-2 tablet:text-[16px]">
          <span className="inline-flex items-center">
            <svg width="14" height="11" viewBox="0 0 14 11" fill="none" aria-hidden="true" className="mr-[17px] ml-px">
              <path d="M1 5.8 4.8 9.6 13 1.4" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
            <span data-n>3</span>&nbsp;breakpoints updated
          </span>
          <i className="text-[14px] not-italic text-white/50">•</i>
          <span data-t>1.8s</span>
        </p>
      </div>

      <FitBox x={580} y={130} w={1100} h={820} className="tablet:mt-10 phone:h-auto">
        <ResponsiveStage />
      </FitBox>
      <ResponsiveFx />
    </Section>
  );
}
