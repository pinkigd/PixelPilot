"use client";

import { useEffect, useRef } from "react";
import { cachedText, easeInOut, easeOut, ramp, runFx, typer } from "@/components/fx/engine";

/** an empty marker element; the effect finds its `<section>` from it */
function useHost(setup: (host: HTMLElement) => (() => void) | void) {
  const ref = useRef<HTMLElement>(null);
  useEffect(() => {
    const host = ref.current?.closest<HTMLElement>("section");
    if (!host) return;
    return setup(host) ?? undefined;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  return <i ref={ref} hidden aria-hidden="true" />;
}

const q = <T extends HTMLElement = HTMLElement>(host: ParentNode, sel: string) => host.querySelector<T>(sel);
const qa = <T extends HTMLElement = HTMLElement>(host: ParentNode, sel: string) => Array.from(host.querySelectorAll<T>(sel));

/* ------------------------------------------------------------------------------------------------
 * THE NEW WAY — prompt is typed, chips pop in, "Generate interface" is pressed, the wireframe is
 * replaced by the generated dashboard (wipe + counters + chart draw).            loop 13s
 * ---------------------------------------------------------------------------------------------- */
export function SolutionFx() {
  return useHost((host) => {
    const prompt = q(host, "[data-prompt]");
    const ty = prompt ? typer(prompt) : null;
    const gen = q(host, ".gen");
    const wire = qa(host, ".wire__win > *");
    const stats = qa(host, ".stat");
    const vals = qa(host, ".stat__v");
    const persons = qa(host, ".person");
    const line = q<SVGPathElement & HTMLElement>(host, ".fx-line");
    const area = q(host, ".fx-area");
    const dots = q(host, ".fx-dots");
    const timeEl = q(host, "[data-time]");
    if (!gen || !ty || !line || !area || !dots || !timeEl || vals.length < 3) return;
    wire.forEach((el, i) => el.style.setProperty("--i", String(i)));
    qa(host, ".fx-pop").forEach((el, i) => el.style.setProperty("--i", String(i)));

    const targets = [48290, 23, 9840];
    const fmt = [(n: number) => `$${n.toLocaleString("en-US")}`, (n: number) => `${n}`, (n: number) => `+$${n.toLocaleString("en-US")}`];
    const orig = vals.map((v) => v.textContent ?? "");
    const writers = vals.map((v) => cachedText(v));
    const setTime = cachedText(timeEl);

    return runFx(host, {
      scope: "fx-sol",
      loop: 13,
      frame: (t) => {
        ty.set(t < 0.5 || t >= 12.4 ? 0 : Math.round(ramp(t, 0.5, 3.0) * ty.len));
        host.classList.toggle("fx-typing", t >= 0.4 && t < 3.3);
        host.classList.toggle("fx-wire", t >= 0.9 && t < 11.8);
        host.classList.toggle("fx-chips", t >= 3.3 && t < 11.8);
        host.classList.toggle("fx-glow", t >= 4.3 && t < 5.2);
        host.classList.toggle("fx-press", t >= 4.75 && t < 5.1);
        host.classList.toggle("fx-meta", t >= 5.2 && t < 11.8);

        // generated UI: wipe in from the left
        const p = t < 12.4 ? easeInOut(ramp(t, 5.0, 6.5)) : 0;
        const fade = 1 - ramp(t, 11.8, 12.4);
        gen.style.opacity = String(fade * (p > 0 ? 1 : 0));
        gen.style.transform = p >= 1 ? "" : `translateY(${((1 - p) * 26).toFixed(1)}px)`;
        gen.style.clipPath = p >= 1 ? "none" : `inset(0 ${((1 - p) * 100).toFixed(2)}% 0 0 round 28px)`;

        // counters, stat cards, chart, team rows
        const qv = t < 12.4 ? easeOut(ramp(t, 5.7, 7.2)) : 0;
        vals.forEach((_, i) => writers[i](qv >= 1 ? orig[i] : fmt[i](Math.round(targets[i] * qv))));
        stats.forEach((s, i) => {
          const a = easeOut(ramp(t, 5.6 + i * 0.18, 6.4 + i * 0.18));
          s.style.opacity = String(t < 12.4 ? a : 0);
          s.style.transform = a >= 1 ? "" : `translateY(${((1 - a) * 14).toFixed(1)}px)`;
        });
        line.style.strokeDashoffset = String(1 - (t < 12.4 ? easeInOut(ramp(t, 5.9, 7.8)) : 0));
        area.style.opacity = String(t < 12.4 ? ramp(t, 6.8, 8.0) : 0);
        dots.style.opacity = String(t < 12.4 ? ramp(t, 7.4, 8.2) : 0);
        persons.forEach((s, i) => {
          const a = easeOut(ramp(t, 7.0 + i * 0.22, 7.7 + i * 0.22));
          s.style.opacity = String(t < 12.4 ? a : 0);
          s.style.transform = a >= 1 ? "" : `translateX(${((1 - a) * 16).toFixed(1)}px)`;
        });
        setTime(`${(4.2 * ramp(t, 5.0, 7.0)).toFixed(1)}s`);
      },
      cleanup: () => {
        ty.restore();
        [gen, area, dots, line, ...stats, ...persons].forEach((el) => el.removeAttribute("style"));
        vals.forEach((v, i) => (v.textContent = orig[i]));
        timeEl.textContent = "4.2s";
      },
    });
  });
}

/* ------------------------------------------------------------------------------------------------
 * YOUR DESIGN SYSTEM — the Primary colour token changes, the connectors light up and the generated
 * Horizon site picks the new colour up live.                                      loop 12s
 * ---------------------------------------------------------------------------------------------- */
const PALETTE = [
  ["#FF7A59", "#f26a4b"],
  ["#5B8CFF", "#4a7bf0"],
  ["#3DD6A0", "#2fc28f"],
];

export function DesignSystemFx() {
  return useHost((host) => {
    const hex = q(host, ".tok span");
    const row = q(host, ".tok");
    const sync = q(host, ".tokens__sync");
    if (!hex || !row || !sync) return;
    const setHex = cachedText(hex);
    const setSync = cachedText(sync);
    let pal = -1;

    return runFx(host, {
      scope: "fx-ds",
      loop: 12,
      frame: (t) => {
        const k = Math.floor(t / 4);
        const u = t - k * 4;
        const next = (k + (u >= 0.9 ? 1 : 0)) % 3;
        if (next !== pal) {
          pal = next;
          host.style.setProperty("--ds-p", PALETTE[next][0]);
          host.style.setProperty("--ds-p2", PALETTE[next][1]);
          setHex(PALETTE[next][0]);
        }
        const syncing = u >= 0.7 && u < 1.9;
        host.classList.toggle("fx-sync", syncing);
        host.classList.toggle("fx-hit", u >= 1.0 && u < 2.1);
        row.classList.toggle("is-pick", u >= 0.2 && u < 1.5);
        setSync(syncing ? "Syncing…" : "Synced ✓");
      },
      cleanup: () => {
        hex.textContent = PALETTE[0][0];
        sync.textContent = "Synced ✓";
        row.classList.remove("is-pick");
      },
    });
  });
}

/* ------------------------------------------------------------------------------------------------
 * FROM IDEA TO INTERFACE — the four screens build up one after the other, the prototype link draws,
 * then a playhead cycles through the steps.                                       (build once, then live)
 * ---------------------------------------------------------------------------------------------- */
export function FlowFx() {
  return useHost((host) => {
    const phones = qa(host, ".ph");
    const steps = qa(host, "[data-step]");
    const bar = q(host, ".flowline");
    const link = q<SVGPathElement & HTMLElement>(host, ".fx-link");
    const head = q(host, ".fx-head");
    const tail = q(host, ".fx-tail");
    if (phones.length < 4 || steps.length < 4 || !link || !head || !tail) return;
    let built = false;

    return runFx(host, {
      scope: "fx-flow",
      frame: (t) => {
        const shown = built ? 4 : Math.min(4, Math.max(0, Math.floor((t - 0.3) / 0.95) + 1));
        for (let i = 0; i < 4; i++) host.classList.toggle(`fx-ph${i + 1}`, i < shown);
        const lp = built ? 1 : easeInOut(ramp(t, 4.6, 5.7));
        link.style.strokeDashoffset = String(1 - lp);
        head.style.opacity = String(ramp(lp, 0.85, 1));
        tail.style.opacity = String(ramp(lp, 0, 0.08));
        host.classList.toggle("fx-tag", built || t >= 5.4);
        if (t >= 6.4) built = true;

        const idx = built ? Math.floor((t - 6.4) / 2.2) % 4 : shown - 1;
        phones.forEach((p, i) => p.classList.toggle("is-live", built && i === idx));
        steps.forEach((s, i) => s.classList.toggle("is-act", built ? i === idx : i < shown));
        host.classList.toggle("fx-tap", built && idx === 3);
        if (bar) bar.style.transform = `scaleX(${(Math.max(0, idx) / 3).toFixed(3)})`;
      },
      cleanup: () => {
        [link, head, tail].forEach((el) => el.removeAttribute("style"));
        phones.forEach((p) => p.classList.remove("is-live"));
        steps.forEach((s) => s.classList.remove("is-act"));
        bar?.removeAttribute("style");
      },
    });
  });
}

/* ------------------------------------------------------------------------------------------------
 * RESPONSIVE BY DEFAULT — "Make this mobile-first." is typed and sent; desktop → tablet → mobile
 * are updated one after the other (flash, ✓ on the breakpoint label, counters).   loop 11s
 * ---------------------------------------------------------------------------------------------- */
export function ResponsiveFx() {
  return useHost((host) => {
    const prompt = q(host, "[data-prompt]");
    const ty = prompt ? typer(prompt) : null;
    const devs = [q(host, ".rsp__stage .rm--d"), q(host, ".rsp__stage .rm--t"), q(host, ".rsp__stage .rm--m")];
    const labels = qa(host, ".rsp__lbl");
    const nEl = q(host, "[data-n]");
    const tEl = q(host, "[data-t]");
    if (!ty || !nEl || !tEl || devs.some((d) => !d)) return;
    const labelTxt = labels.map((l) => l.textContent ?? "");
    const setN = cachedText(nEl);
    const setT = cachedText(tEl);
    const hits = [2.8, 3.4, 4.0];

    return runFx(host, {
      scope: "fx-rsp",
      loop: 11,
      frame: (t) => {
        ty.set(t < 0.5 || t >= 10.2 ? 0 : Math.round(ramp(t, 0.5, 2.0) * ty.len));
        host.classList.toggle("fx-typing", t >= 0.4 && t < 2.2);
        host.classList.toggle("fx-press", t >= 2.4 && t < 2.8);
        host.classList.toggle("fx-meta", t >= 2.5 && t < 9.9);
        let n = 0;
        devs.forEach((d, i) => {
          const on = t >= hits[i] && t < 9.9;
          host.classList.toggle(`fx-d${i + 1}`, on);
          d!.classList.toggle("is-hit", t >= hits[i] && t < hits[i] + 0.9);
          if (labels[i]) labels[i].textContent = on ? `${labelTxt[i]} ✓` : labelTxt[i];
          if (on) n++;
        });
        setN(String(n));
        setT(`${(1.8 * ramp(t, 2.6, 4.6)).toFixed(1)}s`);
      },
      cleanup: () => {
        ty.restore();
        devs.forEach((d) => d!.classList.remove("is-hit"));
        labels.forEach((l, i) => (l.textContent = labelTxt[i]));
        nEl.textContent = "3";
        tEl.textContent = "1.8s";
      },
    });
  });
}

/* ------------------------------------------------------------------------------------------------
 * PRICING — reveal / stagger is pure CSS (data-fx + data-in); this only arms the section.
 * ---------------------------------------------------------------------------------------------- */
export function PricingFx() {
  return useHost((host) => {
    qa(host, ".fx-card").forEach((card, c) => {
      card.style.setProperty("--c", String(c));
      qa(card, ".fx-li").forEach((li, i) => li.style.setProperty("--i", String(i)));
    });
    return runFx(host, { scope: "fx-pr" });
  });
}
