/**
 * Shared engine for the landing-page section animations (components/fx/*).
 *
 * `runFx` marks a section with `data-fx` (CSS then applies the "before" states), adds `data-in` the first time the section is
 * on screen (CSS reveals `[data-rv]` text, cards …) and, if a `frame` callback is given, runs it from one rAF loop while the
 * section is visible. Every visual state is written as a class / attribute / style on the server-rendered markup, so the static
 * design stays untouched without JS, with prefers-reduced-motion, and while the section is off-screen.
 */

export type FxOptions = {
  /** CSS scope class added to the host, e.g. "fx-sol" */
  scope: string;
  /** loop length in seconds (0 / undefined = the clock just keeps running) */
  loop?: number;
  frame?: (t: number, host: HTMLElement) => void;
  /** called when the effect is torn down, to undo inline styles */
  cleanup?: () => void;
};

export const clamp01 = (x: number) => Math.min(1, Math.max(0, x));
/** 0→1 progress of `t` between a and b */
export const ramp = (t: number, a: number, b: number) => clamp01((t - a) / (b - a));
export const easeOut = (x: number) => 1 - Math.pow(1 - x, 3);
export const easeInOut = (x: number) => (x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2);

export function runFx(host: HTMLElement, o: FxOptions): () => void {
  if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return () => {};

  host.classList.add(o.scope);
  host.setAttribute("data-fx", "");
  host.querySelectorAll<HTMLElement>("[data-rv]").forEach((el, i) => el.style.setProperty("--d", `${Math.min(i, 7) * 0.09}s`));

  let raf = 0;
  let running = false;
  let visible = false;
  let shown = false;
  let last = 0;
  let clock = 0;

  const tick = (now: number) => {
    if (!running) return;
    const dt = Math.min(0.1, (now - last) / 1000);
    last = now;
    clock += dt;
    if (o.loop) clock %= o.loop;
    o.frame?.(clock, host);
    raf = requestAnimationFrame(tick);
  };
  const start = () => {
    if (running || !visible || document.hidden || !o.frame) return;
    running = true;
    last = performance.now();
    o.frame(clock, host); // paint the right state before the first frame
    raf = requestAnimationFrame(tick);
  };
  const stop = () => {
    running = false;
    cancelAnimationFrame(raf);
  };

  const io = new IntersectionObserver(
    ([e]) => {
      visible = e.isIntersecting;
      host.classList.toggle("fx-live", visible);
      if (visible) {
        if (!shown) {
          shown = true;
          host.setAttribute("data-in", "");
        }
        start();
      } else stop();
    },
    { threshold: 0.2 },
  );
  io.observe(host);
  const vis = () => (document.hidden ? stop() : start());
  document.addEventListener("visibilitychange", vis);

  return () => {
    stop();
    io.disconnect();
    document.removeEventListener("visibilitychange", vis);
    o.cleanup?.();
    host.removeAttribute("data-fx");
    host.removeAttribute("data-in");
    host.style.removeProperty("--ds-p");
    host.style.removeProperty("--ds-p2");
    host.className = host.className
      .split(/\s+/)
      .filter((c) => c && !c.startsWith("fx-"))
      .join(" ");
    host.querySelectorAll<HTMLElement>("[data-rv]").forEach((el) => el.style.removeProperty("--d"));
  };
}

/** typewriter over `<span data-ty-a>full text</span><i class="fx-caret"/><span data-ty-b class="fx-ghost"/>` */
export function typer(root: HTMLElement) {
  const a = root.querySelector<HTMLElement>("[data-ty-a]");
  const b = root.querySelector<HTMLElement>("[data-ty-b]");
  if (!a || !b) return null;
  const full = a.textContent ?? "";
  let last = -2;
  return {
    len: full.length,
    set(n: number) {
      if (n === last) return;
      last = n;
      a.textContent = full.slice(0, n);
      b.textContent = full.slice(n);
    },
    restore() {
      a.textContent = full;
      b.textContent = "";
    },
  };
}

/** write text only when it changes */
export function cachedText(el: Element | null) {
  let last = el?.textContent ?? "";
  return (s: string) => {
    if (!el || s === last) return;
    last = s;
    el.textContent = s;
  };
}
