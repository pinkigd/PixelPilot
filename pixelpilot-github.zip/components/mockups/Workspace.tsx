import { WorkspaceTour } from "@/components/mockups/WorkspaceTour";
import { ZoomDiv } from "@/components/ui/ZoomDiv";
import avatars from "@/assets/cc-avatars.png";
import alps from "@/assets/cc-alps.jpg";
import dest from "@/assets/cc-dest.jpg";
import home from "@/assets/cc-home.jpg";
import me from "@/assets/cc-me.png";
import portrait from "@/assets/cc-portrait.png";
import thumb from "@/assets/cc-thumb.png";

/** photo crop that fills its `.photo` box (the box clips / rounds it; tour colour-grade filters sit on the box) */
function Pic({ src, w, h }: { src: string; w: number; h: number }) {
  // eslint-disable-next-line @next/next/no-img-element
  return <img src={src} width={w} height={h} alt="" draggable={false} style={{ display: "block", width: "100%", height: "100%", objectFit: "cover" }} />;
}

const Sq = () => (
  <svg width="10" height="10" viewBox="0 0 10 10" fill="none" aria-hidden="true">
    <rect x=".6" y=".6" width="8.8" height="8.8" rx="1.6" stroke="currentColor" strokeWidth="1.2" />
  </svg>
);

const Chev = ({ style }: { style?: React.CSSProperties }) => (
  <svg width="7" height="5" viewBox="0 0 7 5" fill="none" aria-hidden="true" style={style}>
    <path d="M.7.8 3.5 3.8 6.3.8" stroke="currentColor" strokeWidth="1.1" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

/** `tour` plays the looping "give it a command → every screen updates" animation (components/mockups/WorkspaceTour.tsx). */
export function Workspace({ tour = false }: { tour?: boolean }) {
  return (
    <>
      <ZoomDiv zoomW={1506} className="ws" aria-hidden="true" data-tour={tour ? "" : undefined}>
        <div className="ws__cam">
        <div className="ws__bar">
          <div className="ws__l">
            <div className="win__file">
              <i />
              Horizon App
              <Chev style={{ marginLeft: "-4px", marginTop: "7px" }} />
            </div>
            <div className="win__tools">
              <span className="win__tool is-on">➤</span>
              <span className="win__tool">⌘</span>
              <span className="win__tool">
                <svg width="14" height="14" viewBox="0 0 14 14" fill="none" aria-hidden="true">
                  <rect x=".8" y=".8" width="12.4" height="12.4" rx="2.6" stroke="currentColor" strokeWidth="1.6" />
                </svg>
              </span>
              <span className="win__tool">
                <svg width="28" height="28" viewBox="0 0 28 28" fill="none" aria-hidden="true">
                  <circle cx="14" cy="14" r="13" stroke="currentColor" strokeWidth="1.6" />
                </svg>
              </span>
              <span className="win__tool">T</span>
              <span className="win__tool">✎</span>
              <span className="win__tool">❍</span>
            </div>
          </div>
          <div className="win__right">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img className="avatars-img" src={avatars.src} width={87} height={37} alt="" draggable={false} />
            <div className="win__zoom">
              100%
              <Chev style={{ marginTop: "6px" }} />
            </div>
            <div className="win__share">Share</div>
          </div>
        </div>
        <aside className="ws__side">
          <div className="side__h">
            Pages <b>+</b>
          </div>
          <div className="side__i is-on">
            <em className="ic ic--pg">
              <svg width="11" height="12" viewBox="0 0 11 12" fill="none" aria-hidden="true">
                <rect x=".65" y=".65" width="9.7" height="10.7" stroke="currentColor" strokeWidth="1.3" />
                <path d="M.65 3.9h9.7M.65 6h9.7M.65 8.1h9.7" stroke="currentColor" strokeWidth="1.1" />
              </svg>
            </em>Design
          </div>
          <div className="side__i">
            <em className="ic ic--co">
              <svg width="12" height="12" viewBox="0 0 12 12" fill="none" aria-hidden="true">
                <circle cx="6" cy="6" r="5.2" stroke="currentColor" strokeWidth="1.5" />
                <circle cx="6" cy="6" r="2.9" stroke="currentColor" strokeWidth="1" />
              </svg>
            </em>Components
          </div>
          <div className="side__i">
            <em className="ic ic--ex">
              <svg width="15" height="15" viewBox="0 0 15 15" fill="none" aria-hidden="true">
                <path d="M7.5.9 14.1 7.5 7.5 14.1.9 7.5Z" stroke="currentColor" strokeWidth="1" strokeLinejoin="round" />
                <path d="M7.5 3.6 11.4 7.5 7.5 11.4 3.6 7.5Z" stroke="currentColor" strokeWidth=".9" strokeLinejoin="round" />
                <path d="M7.5 5.6 9.4 7.5 7.5 9.4 5.6 7.5Z" fill="currentColor" />
              </svg>
            </em>Explorations
          </div>
          <div className="side__gap" />
          <div className="side__h">Layers</div>
          <div className="side__i side__layer is-hot">
            <em>›</em>
            <em className="ic ic--sq">
              <Sq />
            </em>Home
          </div>
          <div className="side__i side__layer">
            <em>›</em>
            <em className="ic ic--sq">
              <Sq />
            </em>Search
          </div>
          <div className="side__i side__layer">
            <em>›</em>
            <em className="ic ic--sq">
              <Sq />
            </em>Destination
          </div>
          <div className="side__i side__layer">
            <em>›</em>
            <em className="ic ic--sq">
              <Sq />
            </em>Booking
          </div>
          <div className="side__i side__layer">
            <em>›</em>
            <em className="ic ic--sq">
              <Sq />
            </em>Profile
          </div>
          <div className="side__i side__layer">
            <em>›</em>
            <em className="ic ic--sq">
              <Sq />
            </em>Settings
          </div>
        </aside>
        <div className="ws__canvas">
          {tour && <i className="ws__sweep" />}
          {/* 01 Home */}
          <div className="scr">
            <p className="scr__lbl">{"01   Home"}</p>
            <span className="scr__tag">Updated</span>
            <div className="mini">
              <div className="mini__nav">
                <span className="a">☰</span>
                <span className="b">Horizon</span>
                <span className="c">⌕</span>
              </div>
              <div className="t h" style={{ left: "14px", top: "50px", fontWeight: "500", fontSize: "18px", lineHeight: "1.12" }}>
                Discover
                <br />
                extraordinary
                <br />
                places
              </div>
              <p className="t" style={{ left: "14px", top: "126px", fontSize: "9px", color: "rgba(255,255,255,.75)" }}>
                Plan smarter. Travel deeper.
              </p>
              <div className="photo" style={{ left: "-2px", top: "156px", width: "181px", height: "100px" }}>
                <Pic src={home.src} w={181} h={100} />
              </div>
              <div className="mini__tabs">
                <div style={{ left: "14px" }}>
                  ⌂<small>Home</small>
                </div>
                <div style={{ left: "58px" }}>
                  ◎<small>Explore</small>
                </div>
                <div style={{ left: "102px" }}>
                  ♡<small>Saved</small>
                </div>
                <div style={{ left: "146px" }}>
                  ⚇<small>Profile</small>
                </div>
              </div>
            </div>
          </div>
          {/* 02 Search */}
          <div className="scr">
            <p className="scr__lbl">{"02   Search"}</p>
            <span className="scr__tag">Updated</span>
            <div className="mini mini--alt">
              <div className="mini__nav">
                <span className="a">☰</span>
                <span className="b">Horizon</span>
                <span className="c">⌕</span>
              </div>
              <div className="t h" style={{ left: "10px", top: "48px", fontWeight: "500", fontSize: "15px", lineHeight: "1.18" }}>
                Find your
                <br />
                next destination
              </div>
              <div
                style={{
                  left: "10px",
                  top: "106px",
                  width: "157px",
                  height: "26px",
                  borderRadius: "13px",
                  background: "rgba(255,255,255,.06)",
                }}
              >
                <span
                  className="t"
                  style={{
                    position: "absolute",
                    left: "10px",
                    top: "8px",
                    fontSize: "8px",
                    color: "rgba(255,255,255,.6)",
                    whiteSpace: "pre",
                  }}
                >
                  {"⌕  Search destinations..."}
                </span>
              </div>
              <span
                className="t keep"
                style={{
                  left: "10px",
                  top: "142px",
                  background: "#fff",
                  color: "#151412",
                  fontSize: "7px",
                  padding: "5px 10px",
                  borderRadius: "999px",
                }}
              >
                All
              </span>
              <span
                className="t"
                style={{
                  left: "38px",
                  top: "142px",
                  border: "1px solid rgba(255,255,255,.15)",
                  fontSize: "7px",
                  padding: "5px 8px",
                  borderRadius: "999px",
                  color: "rgba(255,255,255,.8)",
                }}
              >
                Mountains
              </span>
              <span
                className="t"
                style={{
                  left: "84px",
                  top: "142px",
                  border: "1px solid rgba(255,255,255,.15)",
                  fontSize: "7px",
                  padding: "5px 8px",
                  borderRadius: "999px",
                  color: "rgba(255,255,255,.8)",
                }}
              >
                Beaches
              </span>
              <span
                className="t"
                style={{
                  left: "123px",
                  top: "142px",
                  border: "1px solid rgba(255,255,255,.15)",
                  fontSize: "7px",
                  padding: "5px 8px",
                  borderRadius: "999px",
                  color: "rgba(255,255,255,.8)",
                }}
              >
                Cities
              </span>
              <div style={{ left: "10px", top: "168px", width: "157px", height: "120px", borderRadius: "12px", overflow: "hidden" }}>
                <div className="photo" style={{ position: "absolute", inset: "0" }}>
                  <Pic src={alps.src} w={157} h={120} />
                </div>
                <span className="t" style={{ position: "absolute", left: "10px", top: "86px", fontWeight: "500", fontSize: "10px" }}>
                  Swiss Alps
                </span>
                <span
                  className="t"
                  style={{ position: "absolute", left: "10px", top: "101px", fontSize: "7px", color: "rgba(255,255,255,.7)" }}
                >
                  Switzerland
                </span>
                <b
                  style={{
                    position: "absolute",
                    left: "126px",
                    top: "88px",
                    width: "22px",
                    height: "22px",
                    borderRadius: "50%",
                    background: "#fff",
                    color: "#151412",
                    display: "grid",
                    placeItems: "center",
                    fontSize: "10px",
                  }}
                >
                  →
                </b>
              </div>
            </div>
          </div>
          {/* 03 Destination */}
          <div className="scr">
            <p className="scr__lbl">{"03   Destination"}</p>
            <span className="scr__tag">Updated</span>
            <div className="mini">
              <div className="mini__nav">
                <span className="a">☰</span>
                <span className="b">Horizon</span>
                <span className="c">⌕</span>
              </div>
              <div className="photo" style={{ left: "-2px", top: "34px", width: "181px", height: "133px" }}>
                <Pic src={dest.src} w={181} h={133} />
              </div>
              <p className="t h" style={{ left: "12px", top: "182px", fontWeight: "500", fontSize: "13px" }}>
                Lago di Braies
              </p>
              <p className="t" style={{ left: "12px", top: "201px", fontSize: "9px", color: "rgba(255,255,255,.7)" }}>
                Dolomites, Italy
              </p>
              <div
                style={{
                  left: "144px",
                  top: "178px",
                  width: "24px",
                  height: "24px",
                  borderRadius: "6px",
                  background: "rgba(255,255,255,.08)",
                  fontSize: "10px",
                  display: "grid",
                  placeItems: "center",
                }}
              >
                ⚑
              </div>
              <p className="t star" style={{ left: "12px", top: "222px", fontSize: "10px", color: "#f5c542" }}>
                ★
              </p>
              <p className="t" style={{ left: "26px", top: "223px", fontWeight: "500", fontSize: "9px" }}>
                4.8
              </p>
              <p className="t" style={{ left: "44px", top: "223px", fontSize: "9px", color: "rgba(255,255,255,.6)" }}>
                (2.4k)
              </p>
              <p
                style={{
                  left: "12px",
                  top: "246px",
                  fontSize: "8px",
                  lineHeight: "1.5",
                  color: "rgba(255,255,255,.75)",
                  whiteSpace: "nowrap",
                }}
              >
                A serene alpine lake surrounded
                <br />
                by majestic mountains.
              </p>
            </div>
          </div>
          {/* 04 Booking */}
          <div className="scr">
            <p className="scr__lbl">{"04   Booking"}</p>
            <span className="scr__tag">Updated</span>
            <div className="mini">
              <div className="mini__nav">
                <span className="a">☰</span>
                <span className="b">Horizon</span>
                <span className="c">⌕</span>
              </div>
              <p className="t h" style={{ left: "12px", top: "60px", fontWeight: "500", fontSize: "15px" }}>
                Your trip
              </p>
              <div style={{ left: "10px", top: "96px", width: "155px", height: "130px", borderRadius: "10px", overflow: "hidden" }}>
                <div
                  className="photo"
                  style={{ position: "absolute", left: "8px", top: "10px", width: "40px", height: "40px", borderRadius: "8px" }}
                >
                  <Pic src={thumb.src} w={40} h={40} />
                </div>
                <span className="t" style={{ position: "absolute", left: "56px", top: "14px", fontWeight: "500", fontSize: "9px" }}>
                  Lago di Braies
                </span>
                <span
                  className="t"
                  style={{ position: "absolute", left: "56px", top: "30px", fontSize: "8px", color: "rgba(255,255,255,.7)" }}
                >
                  Dolomites, Italy
                </span>
                <i
                  style={{
                    position: "absolute",
                    left: "0",
                    top: "58px",
                    width: "155px",
                    height: "1px",
                    background: "rgba(255,255,255,.08)",
                  }}
                />
                <span
                  className="t"
                  style={{
                    position: "absolute",
                    left: "10px",
                    top: "72px",
                    fontSize: "8px",
                    color: "rgba(255,255,255,.9)",
                    whiteSpace: "pre",
                  }}
                >
                  {"▦    Jun 12 – Jun 16, 2024"}
                </span>
                <i
                  style={{
                    position: "absolute",
                    left: "0",
                    top: "94px",
                    width: "155px",
                    height: "1px",
                    background: "rgba(255,255,255,.08)",
                  }}
                />
                <span
                  className="t"
                  style={{
                    position: "absolute",
                    left: "10px",
                    top: "108px",
                    fontSize: "8px",
                    color: "rgba(255,255,255,.9)",
                    whiteSpace: "pre",
                  }}
                >
                  {"⚇    2 travelers"}
                </span>
              </div>
            </div>
          </div>
          {/* 05 Profile */}
          <div className="scr">
            <p className="scr__lbl">{"05   Profile"}</p>
            <span className="scr__tag">Updated</span>
            <div className="mini">
              <div className="mini__nav">
                <span className="a">☰</span>
                <span className="b">Horizon</span>
                <span className="c">⌕</span>
              </div>
              <div className="photo" style={{ left: "56px", top: "66px", width: "64px", height: "64px", borderRadius: "50%" }}>
                <Pic src={portrait.src} w={64} h={64} />
              </div>
              <p className="t h" style={{ left: "63px", top: "140px", fontWeight: "500", fontSize: "12px" }}>
                Tara Sen
              </p>
              <p className="t" style={{ left: "57.5px", top: "158px", fontSize: "8px", color: "rgba(255,255,255,.7)" }}>
                tara@horizon.co
              </p>
              <div className="t" style={{ left: "19.5px", top: "186px", textAlign: "center" }}>
                <b style={{ display: "block", fontWeight: "500", fontSize: "11px" }}>12</b>
                <small style={{ fontSize: "7px", color: "rgba(255,255,255,.7)" }}>Trips</small>
              </div>
              <div className="t" style={{ left: "77.5px", top: "186px", textAlign: "center" }}>
                <b style={{ display: "block", fontWeight: "500", fontSize: "11px" }}>28</b>
                <small style={{ fontSize: "7px", color: "rgba(255,255,255,.7)" }}>Saved</small>
              </div>
              <div className="t" style={{ left: "132px", top: "186px", textAlign: "center" }}>
                <b style={{ display: "block", fontWeight: "500", fontSize: "11px" }}>4</b>
                <small style={{ fontSize: "7px", color: "rgba(255,255,255,.7)" }}>Countries</small>
              </div>
              <div
                style={{
                  left: "10px",
                  top: "226px",
                  width: "157px",
                  height: "26px",
                  borderRadius: "8px",
                  background: "rgba(255,255,255,.08)",
                  textAlign: "center",
                  fontWeight: "500",
                  fontSize: "9px",
                  lineHeight: "26px",
                }}
              >
                Edit profile
              </div>
            </div>
          </div>
          {/* 06 Settings */}
          <div className="scr">
            <p className="scr__lbl">{"06   Settings"}</p>
            <span className="scr__tag">Updated</span>
            <div className="mini">
              <div className="mini__nav">
                <span className="a">☰</span>
                <span className="b">Horizon</span>
                <span className="c">⌕</span>
              </div>
              <p className="t h" style={{ left: "12px", top: "56px", fontWeight: "500", fontSize: "15px" }}>
                Settings
              </p>
              <p className="t" style={{ left: "12px", top: "96px", fontSize: "9px", whiteSpace: "pre" }}>
                {"⚇  Account"}
              </p>
              <p className="t" style={{ left: "156px", top: "94px", fontSize: "11px", color: "rgba(255,255,255,.6)" }}>
                ›
              </p>
              <i style={{ left: "12px", top: "116px", width: "155px", height: "1px", background: "rgba(255,255,255,.07)" }} />
              <p className="t" style={{ left: "12px", top: "129px", fontSize: "9px", whiteSpace: "pre" }}>
                {"♫  Notifications"}
              </p>
              <p className="t" style={{ left: "156px", top: "127px", fontSize: "11px", color: "rgba(255,255,255,.6)" }}>
                ›
              </p>
              <i style={{ left: "12px", top: "149px", width: "155px", height: "1px", background: "rgba(255,255,255,.07)" }} />
              <p className="t" style={{ left: "12px", top: "162px", fontSize: "9px", whiteSpace: "pre" }}>
                {"◈  Appearance"}
              </p>
              <p className="t" style={{ left: "156px", top: "160px", fontSize: "11px", color: "rgba(255,255,255,.6)" }}>
                ›
              </p>
              <i style={{ left: "12px", top: "182px", width: "155px", height: "1px", background: "rgba(255,255,255,.07)" }} />
              <p className="t" style={{ left: "12px", top: "195px", fontSize: "9px", whiteSpace: "pre" }}>
                {"◍  Language"}
              </p>
              <p className="t" style={{ left: "156px", top: "193px", fontSize: "11px", color: "rgba(255,255,255,.6)" }}>
                ›
              </p>
              <i style={{ left: "12px", top: "215px", width: "155px", height: "1px", background: "rgba(255,255,255,.07)" }} />
              <p className="t" style={{ left: "12px", top: "228px", fontSize: "9px", whiteSpace: "pre" }}>
                {"⊡  Privacy"}
              </p>
              <p className="t" style={{ left: "156px", top: "226px", fontSize: "11px", color: "rgba(255,255,255,.6)" }}>
                ›
              </p>
            </div>
          </div>
        </div>
        <aside className="ws__ai">
          <div className="ai__head">
            <span className="ai__brand">
              <i />
              PixelPilot AI
            </span>
            <span>•••</span>
          </div>
          <p className="ai__sel">6 screens selected</p>
          <div className="ai__me">
            <p>Make the navigation 20% narrower.</p>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={me.src} width={40} height={40} alt="" draggable={false} />
          </div>
          <div className="ai__reply">
            <i>✦</i>
            <div>
              {tour && (
                <span className="ws__dots">
                  <i />
                  <i />
                  <i />
                </span>
              )}
              <p>
                Done. Navigation updated
                <br />
                across 6 screens.
              </p>
              <small>Width 1200 → 960px · 2.1s</small>
            </div>
          </div>
          <div className="ai__btns">
            <button className="undo">Undo</button>
            <button className="view">View changes</button>
          </div>
          <div className="ai__rule" />
          <p className="ai__try">Try another command</p>
          <div className="ai__chips">
            <span className="chip">Dark mode</span>
            <span className="chip">Mobile layout</span>
            <span className="chip">More editorial</span>
            <span className="chip">Increase contrast</span>
          </div>
          <div className="ai__input">
            <span>Ask PixelPilot...</span>
            <b>→</b>
          </div>
        </aside>
        {tour && <WorkspaceTour />}
        </div>
      </ZoomDiv>
    </>
  );
}
