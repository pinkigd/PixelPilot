import { ZoomDiv } from "@/components/ui/ZoomDiv";
import av from "@/assets/fl-av.png";
import hero from "@/assets/fl-hero.jpg";
import t1 from "@/assets/fl-t1.jpg";
import t2 from "@/assets/fl-t2.jpg";
import t3 from "@/assets/fl-t3.jpg";

/** photo crop that fills its (clipped / rounded) box */
function Pic({ src, w, h }: { src: string; w: number; h: number }) {
  // eslint-disable-next-line @next/next/no-img-element
  return <img src={src} width={w} height={h} alt="" draggable={false} style={{ display: "block", width: "100%", height: "100%", objectFit: "cover" }} />;
}

/** wireframe placeholder: 1px dashed outline (6 on / 4 off, like the design) */
function Dash({ x, y, w, h, r = 0, o }: { x: number; y: number; w: number; h: number; r?: number; o?: number }) {
  return (
    <svg className="dash" width={w} height={h} viewBox={`0 0 ${w} ${h}`} style={{ left: x, top: y, opacity: o }} aria-hidden="true">
      <rect x=".5" y=".5" width={w - 1} height={h - 1} rx={r} ry={r} fill="none" stroke="currentColor" strokeDasharray="6 4" strokeDashoffset="3" />
    </svg>
  );
}

/** bottom tab bar with line icons (home / search / saved / profile) */
function Tabs() {
  return (
    <div className="tabs">
      <span style={{ left: 40, top: 21 }}>
        <svg width="12" height="13" viewBox="0 0 12 13" fill="none" aria-hidden="true">
          <path d="M1.1 5.9 6 1.3l4.9 4.6v6H1.1Z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round" />
        </svg>
      </span>
      <span style={{ left: 108, top: 22 }}>
        <svg width="10" height="10" viewBox="0 0 10 10" fill="none" aria-hidden="true">
          <circle cx="6" cy="4" r="3" stroke="currentColor" strokeWidth="1.2" />
          <path d="M3.8 6.2 1 9" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" />
        </svg>
      </span>
      <span style={{ left: 176, top: 20 }}>
        <svg width="16" height="15" viewBox="0 0 16 15" fill="none" aria-hidden="true">
          <path
            d="M8 13.6S1 9.4 1 5.1C1 2.9 2.7 1.3 4.7 1.3c1.4 0 2.6.8 3.3 2 .7-1.2 1.9-2 3.3-2C13.3 1.3 15 2.9 15 5.1c0 4.3-7 8.5-7 8.5Z"
            stroke="currentColor"
            strokeWidth="1.4"
            strokeLinejoin="round"
          />
        </svg>
      </span>
      <span style={{ left: 245, top: 21 }}>
        <svg width="13" height="13" viewBox="0 0 13 13" fill="none" aria-hidden="true">
          <circle cx="6.5" cy="6.5" r="5.8" stroke="currentColor" strokeWidth="1.3" />
          <circle cx="4.6" cy="6" r="1" fill="currentColor" />
          <circle cx="8.4" cy="6" r="1" fill="currentColor" />
        </svg>
      </span>
    </div>
  );
}

function UiPhone({ proto = false }: { proto?: boolean }) {
  return (
    <ZoomDiv zoomW={300} zoomCols={2} className="ph ph--ui">
      <span className="time">9:41</span>
      <span className="logo logo--serif">Horizon</span>
      <i className="av photo">
        <Pic src={av.src} w={30} h={30} />
      </i>
      <i className="hero photo">
        <Pic src={hero.src} w={252} h={200} />
      </i>
      <span className="h">
        Discover extraordinary
        <br />
        places
      </span>
      <span className="search">{"⌕    Where do you want to go?"}</span>
      <span className="pop">Popular destinations</span>
      <i className="th photo" style={{ left: "22px" }}>
        <Pic src={t1.src} w={76} h={76} />
      </i>
      <i className="th photo" style={{ left: "110px" }}>
        <Pic src={t2.src} w={76} h={76} />
      </i>
      <i className="th photo" style={{ left: "198px" }}>
        <Pic src={t3.src} w={76} h={76} />
      </i>
      <Tabs />
      {proto && <i className="hotspot" />}
    </ZoomDiv>
  );
}

export function FlowPhones() {
  return (
    <>
      {/* 01 Wireframe */}
      <ZoomDiv zoomW={300} zoomCols={2} className="ph ph--wire">
        <Dash x={24} y={24} w={60} h={8} />
        <Dash x={22} y={60} w={84} h={14} />
        <Dash x={244} y={52} w={30} h={30} r={15} />
        <svg className="x" width="252" height="200" viewBox="0 0 252 200" aria-hidden="true">
          <defs>
            <clipPath id="flow-x-clip">
              <rect width="252" height="200" rx="20" ry="20" />
            </clipPath>
          </defs>
          <g clipPath="url(#flow-x-clip)" stroke="currentColor" strokeWidth="1" opacity=".55">
            <path d="M0 0 252 200M252 0 0 200" />
          </g>
          <rect x=".5" y=".5" width="251" height="199" rx="19.5" ry="19.5" fill="none" stroke="currentColor" strokeDasharray="6 4" strokeDashoffset="3" />
        </svg>
        <Dash x={22} y={324} w={200} h={13} o={0.75} />
        <Dash x={22} y={346} w={150} h={13} o={0.75} />
        <Dash x={22} y={378} w={230} h={6} o={0.75} />
        <Dash x={22} y={392} w={190} h={6} o={0.75} />
        <Dash x={22} y={400} w={252} h={46} r={23} />
        <Dash x={22} y={470} w={110} h={8} o={0.75} />
        <Dash x={22} y={492} w={76} h={76} r={12} />
        <Dash x={110} y={492} w={76} h={76} r={12} />
        <Dash x={198} y={492} w={76} h={76} r={12} />
        <i className="tabs" />
      </ZoomDiv>
      {/* 02 Structure */}
      <ZoomDiv zoomW={300} zoomCols={2} className="ph ph--struct">
        <span className="time">9:41</span>
        <span className="logo">Horizon</span>
        <i className="av" />
        <i className="hero" />
        <span className="h">
          Discover extraordinary
          <br />
          places
        </span>
        <span className="search">Where to?</span>
        <span className="pop">Popular destinations</span>
        <i className="th" style={{ left: "22px" }} />
        <i className="th" style={{ left: "110px" }} />
        <i className="th" style={{ left: "198px" }} />
        <Tabs />
      </ZoomDiv>
      {/* 03 UI */}
      <UiPhone />
      {/* 04 Prototype */}
      <UiPhone proto />
      <svg className="proto-link" width="330" height="140" viewBox="0 0 330 140" aria-hidden="true">
        <path
          className="fx-link"
          pathLength={1}
          d="M32.0 105.6 L36.9 109.1 L42.0 112.4 L47.2 115.5 L52.6 118.4 L58.0 121.1 L63.5 123.5 L69.2 125.8 L74.9 127.8 L80.7 129.6 L86.5 131.2 L92.4 132.5 L98.4 133.6 L104.3 134.5 L110.3 135.2 L116.3 135.6 L122.3 135.8 L128.3 135.8 L134.3 135.5 L140.3 135.1 L146.2 134.4 L152.0 133.5 L157.8 132.4 L163.6 131.1 L169.3 129.6 L174.9 127.9 L180.5 126.0 L186.0 124.0 L191.4 121.7 L196.8 119.4 L202.1 116.8 L207.3 114.1 L212.4 111.3 L217.5 108.3 L222.5 105.1 L227.5 101.8 L232.4 98.4 L237.2 94.9 L241.9 91.2 L246.6 87.4 L251.2 83.4 L255.7 79.4 L260.1 75.2 L264.4 70.9 L268.7 66.6 L272.8 62.1 L276.8 57.5 L280.7 52.8 L284.5 48.1 L288.1 43.2 L291.6 38.3 L295.0 33.3 L298.2 28.2 L301.3 23.1 L304.2 17.9 L307.0 12.6"
          fill="none"
          stroke="#ff4b3e"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path className="fx-tail" d="M44 103.1 32 105.6 34 117.5" fill="none" stroke="#ff4b3e" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        <path className="fx-head" d="M294 17.8 307 12.5 310 25.6" fill="none" stroke="#ff4b3e" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
      <span className="proto-tag">
        On tap
        <svg width="11" height="9" viewBox="0 0 11 9" fill="none" aria-hidden="true">
          <path d="M0 4.5h9.5M6.2 1l3.6 3.5L6.2 8" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
        Destination
      </span>
    </>
  );
}
