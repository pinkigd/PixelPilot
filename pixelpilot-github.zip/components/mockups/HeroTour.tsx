"use client";

import { useEffect, useRef } from "react";

/**
 * Scripted "product tour" for the hero window: a camera moves in 3D over the UI while a cursor selects the Image layer,
 * runs "Change the mood" and sends the prompt. Everything is driven from one rAF loop that only writes a few CSS
 * variables / data-attributes on the (server-rendered) window, so the static design stays untouched without JS,
 * with prefers-reduced-motion, and while the window is off-screen.
 */

const LOOP = 14.5; // seconds

type Pt = { x: number; y: number };
type CamKey = { t: number; at: string; s: number; rx: number; ry: number };
type CurKey = { t: number; at: string; dx?: number; dy?: number };

/** camera keyframes — `at` is an anchor name (see anchors()) */
const CAM: CamKey[] = [
  { t: 0, at: "center", s: 1, rx: 0, ry: 0 },
  { t: 1.3, at: "canvas", s: 1.07, rx: 4, ry: -6 },
  { t: 2.7, at: "layers", s: 1.75, rx: 3, ry: 8 },
  { t: 4.1, at: "layers", s: 1.75, rx: 3, ry: 8 },
  { t: 5.3, at: "photo", s: 1.4, rx: 1, ry: -5 },
  { t: 6.0, at: "photo", s: 1.4, rx: 1, ry: -5 },
  { t: 7.1, at: "ai", s: 1.8, rx: 2, ry: -9 },
  { t: 8.1, at: "ai", s: 1.8, rx: 2, ry: -9 },
  { t: 9.3, at: "canvas", s: 1.28, rx: 2, ry: 4 },
  { t: 10.1, at: "canvas", s: 1.28, rx: 2, ry: 4 },
  { t: 11.3, at: "center", s: 1.04, rx: 3, ry: -3 },
  { t: 12.8, at: "center", s: 1, rx: 0, ry: 0 },
  { t: LOOP, at: "center", s: 1, rx: 0, ry: 0 },
];

/** cursor keyframes */
const CUR: CurKey[] = [
  { t: 0, at: "start" },
  { t: 0.9, at: "start" },
  { t: 2.3, at: "layer1", dx: 40, dy: 2 },
  { t: 3.3, at: "layer4", dx: 40, dy: 2 },
  { t: 3.8, at: "layer4", dx: 40, dy: 2 },
  { t: 5.5, at: "photo", dx: 60, dy: -60 },
  { t: 6.1, at: "photo", dx: 60, dy: -60 },
  { t: 7.2, at: "mood", dx: 70, dy: 4 },
  { t: 7.9, at: "mood", dx: 70, dy: 4 },
  { t: 9.5, at: "send" },
  { t: 10.2, at: "send" },
  { t: 11.5, at: "exit" },
  { t: LOOP, at: "exit" },
];

/** click moments */
const CLICK_LAYER = 3.55;
const CLICK_MOOD = 7.7;
const CLICK_SEND = 9.85;
const RESET = 13.2;

const ease = (x: number) => (x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2);

function seg<T extends { t: number }>(keys: T[], t: number): [T, T, number] {
  for (let i = 0; i < keys.length - 1; i++) {
    if (t >= keys[i].t && t <= keys[i + 1].t) {
      const span = keys[i + 1].t - keys[i].t;
      return [keys[i], keys[i + 1], span > 0 ? ease((t - keys[i].t) / span) : 1];
    }
  }
  const last = keys[keys.length - 1];
  return [last, last, 1];
}

export function HeroTour() {
  const cursorRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const cur = cursorRef.current;
    const cam = cur?.closest<HTMLElement>(".tour__cam");
    const win = cam?.closest<HTMLElement>(".win");
    if (!cur || !cam || !win) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;

    let raf = 0;
    let running = false;
    let visible = false;
    let last = 0;
    let clock = 0;
    let anchors: Record<string, Pt> = {};
    let W = 0;
    let H = 0;

    const layers = Array.from(win.querySelectorAll<HTMLElement>(".side__layer"));
    const acts = Array.from(win.querySelectorAll<HTMLElement>(".ai__act"));
    const send = win.querySelector<HTMLElement>(".ai__prompt b");
    const photo = win.querySelector<HTMLElement>(".site__photo");
    const canvas = win.querySelector<HTMLElement>(".win__canvas");
    const ai = win.querySelector<HTMLElement>(".win__ai");
    if (!photo || !canvas || !ai || !send || layers.length < 7 || acts.length < 3) return;

    /** centre of an element in the camera's own coordinate space (unaffected by transforms / zoom) */
    const centre = (el: HTMLElement): Pt => {
      let x = 0;
      let y = 0;
      let n: HTMLElement | null = el;
      while (n && n !== cam) {
        x += n.offsetLeft;
        y += n.offsetTop;
        n = n.offsetParent as HTMLElement | null;
      }
      return { x: x + el.offsetWidth / 2, y: y + el.offsetHeight / 2 };
    };

    const measure = () => {
      W = cam.offsetWidth;
      H = cam.offsetHeight;
      const l1 = centre(layers[1]);
      const l4 = centre(layers[4]);
      const side = win.querySelector<HTMLElement>(".win__side");
      const sideBox = side ? centre(side) : { x: 130, y: 300 };
      anchors = {
        center: { x: W / 2, y: H / 2 },
        canvas: centre(canvas),
        photo: centre(photo),
        ai: centre(ai),
        layers: { x: sideBox.x + 60, y: (l1.y + l4.y) / 2 },
        layer1: { x: layers[1].offsetLeft + 70, y: l1.y },
        layer4: { x: layers[4].offsetLeft + 70, y: l4.y },
        mood: centre(acts[2]),
        send: centre(send),
        start: { x: W - 120, y: H - 70 },
        exit: { x: W + 40, y: H * 0.55 },
      };
    };

    // state that the loop toggles on the DOM (only when it changes)
    const st = { hl: -1, sel: false, mood: false, min: false, ripple: -1 };
    const setHover = (i: number) => {
      if (st.hl === i) return;
      layers.forEach((l, k) => l.classList.toggle("is-hover", k === i));
      st.hl = i;
    };
    const setSel = (on: boolean) => {
      if (st.sel === on) return;
      st.sel = on;
      layers[0].classList.toggle("is-hot", !on);
      layers[4].classList.toggle("is-hot", on);
      if (on) win.setAttribute("data-sel", "");
      else win.removeAttribute("data-sel");
    };
    const setFlag = (k: "mood" | "min", on: boolean) => {
      if (st[k] === on) return;
      st[k] = on;
      const attr = k === "mood" ? "data-mood" : "data-min";
      if (on) win.setAttribute(attr, "");
      else win.removeAttribute(attr);
      if (k === "mood") acts[2].classList.toggle("is-active", on);
    };

    const frame = (tt: number) => {
      // camera
      const [a, b, p] = seg(CAM, tt);
      const A = anchors[a.at];
      const B = anchors[b.at];
      const px = A.x + (B.x - A.x) * p;
      const py = A.y + (B.y - A.y) * p;
      const s = Math.exp(Math.log(a.s) + (Math.log(b.s) - Math.log(a.s)) * p);
      const rx = a.rx + (b.rx - a.rx) * p;
      const ry = a.ry + (b.ry - a.ry) * p;
      cam.style.transform = `translate(${W / 2}px, ${H / 2}px) rotateX(${rx}deg) rotateY(${ry}deg) scale(${s}) translate(${-px}px, ${-py}px)`;

      // cursor (lives inside the camera, so it is counter-scaled to stay a constant size)
      const [c0, c1, cp] = seg(CUR, tt);
      const C0 = anchors[c0.at];
      const C1 = anchors[c1.at];
      const cx = C0.x + (c0.dx ?? 0) + (C1.x + (c1.dx ?? 0) - C0.x - (c0.dx ?? 0)) * cp;
      const cy = C0.y + (c0.dy ?? 0) + (C1.y + (c1.dy ?? 0) - C0.y - (c0.dy ?? 0)) * cp;
      const clickAt = tt >= CLICK_SEND ? CLICK_SEND : tt >= CLICK_MOOD ? CLICK_MOOD : tt >= CLICK_LAYER ? CLICK_LAYER : -9;
      const age = tt - clickAt;
      const press = age >= 0 && age < 0.18 ? 0.88 : 1;
      cur.style.transform = `translate(${cx}px, ${cy}px) scale(${(press / s).toFixed(4)})`;
      cur.style.setProperty("--ck", age >= 0 && age < 0.6 ? (age / 0.6).toFixed(3) : "1");
      cur.style.opacity = tt < 0.7 || tt > 12.2 ? String(Math.max(0, Math.min(1, tt < 0.7 ? (tt - 0.4) / 0.3 : (12.4 - tt) / 0.2))) : "1";

      // states
      const resetting = tt >= RESET;
      setSel(tt >= CLICK_LAYER && !resetting);
      setFlag("mood", tt >= CLICK_MOOD && !resetting);
      setFlag("min", tt >= CLICK_SEND && !resetting);
      setHover(tt >= 2.1 && tt < 2.8 ? 1 : tt >= 2.85 && tt < CLICK_LAYER ? 4 : tt >= CLICK_LAYER && tt < 4.4 ? 4 : -1);
      acts[2].classList.toggle("is-hover", tt >= 7.0 && tt < CLICK_MOOD);
      send.classList.toggle("is-hover", tt >= 9.4 && tt < CLICK_SEND);
    };

    const tick = (now: number) => {
      if (!running) return;
      const dt = Math.min(0.1, (now - last) / 1000);
      last = now;
      clock = (clock + dt) % LOOP;
      frame(clock);
      raf = requestAnimationFrame(tick);
    };
    const start = () => {
      if (running || !visible || document.hidden) return;
      running = true;
      measure();
      last = performance.now();
      raf = requestAnimationFrame(tick);
    };
    const stop = () => {
      running = false;
      cancelAnimationFrame(raf);
    };

    const io = new IntersectionObserver(
      ([e]) => {
        visible = e.isIntersecting;
        if (visible) start();
        else stop();
      },
      { threshold: 0.15 },
    );
    io.observe(win);
    const vis = () => (document.hidden ? stop() : start());
    document.addEventListener("visibilitychange", vis);
    const ro = new ResizeObserver(() => running && measure());
    ro.observe(cam);
    document.fonts?.ready.then(() => running && measure());

    return () => {
      stop();
      io.disconnect();
      ro.disconnect();
      document.removeEventListener("visibilitychange", vis);
      cam.style.transform = "";
      win.removeAttribute("data-sel");
      win.removeAttribute("data-mood");
      win.removeAttribute("data-min");
    };
  }, []);

  return (
    <div ref={cursorRef} className="tour__cursor" aria-hidden="true">
      <i className="tour__ripple" />
      <svg width="26" height="30" viewBox="0 0 26 30" fill="none">
        <path d="M3 2v22.5l6.2-5.6 4.4 9.6 4.3-2-4.3-9.2h8.5L3 2Z" fill="#fff" stroke="#111" strokeWidth="1.8" strokeLinejoin="round" />
      </svg>
    </div>
  );
}
