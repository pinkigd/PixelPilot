import { Pic } from "@/components/mockups/Pic";
import { ZoomDiv } from "@/components/ui/ZoomDiv";
import c1 from "@/assets/vr-ex-c1.jpg";
import c2 from "@/assets/vr-ex-c2.jpg";
import c3 from "@/assets/vr-ex-c3.jpg";
import c4 from "@/assets/vr-ex-c4.jpg";
import rock from "@/assets/vr-ex-rock.jpg";
import { cn } from "@/lib/cn";

export function VariationExpressive({ picked = false }: { picked?: boolean }) {
  return (
    <>
      <ZoomDiv
        zoomW={515}
        className={cn(
          "vc vc--ex tablet:relative tablet:top-auto tablet:left-auto tablet:col-span-full tablet:w-[515px]",
          picked && "is-picked",
        )}
        aria-hidden="true"
      >
        <i className="blob" style={{ left: "-74px", top: "-150px", width: "260px", height: "260px", background: "#bfe0ff" }} />
        <i className="blob" style={{ left: "353px", top: "-85px", width: "210px", height: "210px", background: "#ffb1d8" }} />
        <i className="blob" style={{ left: "411px", top: "60px", width: "150px", height: "290px", transform: "rotate(12deg)", background: "#2f5bff" }} />
        <i className="blob" style={{ left: "151px", top: "322px", width: "385px", height: "300px", background: "#ff7a45" }} />
        <i className="blob" style={{ left: "351px", top: "480px", width: "250px", height: "250px", background: "#ffc2de" }} />
        <i className="rock photo">
          <Pic i={rock} />
        </i>
        <span className="lg">Horizon</span>
        <span className="nv" style={{ left: "148.5px" }}>
          Destinations
        </span>
        <span className="nv" style={{ left: "218.1px" }}>
          Experiences
        </span>
        <span className="nv" style={{ left: "275.6px" }}>
          About
        </span>
        <span style={{ left: "389.7px", top: "24.1px", fontSize: "13.9px" }}>⌕</span>
        <span className="si">Sign in</span>
        <div className="hd">
          Discover
          <br />
          extraordinary
          <br />
          places
        </div>
        <div className="sb">
          Plan smarter. Travel deeper.
          <br />
          Unforgettable experiences
          <br />
          around the world.
        </div>
        <div className="srch">
          <span>{"⌕   Where do you want to go?"}</span>
          <b>→</b>
        </div>
        <span className="btn-o">{"Explore destinations  →"}</span>
        <div className="gp">
          Good
          <br />
          Places
          <br />
          Brighter
          <br />
          You
        </div>
        <div className="dc" style={{ left: "27.8px" }}>
          <i className="photo">
            <Pic i={c1} />
          </i>
          <b>Swiss Alps</b>
          <small>Switzerland</small>
        </div>
        <div className="dc" style={{ left: "144.8px" }}>
          <i className="photo">
            <Pic i={c2} />
          </i>
          <b>Kyoto</b>
          <small>Japan</small>
        </div>
        <div className="dc" style={{ left: "261.7px" }}>
          <i className="photo">
            <Pic i={c3} />
          </i>
          <b>Santorini</b>
          <small>Greece</small>
        </div>
        <div className="dc" style={{ left: "378.6px" }}>
          <i className="photo">
            <Pic i={c4} />
          </i>
          <b>Banff</b>
          <small>Canada</small>
        </div>
      </ZoomDiv>
    </>
  );
}
