import { Seg } from "@/components/ui/Seg";

export function GenWindow() {
  return (
    <>
      <div className="gen tablet:top-[213px] tablet:left-[158px]" aria-hidden="true">
        <div className="gen__bar">
          <Seg />
          <span className="gen__badge">
            <i />
            Generated
          </span>
        </div>
        <div className="gen__body">
          <div className="rail">
            <span>▣</span>
            <span className="is-on">⌂</span>
            <span>▥</span>
            <span>▤</span>
            <span>⚇</span>
            <span>⚙</span>
          </div>
          <div className="gen__main">
            <div className="gen__top">
              <div>
                <p className="gen__hi">Good morning,</p>
                <p className="gen__title">Here’s your business at a glance.</p>
              </div>
              <span className="pill">{"Apr 1, 2024 – Sep 30, 2024   ⌄"}</span>
            </div>
            <div className="stats">
              <div className="stat">
                <span className="stat__ic">☰</span>
                <div>
                  <p className="stat__l">Revenue</p>
                  <p className="stat__v">$48,290</p>
                  <p className="stat__d">↑ +12.4%</p>
                </div>
              </div>
              <div className="stat">
                <span className="stat__ic">▤</span>
                <div>
                  <p className="stat__l">Open invoices</p>
                  <p className="stat__v">23</p>
                  <p className="stat__d is-muted">3 overdue</p>
                </div>
              </div>
              <div className="stat">
                <span className="stat__ic">≈</span>
                <div>
                  <p className="stat__l">Cash flow</p>
                  <p className="stat__v">+$9,840</p>
                  <p className="stat__d">↑ +8.1%</p>
                </div>
              </div>
            </div>
            <div className="lower">
              <div className="panel panel--chart">
                <div className="panel__h">
                  Cash flow — last 6 months <span className="pill">{"Monthly  ⌄"}</span>
                </div>
                <svg className="chart" viewBox="0 0 400 249" role="img" aria-label="Cash flow, last 6 months">
                  <defs>
                    <linearGradient id="areaFill" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0" stopColor="#ff4b3e" stopOpacity=".45" />
                      <stop offset="1" stopColor="#ff4b3e" stopOpacity="0" />
                    </linearGradient>
                  </defs>
                  <g stroke="rgba(255,255,255,.07)">
                    <path d="M40 8.5H400M40 80.8H400M40 153.2H400M40 225.5H400" />
                  </g>
                  <text x="0" y="12">
                    60K
                  </text>
                  <text x="0" y="84.3">
                    40K
                  </text>
                  <text x="0" y="156.7">
                    20K
                  </text>
                  <text x="0" y="229">
                    0
                  </text>
                  <text x="44" y="245">
                    Apr
                  </text>
                  <text x="108" y="245">
                    May
                  </text>
                  <text x="172" y="245">
                    Jun
                  </text>
                  <text x="236" y="245">
                    Jul
                  </text>
                  <text x="300" y="245">
                    Aug
                  </text>
                  <text x="364" y="245">
                    Sep
                  </text>
                  <path
                    className="fx-area"
                    fill="url(#areaFill)"
                    d="M50 177.2L76.4 170.8L102.8 164.2L129.2 146.9L155.6 116.5L182 105.7L208.4 116.5L234.8 142.5L261.2 138.2L287.6 105.7L314 77.4L347 68.8L380 55.7V225H50Z"
                  />
                  <path
                    className="fx-line"
                    pathLength={1}
                    fill="none"
                    stroke="#ee4d44"
                    strokeWidth="2"
                    strokeLinejoin="round"
                    d="M50 177.2L76.4 170.8L102.8 164.2L129.2 146.9L155.6 116.5L182 105.7L208.4 116.5L234.8 142.5L261.2 138.2L287.6 105.7L314 77.4L347 68.8L380 55.7"
                  />
                  <g className="fx-dots" fill="#ee4d44">
                    <circle cx="76.4" cy="170.8" r="3" />
                    <circle cx="102.8" cy="164.2" r="3" />
                    <circle cx="129.2" cy="146.9" r="3" />
                    <circle cx="155.6" cy="116.5" r="3" />
                    <circle cx="182" cy="105.7" r="3" />
                    <circle cx="208.4" cy="116.5" r="3" />
                    <circle cx="234.8" cy="142.5" r="3" />
                    <circle cx="261.2" cy="138.2" r="3" />
                    <circle cx="287.6" cy="105.7" r="3" />
                    <circle cx="314" cy="77.4" r="3" />
                    <circle cx="347" cy="68.8" r="3" />
                    <circle cx="380" cy="55.7" r="7" />
                  </g>
                </svg>
              </div>
              <div className="panel panel--team">
                <div className="panel__h">
                  Team activity <span>View all</span>
                </div>
                <div className="person">
                  <i className="person__av" />
                  <div className="person__b">
                    <b>Riya Sharma</b>
                    <span>Updated invoice #1024</span>
                  </div>
                  <em>2h ago</em>
                </div>
                <div className="person">
                  <i className="person__av" />
                  <div className="person__b">
                    <b>Arjun Mehta</b>
                    <span>Added a new client</span>
                  </div>
                  <em>5h ago</em>
                </div>
                <div className="person">
                  <i className="person__av" />
                  <div className="person__b">
                    <b>Neha Kapoor</b>
                    <span>Commented on dashboard</span>
                  </div>
                  <em>1d ago</em>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
