/** Plain (non-responsive) "03 UI" phone from the landing flow: 300 × 620, scaled by the caller. `hotspot` adds the prototype tap target. */
export function PhoneUI({ hotspot = false }: { hotspot?: boolean }) {
  return (
    <div className="ph ph--ui" aria-hidden="true">
      <span className="time">9:41</span>
      <span className="logo logo--serif">Horizon</span>
      <i className="av photo" style={{ background: "linear-gradient(135deg,#d6a58c,#5a4036)" }} />
      {/* TODO image: Photo / Mountains (Figma node 34:49) */}
      <i className="hero photo" />
      <span className="h">
        Discover extraordinary
        <br />
        places
      </span>
      <span className="search">{"⌕    Where do you want to go?"}</span>
      <span className="pop">Popular destinations</span>
      {/* TODO images: Thumb x3 (Figma nodes 34:54–34:56) */}
      <i className="th photo photo--blue" style={{ left: "22px" }} />
      <i className="th photo photo--red" style={{ left: "110px" }} />
      <i className="th photo photo--dusk" style={{ left: "198px" }} />
      <div className="tabs">
        <span style={{ left: "40px" }}>⌂</span>
        <span style={{ left: "108px" }}>⌕</span>
        <span style={{ left: "176px" }}>♡</span>
        <span style={{ left: "244px" }}>⚇</span>
      </div>
      {hotspot && <i className="hotspot" />}
    </div>
  );
}
