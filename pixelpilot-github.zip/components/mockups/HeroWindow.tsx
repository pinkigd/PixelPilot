import avatars from "@/assets/hero-avatars.png";
import photo from "@/assets/hero-photo.jpg";
import { HeroTour } from "@/components/mockups/HeroTour";
import { ZoomDiv } from "@/components/ui/ZoomDiv";
import { cn } from "@/lib/cn";

/** `className` lets a page reposition / resize the window (the Product hero uses a 560px-tall one). */
export function HeroWindow({ className, tour = false }: { className?: string; tour?: boolean }) {
  return (
    <>
      <ZoomDiv zoomW={1452} className={cn("win", className)} aria-hidden="true" data-tour={tour ? "" : undefined}>
        <div className="tour__cam">
        <div className="win__bar">
          <div className="win__file">
            <i />
            {"Travel App  ⌄"}
          </div>
          <div className="win__tools">
            <span className="win__tool is-on">➤</span>
            <span className="win__tool">⌘</span>
            <span className="win__tool">▢</span>
            <span className="win__tool">◯</span>
            <span className="win__tool">T</span>
            <span className="win__tool">✎</span>
            <span className="win__tool">❍</span>
          </div>
          <div className="win__right">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img className="avatars-img" src={avatars.src} width={87} height={37} alt="" />
            <div className="win__zoom">{"100%  ⌄"}</div>
            <div className="win__share">Share</div>
          </div>
        </div>
        <div className="win__body">
          <aside className="win__side">
            <div className="side__h">
              Pages <b>+</b>
            </div>
            <div className="side__i is-on">
              <em>▤</em>Design
            </div>
            <div className="side__i">
              <em>◎</em>Components
            </div>
            <div className="side__i">
              <em>◈</em>Explorations
            </div>
            <div className="side__gap" />
            <div className="side__h">Layers</div>
            <div className="side__i side__layer is-hot">
              <em>›</em>
              <em>▢</em>Hero
            </div>
            <div className="side__i side__layer">
              <em>›</em>
              <em>▢</em>Navigation
            </div>
            <div className="side__i side__layer">
              <em>›</em>
              <em>▢</em>Content
            </div>
            <div className="side__i side__layer">
              <em>›</em>
              <em>▢</em>Search
            </div>
            <div className="side__i side__layer">
              <em>›</em>
              <em>▢</em>Image
            </div>
            <div className="side__i side__layer">
              <em>›</em>
              <em>▢</em>Features
            </div>
            <div className="side__i side__layer">
              <em>›</em>
              <em>▢</em>Footer
            </div>
          </aside>
          <div className="win__canvas">
            <div className="site">
              <div className="site__nav">
                <span className="site__logo">Horizon</span>
                <span className="site__links">
                  <span>Destinations</span>
                  <span>Experiences</span>
                  <span>About</span>
                </span>
                <span className="site__right">
                  <span>⌕</span>
                  <span className="site__signup">Sign up</span>
                </span>
              </div>
              <div className="site__hero">
                {tour && <span className="tour__chip">Image · 398 × 333</span>}
                <div className="site__text">
                  <p className="site__eyebrow">EXPLORE A BRIGHTER TOMORROW</p>
                  <h3 className="site__h">
                    Discover
                    <br />
                    extraordinary
                    <br />
                    places
                  </h3>
                  <p className="site__p">
                    Plan smarter. Travel deeper. Unforgettable
                    <br />
                    journeys powered by people and AI.
                  </p>
                  <div className="site__search">
                    <span>{"⌕    Where do you want to go?"}</span>
                    <b>→</b>
                  </div>
                  <p className="site__pop">Popular destinations</p>
                </div>
                <div className="photo photo--round site__photo">
                  {/* Photo / Mountains — cropped from the supplied hero design */}
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={photo.src} width={398} height={333} alt="" />
                </div>
              </div>
            </div>
          </div>
          <aside className="win__ai">
            <div className="ai__head">
              <span className="ai__brand">
                <i />
                PixelPilot AI
              </span>
              <span>•••</span>
            </div>
            <div className="ai__prompt">
              <p>Make this section more minimal and modern</p>
              <b>↑</b>
            </div>
            <button className="ai__act">
              <em>✦</em>Generate alternatives
            </button>
            <button className="ai__act">
              <em>⇅</em>Adjust spacing
            </button>
            <button className="ai__act">
              <em>◈</em>Change the mood
            </button>
            <button className="ai__act">
              <em>≋</em>Apply to all screens
            </button>
            {tour && <div className="ai__toast">✦ Mood applied to 6 screens · 1.4s</div>}
          </aside>
        </div>
        {tour && <HeroTour />}
        </div>
      </ZoomDiv>
    </>
  );
}
