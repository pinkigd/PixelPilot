import { DesktopDevice, MobileDevice, TabletDevice } from "./Devices";

/**
 * Product "Every breakpoint" stage (Figma 65:219 / 65:253 / 65:293), 780 × 620.
 * The three Horizon mockups are the landing ones, zoomed down: desktop ×0.78, mobile ×0.82, tablet ×0.62
 * (the Figma frames are 670.8×475.8, 196.8×419.84 and 205.84×317.44).
 */
export function BreakpointStage() {
  const label =
    "absolute text-[15px] leading-[normal] font-medium text-white/60";
  return (
    <div className="fit relative" aria-hidden="true">
      <span className={label} style={{ left: 0, top: 0 }}>
        1440
      </span>
      <div className="absolute" style={{ left: 0, top: 28 }}>
        <DesktopDevice className="top-0 left-0 [zoom:0.78]" />
      </div>

      <span className={label} style={{ left: 580, top: 172 }}>
        390
      </span>
      <div className="absolute" style={{ left: 580, top: 198 }}>
        <MobileDevice className="top-0 left-0 [zoom:0.82]" />
      </div>

      <span className={label} style={{ left: 380, top: 262 }}>
        768
      </span>
      <div className="absolute" style={{ left: 380, top: 288 }}>
        <TabletDevice className="top-0 left-0 [zoom:0.62]" />
      </div>
    </div>
  );
}
