type Img = { src: string; width: number; height: number };

/** photo crop that fills its clipped / rounded `.photo` box */
export function Pic({ i }: { i: Img }) {
  // eslint-disable-next-line @next/next/no-img-element
  return <img src={i.src} width={i.width} height={i.height} alt="" draggable={false} style={{ display: "block", width: "100%", height: "100%", objectFit: "cover" }} />;
}
