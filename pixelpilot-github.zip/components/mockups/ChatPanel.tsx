"use client";

import { useState, type FormEvent } from "react";
import { cn } from "@/lib/cn";

type Turn = { user: string; reply: [string, string]; meta: string };

const DEFAULT: Turn = {
  user: "Make the navigation 20% narrower.",
  reply: ["Done. Navigation updated", "across 6 screens."],
  meta: "Width 1200 → 960px · 2.1s",
};

const COMMANDS: Record<string, Turn> = {
  "Dark mode": {
    user: "Switch to dark mode.",
    reply: ["Done. Dark theme applied", "across 6 screens."],
    meta: "12 tokens remapped · 1.9s",
  },
  "Mobile layout": {
    user: "Make this mobile-first.",
    reply: ["Done. Mobile layout built", "for 6 screens."],
    meta: "3 breakpoints · 2.4s",
  },
  "More editorial": {
    user: "Make it more editorial.",
    reply: ["Done. Type and spacing", "reworked on 6 screens."],
    meta: "Serif headings · 2.2s",
  },
  "Increase contrast": {
    user: "Increase the contrast.",
    reply: ["Done. Contrast raised to AA", "on 6 screens."],
    meta: "14 pairs fixed · 1.7s",
  },
};

/**
 * "AI chat panel" — Product (Figma 65:149 + backdrop 65:193, 560 × 690) and Features (70:1013, `wide`: 620 × 694).
 * Interactive: command chips run a canned command, the input accepts a prompt, Undo restores the first state.
 */
export function ChatPanel({ wide = false }: { wide?: boolean }) {
  const [turn, setTurn] = useState<Turn>(DEFAULT);
  const [active, setActive] = useState<string | null>(null);
  const [draft, setDraft] = useState("");

  const run = (name: string) => {
    setActive(name);
    setTurn(COMMANDS[name]);
  };
  const undo = () => {
    setActive(null);
    setTurn(DEFAULT);
  };
  const submit = (e: FormEvent) => {
    e.preventDefault();
    const text = draft.trim();
    if (!text) return;
    setActive(null);
    setTurn({
      user: text,
      reply: ["Done. Applied to the", "6 selected screens."],
      meta: "1 change · 2.0s",
    });
    setDraft("");
  };

  return (
    <div className="fit relative">
      <div className="absolute inset-0 rounded-[20px] border border-white/7 bg-[#161413]" />
      <div
        className={cn(
          "absolute top-5 flex w-[520px] flex-col overflow-hidden rounded-[20px] border border-white/12 p-[26px] text-[14px] leading-[normal]",
          // Features frame: 620×694 backdrop with the 654px panel centred in it; Product frame: 560×690, 648px panel
          wide ? "left-[50px] h-[654px]" : "left-10 h-[648px]",
        )}
      >
        <div className="flex items-center justify-between">
          <span className="flex items-center gap-3 text-[20px] font-medium text-white">
            <i className="size-[15px] rounded-full bg-[#c4382d]" />
            PixelPilot AI
          </span>
          <span className="text-white/80">•••</span>
        </div>
        <p className="pt-2 pl-[27px] text-white/70">6 screens selected</p>

        <div className="mt-10 flex items-center justify-end gap-3">
          <p
            className="rounded-xl bg-white/10 px-3.5 py-3 whitespace-nowrap text-white"
            aria-live="polite"
          >
            {turn.user}
          </p>
          <i className="portrait size-10 flex-none rounded-full" />
        </div>

        <div className="mt-[30px] flex items-start gap-[18px] whitespace-nowrap">
          <span className="text-[24px] text-accent-soft">✦</span>
          <div className="flex flex-col gap-3">
            <p className="text-[16px] leading-[1.5] text-white">
              {turn.reply[0]}
              <br />
              {turn.reply[1]}
            </p>
            <p className="text-white/75">{turn.meta}</p>
          </div>
        </div>

        <div className="mt-6 flex gap-2.5 pl-10 text-[15px] leading-[normal]">
          <button
            type="button"
            onClick={undo}
            className="w-24 rounded-full border border-white/25 py-[15px] text-center font-medium text-white transition-colors hover:bg-white/8"
          >
            Undo
          </button>
          <button
            type="button"
            className="flex-1 rounded-full bg-white py-[15px] text-center font-semibold text-ink transition-transform hover:-translate-y-px"
          >
            View changes
          </button>
        </div>

        <i className="mt-8 block h-px w-full bg-white/10" />

        <p className="mt-7 text-white/75">Try another command</p>
        <div className="mt-3.5 flex flex-wrap gap-x-2.5 gap-y-3">
          {Object.keys(COMMANDS).map((name) => (
            <button
              key={name}
              type="button"
              aria-pressed={active === name}
              onClick={() => run(name)}
              className={cn(
                "rounded-full border px-6 py-[13px] text-[15px] leading-none font-medium whitespace-nowrap text-white transition-colors",
                active === name
                  ? "border-accent/60 bg-accent/12"
                  : "border-white/12 bg-white/6 hover:border-white/30",
              )}
            >
              {name}
            </button>
          ))}
        </div>

        <form
          onSubmit={submit}
          className="mt-9 flex items-center justify-between rounded-full border border-white/12 bg-white/5 py-2 pr-2 pl-[22px]"
        >
          <input
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            placeholder="Ask PixelPilot..."
            aria-label="Ask PixelPilot"
            className="min-w-0 flex-1 bg-transparent text-[15px] text-white outline-none placeholder:text-white/70"
          />
          <button
            type="submit"
            aria-label="Send"
            className="grid size-[42px] flex-none place-items-center rounded-full bg-accent text-[18px] font-semibold text-ink"
          >
            →
          </button>
        </form>
      </div>
    </div>
  );
}
