/**
 * Enterprise illustration: three nested shields + a check (Figma 66:419–66:422), 640 × 440.
 * TODO: the original vector layers couldn't be downloaded in this environment, so these are hand-drawn
 * stand-ins at the same positions / sizes — export the 3 "Shield" + "Check" vectors from Figma to replace them.
 */
function shield(x: number, y: number, w: number, h: number) {
  const X = (n: number) => +(x + n * w).toFixed(2);
  const Y = (n: number) => +(y + n * h).toFixed(2);
  return [
    `M${X(0.5)} ${Y(0)}`,
    `L${X(1)} ${Y(0.155)}`,
    `V${Y(0.54)}`,
    `C${X(1)} ${Y(0.78)} ${X(0.74)} ${Y(0.92)} ${X(0.5)} ${Y(1)}`,
    `C${X(0.26)} ${Y(0.92)} ${X(0)} ${Y(0.78)} ${X(0)} ${Y(0.54)}`,
    `V${Y(0.155)}`,
    "Z",
  ].join(" ");
}

export function ShieldArt() {
  return (
    <svg
      className="fit block"
      viewBox="0 0 640 440"
      fill="none"
      aria-hidden="true"
    >
      <g
        stroke="rgba(255,255,255,0.12)"
        strokeWidth="1.5"
        strokeLinejoin="round"
      >
        <path d={shield(1, 1, 358, 438)} />
        <path d={shield(251, 51, 278.8, 341.2)} />
        <path d={shield(421, 81, 214, 262)} />
      </g>
      <path
        d="M126 232 L168 270 L238 188"
        stroke="rgba(255,255,255,0.15)"
        strokeWidth="9"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}
