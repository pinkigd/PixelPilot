import { DesktopDevice, MobileDevice, TabletDevice } from "./Devices";

export function ResponsiveStage() {
  return (
    <div className="fit rsp__stage phone:mx-auto phone:h-[512px] phone:w-[240px] phone:[zoom:1]" aria-hidden="true">
      <i className="rsp__vdiv phone:hidden" />
      <span className="rsp__lbl phone:hidden" style={{ left: "239px", top: "10px" }}>
        1440
      </span>
      <DesktopDevice className="phone:hidden" />
      <span className="rsp__lbl phone:hidden" style={{ left: "0", top: "262px" }}>
        768
      </span>
      <TabletDevice className="phone:hidden" />
      <span className="rsp__lbl phone:hidden" style={{ left: "830px", top: "254px" }}>
        390
      </span>
      <MobileDevice className="phone:top-0 phone:left-0" />
    </div>
  );
}
