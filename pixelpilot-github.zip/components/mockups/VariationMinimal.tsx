import { Pic } from "@/components/mockups/Pic";
import { ZoomDiv } from "@/components/ui/ZoomDiv";
import th1 from "@/assets/vr-min-th1.jpg";
import th2 from "@/assets/vr-min-th2.jpg";
import th3 from "@/assets/vr-min-th3.jpg";
import th4 from "@/assets/vr-min-th4.jpg";
import hero from "@/assets/vr-min-hero.jpg";
import { cn } from "@/lib/cn";

export function VariationMinimal({ picked = false }: { picked?: boolean }) {
  return (
    <>
      <ZoomDiv
        zoomW={515}
        className={cn(
          "vc vc--min tablet:relative tablet:top-auto tablet:left-auto tablet:col-span-full tablet:w-[515px]",
          picked && "is-picked",
        )}
        aria-hidden="true"
      >
        <span className="lg">Horizon</span>
        <span className="nv" style={{ left: "146.6px" }}>
          Destinations
        </span>
        <span className="nv" style={{ left: "216.2px" }}>
          Experiences
        </span>
        <span className="nv" style={{ left: "290.4px" }}>
          About
        </span>
        <span style={{ left: "387.9px", top: "24px", fontSize: "13.9px" }}>⌕</span>
        <span className="si">Sign in</span>
        <span className="eb">TRAVEL FURTHER</span>
        <div className="hd">
          Discover
          <br />
          extraordinary
          <br />
          places
        </div>
        <div className="sb">
          Plan smarter. Travel deeper.
          <br />
          Unforgettable experiences
          <br />
          around the world.
        </div>
        <div className="srch">
          <span>{"⌕   Where do you want to go?"}</span>
        </div>
        <span className="btn-o">{"Explore destinations  →"}</span>
        <i className="hero photo">
          <Pic i={hero} />
        </i>
        <div className="cap">
          A quieter
          <br />
          kinder world
        </div>
        <i className="th photo" style={{ left: "29.7px" }}>
          <Pic i={th1} />
        </i>
        <span className="ct" style={{ left: "29.7px" }}>
          Swiss Alps
        </span>
        <small className="s" style={{ left: "29.7px" }}>
          Switzerland
        </small>
        <i className="th photo" style={{ left: "146.6px" }}>
          <Pic i={th2} />
        </i>
        <span className="ct" style={{ left: "146.6px" }}>
          Kyoto
        </span>
        <small className="s" style={{ left: "146.6px" }}>
          Japan
        </small>
        <i className="th photo" style={{ left: "263.5px" }}>
          <Pic i={th3} />
        </i>
        <span className="ct" style={{ left: "263.5px" }}>
          Santorini
        </span>
        <small className="s" style={{ left: "263.5px" }}>
          Greece
        </small>
        <i className="th photo" style={{ left: "380.5px" }}>
          <Pic i={th4} />
        </i>
        <span className="ct" style={{ left: "380.5px" }}>
          Banff
        </span>
        <small className="s" style={{ left: "380.5px" }}>
          Canada
        </small>
      </ZoomDiv>
    </>
  );
}
