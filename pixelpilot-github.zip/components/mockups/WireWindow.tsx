export function WireWindow() {
  return (
    <>
      <div className="wire tablet:top-0 tablet:left-0" aria-hidden="true">
        <div className="wire__win">
          <i className="wire__sq" />
          <span className="wire__t">Wireframe</span>
          <i className="wire__d" style={{ left: "399px" }} />
          <i className="wire__d" style={{ left: "419px" }} />
          <i className="wire__d" style={{ left: "439px" }} />
          <i className="wire__ic" style={{ top: "69px" }} />
          <i className="wire__ic" style={{ top: "109px" }} />
          <i className="wire__ic" style={{ top: "149px" }} />
          <i className="wire__ic" style={{ top: "189px" }} />
          <i className="wire__box" style={{ left: "63px", top: "63px", width: "124px", height: "60px" }} />
          <i className="wire__box" style={{ left: "199px", top: "63px", width: "124px", height: "60px" }} />
          <i className="wire__box" style={{ left: "335px", top: "63px", width: "120px", height: "60px" }} />
          <i className="wire__box" style={{ left: "63px", top: "139px", width: "392px", height: "160px" }} />
        </div>
      </div>
    </>
  );
}
