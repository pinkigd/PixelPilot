import { Pic } from "@/components/mockups/Pic";
import { ZoomDiv } from "@/components/ui/ZoomDiv";
import band from "@/assets/vr-ed-band.jpg";
import { cn } from "@/lib/cn";

export function VariationEditorial({ picked = false }: { picked?: boolean }) {
  return (
    <>
      <ZoomDiv
        zoomW={515}
        className={cn(
          "vc vc--ed tablet:relative tablet:top-auto tablet:left-auto tablet:col-span-full tablet:w-[515px]",
          picked && "is-picked",
        )}
        aria-hidden="true"
      >
        <span className="lg">Horizon</span>
        <span className="nv" style={{ left: "157.3px" }}>
          Destinations
        </span>
        <span className="nv" style={{ left: "232.3px" }}>
          Experiences
        </span>
        <span className="nv" style={{ left: "311px" }}>
          About
        </span>
        <span style={{ left: "390.6px", top: "33.9px", fontSize: "13.7px" }}>⌕</span>
        <span className="si">Sign in</span>
        <span className="eb">TRAVEL FURTHER</span>
        <div className="hd">
          Discover
          <br />
          extraordinary
          <br />
          places
        </div>
        <div className="sb">
          Plan smarter. Travel deeper.
          <br />
          Unforgettable experiences
          <br />
          around the world.
        </div>
        <i className="cover" />
        <i className="phx">
          <Pic i={band} />
        </i>
        <div className="srch">
          <span>{"⌕   Where do you want to go?"}</span>
          <b>→</b>
        </div>
        <span className="ct" style={{ left: "38.4px" }}>
          Swiss Alps
        </span>
        <small className="s" style={{ left: "38.4px" }}>
          Switzerland
        </small>
        <span className="ct" style={{ left: "164.7px" }}>
          Kyoto
        </span>
        <small className="s" style={{ left: "164.7px" }}>
          Japan
        </small>
        <i className="vl" style={{ left: "151.9px" }} />
        <span className="ct" style={{ left: "290.9px" }}>
          Santorini
        </span>
        <small className="s" style={{ left: "290.9px" }}>
          Greece
        </small>
        <i className="vl" style={{ left: "278.1px" }} />
        <span className="ct" style={{ left: "417.1px" }}>
          Banff
        </span>
        <small className="s" style={{ left: "417.1px" }}>
          Canada
        </small>
        <i className="vl" style={{ left: "404.3px" }} />
      </ZoomDiv>
    </>
  );
}
