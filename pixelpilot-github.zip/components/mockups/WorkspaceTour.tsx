"use client";

import { useEffect, useRef } from "react";

/**
 * "Design with conversation" loop for the AI Command Center dashboard.
 * A cursor clicks two suggestion chips ("More editorial", "Increase contrast"); the AI panel thinks and answers, and a
 * glowing sweep runs across the canvas flipping the six screens one column at a time while the layer list pings and the
 * "Updated" tags pop back in. A 3D camera follows the action. One rAF loop; every state is a pure function of the loop
 * time and is written as classes / data-attributes on the server-rendered mockup, so the static design is untouched
 * without JS, with prefers-reduced-motion, and while the mockup is off-screen.
 */

const LOOP = 16;

type Pt = { x: number; y: number };
type CamKey = { t: number; at: string; s: number; rx: number; ry: number };
type CurKey = { t: number; at: string; dx?: number; dy?: number };

const CAM: CamKey[] = [
  { t: 0, at: "center", s: 1, rx: 0, ry: 0 },
  { t: 0.9, at: "center", s: 1.04, rx: 2, ry: -3 },
  { t: 2.3, at: "ai", s: 1.75, rx: 2, ry: -9 },
  { t: 3.0, at: "ai", s: 1.75, rx: 2, ry: -9 },
  { t: 4.4, at: "canvas", s: 1.3, rx: 3, ry: 5 },
  { t: 6.3, at: "canvas", s: 1.38, rx: 2, ry: 3 },
  { t: 7.6, at: "ai", s: 1.75, rx: 2, ry: -9 },
  { t: 8.7, at: "ai", s: 1.75, rx: 2, ry: -9 },
  { t: 9.9, at: "canvas", s: 1.3, rx: 3, ry: 5 },
  { t: 12.0, at: "canvas", s: 1.2, rx: 2, ry: 2 },
  { t: 13.3, at: "center", s: 1, rx: 0, ry: 0 },
  { t: LOOP, at: "center", s: 1, rx: 0, ry: 0 },
];

const CUR: CurKey[] = [
  { t: 0, at: "start" },
  { t: 1.0, at: "start" },
  { t: 2.4, at: "chip2", dx: 12, dy: 4 },
  { t: 3.0, at: "chip2", dx: 12, dy: 4 },
  { t: 4.8, at: "canvas", dx: -120, dy: -30 },
  { t: 6.4, at: "canvas", dx: -120, dy: -30 },
  { t: 7.9, at: "chip3", dx: 14, dy: 4 },
  { t: 8.7, at: "chip3", dx: 14, dy: 4 },
  { t: 10.4, at: "canvas", dx: 120, dy: 40 },
  { t: 11.7, at: "canvas", dx: 120, dy: 40 },
  { t: 12.8, at: "exit" },
  { t: LOOP, at: "exit" },
];

const CLICK1 = 2.75;
const CLICK2 = 8.3;
const THINK = 1.0;
const SWEEP1 = { t: 3.85, d: 1.5 };
const SWEEP2 = { t: 9.45, d: 1.4 };
const RESET = 13.5;
const BAND = 220;
const FLASH = 0.7;

const TEXT = [
  null, // original copy is read from the DOM
  { me: "Make it more editorial.", p: "Done. Typography updated<br>across 6 screens.", s: "Serif headlines · 1.8s" },
  { me: "Increase contrast.", p: "Done. Contrast raised<br>across 6 screens.", s: "WCAG AA → AAA · 1.6s" },
];

const ease = (x: number) => (x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2);

function seg<T extends { t: number }>(keys: T[], t: number): [T, T, number] {
  for (let i = 0; i < keys.length - 1; i++) {
    if (t >= keys[i].t && t <= keys[i + 1].t) {
      const span = keys[i + 1].t - keys[i].t;
      return [keys[i], keys[i + 1], span > 0 ? ease((t - keys[i].t) / span) : 1];
    }
  }
  const last = keys[keys.length - 1];
  return [last, last, 1];
}

export function WorkspaceTour() {
  const cursorRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const cur = cursorRef.current;
    const cam = cur?.closest<HTMLElement>(".ws__cam");
    const ws = cam?.closest<HTMLElement>(".ws");
    if (!cur || !cam || !ws) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;

    const scrs = Array.from(ws.querySelectorAll<HTMLElement>(".scr"));
    const layers = Array.from(ws.querySelectorAll<HTMLElement>(".side__layer"));
    const chips = Array.from(ws.querySelectorAll<HTMLElement>(".ai__chips .chip"));
    const canvas = ws.querySelector<HTMLElement>(".ws__canvas");
    const sweep = ws.querySelector<HTMLElement>(".ws__sweep");
    const meP = ws.querySelector<HTMLElement>(".ai__me p");
    const replyP = ws.querySelector<HTMLElement>(".ai__reply p");
    const replyS = ws.querySelector<HTMLElement>(".ai__reply small");
    const reply = ws.querySelector<HTMLElement>(".ai__reply");
    const view = ws.querySelector<HTMLElement>(".ai__btns .view");
    if (!canvas || !sweep || !meP || !replyP || !replyS || !reply || !view || scrs.length < 6 || chips.length < 4 || layers.length < 6) return;

    const orig = { me: meP.innerHTML, p: replyP.innerHTML, s: replyS.innerHTML };

    let raf = 0;
    let running = false;
    let visible = false;
    let last = 0;
    let clock = 0;
    let anchors: Record<string, Pt> = {};
    let W = 0;
    let H = 0;
    let canvasW = 0;
    let cx: number[] = []; // screen centres along the canvas (for the sweep)

    /** centre of an element in the camera's own coordinate space (unaffected by transforms / zoom) */
    const centre = (el: HTMLElement): Pt => {
      let x = 0;
      let y = 0;
      let n: HTMLElement | null = el;
      while (n && n !== cam) {
        x += n.offsetLeft;
        y += n.offsetTop;
        n = n.offsetParent as HTMLElement | null;
      }
      return { x: x + el.offsetWidth / 2, y: y + el.offsetHeight / 2 };
    };

    const measure = () => {
      W = cam.offsetWidth;
      H = cam.offsetHeight;
      canvasW = canvas.offsetWidth;
      cx = scrs.map((s) => s.offsetLeft + s.offsetWidth / 2);
      const rc = centre(reply);
      const c2 = centre(chips[2]);
      const c3 = centre(chips[3]);
      const cv = centre(canvas);
      anchors = {
        center: { x: W / 2, y: H / 2 },
        canvas: { x: cv.x - 20, y: cv.y - 40 },
        ai: { x: c2.x, y: (rc.y + c3.y) / 2 + 20 },
        chip2: c2,
        chip3: c3,
        start: { x: W - 50, y: H - 50 },
        exit: { x: W + 40, y: H * 0.6 },
      };
    };

    /** time at which the sweep's leading edge reaches screen i */
    const flipAt = (sw: { t: number; d: number }, i: number) => sw.t + Math.min(1, cx[i] / (canvasW + BAND)) * sw.d;

    // cached DOM state (only touched when it changes)
    const st = {
      scr: scrs.map(() => ({ ed: false, ct: false, flash: false, tag: true })),
      ping: layers.map(() => false),
      chipHover: [false, false],
      chipActive: [false, false],
      text: 0,
      think: false,
      pop: false,
      live: false,
      glow: false,
      sweepOn: false,
    };
    const flag = (el: HTMLElement, cls: string, on: boolean) => el.classList.toggle(cls, on);

    const frame = (tt: number) => {
      if (!st.live) {
        st.live = true;
        scrs.forEach((el) => el.classList.add("is-tag"));
        ws.setAttribute("data-live", "");
      }

      // camera (clamped so the zoomed view never leaves the mockup)
      const [a, b, p] = seg(CAM, tt);
      const A = anchors[a.at];
      const B = anchors[b.at];
      const s = Math.exp(Math.log(a.s) + (Math.log(b.s) - Math.log(a.s)) * p);
      const mx = W / (2 * s);
      const my = H / (2 * s);
      const px = Math.min(W - mx, Math.max(mx, A.x + (B.x - A.x) * p));
      const py = Math.min(H - my, Math.max(my, A.y + (B.y - A.y) * p));
      const rx = a.rx + (b.rx - a.rx) * p;
      const ry = a.ry + (b.ry - a.ry) * p;
      cam.style.transform = `translate(${W / 2}px, ${H / 2}px) rotateX(${rx}deg) rotateY(${ry}deg) scale(${s}) translate(${-px}px, ${-py}px)`;

      // cursor (inside the camera, counter-scaled to stay a constant size)
      const [c0, c1, cp] = seg(CUR, tt);
      const C0 = anchors[c0.at];
      const C1 = anchors[c1.at];
      const x0 = C0.x + (c0.dx ?? 0);
      const y0 = C0.y + (c0.dy ?? 0);
      const x1 = C1.x + (c1.dx ?? 0);
      const y1 = C1.y + (c1.dy ?? 0);
      const clickAt = tt >= CLICK2 ? CLICK2 : tt >= CLICK1 ? CLICK1 : -9;
      const age = tt - clickAt;
      const press = age >= 0 && age < 0.18 ? 0.88 : 1;
      cur.style.transform = `translate(${x0 + (x1 - x0) * cp}px, ${y0 + (y1 - y0) * cp}px) scale(${(press / s).toFixed(4)})`;
      cur.style.setProperty("--ck", age >= 0 && age < 0.6 ? (age / 0.6).toFixed(3) : "1");
      cur.style.opacity = tt < 1.0 ? String(Math.max(0, Math.min(1, (tt - 0.5) / 0.4))) : tt > 12.0 ? String(Math.max(0, Math.min(1, (12.8 - tt) / 0.5))) : "1";

      // ---- AI panel ----
      const reset = tt >= RESET;
      const phase = reset || tt < CLICK1 ? 0 : tt < CLICK2 ? 1 : 2;
      if (st.text !== phase) {
        st.text = phase;
        const t = TEXT[phase];
        meP.innerHTML = t ? t.me : orig.me;
        replyP.innerHTML = t ? t.p : orig.p;
        replyS.innerHTML = t ? t.s : orig.s;
      }
      const pop = (tt >= CLICK1 && tt < CLICK1 + 0.5) || (tt >= CLICK2 && tt < CLICK2 + 0.5);
      if (st.pop !== pop) {
        st.pop = pop;
        flag(meP, "is-pop", pop);
      }
      const think = (tt >= CLICK1 && tt < CLICK1 + THINK) || (tt >= CLICK2 && tt < CLICK2 + THINK);
      if (st.think !== think) {
        st.think = think;
        if (think) ws.setAttribute("data-think", "");
        else ws.removeAttribute("data-think");
      }
      const hov = [tt >= 2.1 && tt < CLICK1, tt >= 7.6 && tt < CLICK2];
      const act = [phase === 1, phase === 2];
      for (let k = 0; k < 2; k++) {
        if (st.chipHover[k] !== hov[k]) {
          st.chipHover[k] = hov[k];
          flag(chips[2 + k], "is-hover", hov[k]);
        }
        if (st.chipActive[k] !== act[k]) {
          st.chipActive[k] = act[k];
          flag(chips[2 + k], "is-active", act[k]);
        }
      }
      const glow = (tt >= CLICK1 + THINK && tt < CLICK1 + THINK + 0.9) || (tt >= CLICK2 + THINK && tt < CLICK2 + THINK + 0.9);
      if (st.glow !== glow) {
        st.glow = glow;
        flag(view, "is-glow", glow);
      }

      // ---- sweep band ----
      let sx = -1;
      for (const sw of [SWEEP1, SWEEP2]) {
        if (tt >= sw.t && tt <= sw.t + sw.d) sx = ((tt - sw.t) / sw.d) * (canvasW + BAND);
      }
      const sOn = sx >= 0;
      if (sOn) sweep.style.transform = `translate3d(${(sx - BAND).toFixed(1)}px,0,0)`;
      if (st.sweepOn !== sOn) {
        st.sweepOn = sOn;
        sweep.style.opacity = sOn ? "1" : "0";
      }

      // ---- screens + layers ----
      scrs.forEach((el, i) => {
        const e = flipAt(SWEEP1, i);
        const c = flipAt(SWEEP2, i);
        const ed = tt >= e && !reset;
        const ct = tt >= c && !reset;
        const since = (t0: number) => tt >= t0 && tt < t0 + FLASH;
        const flash = since(e) || since(c) || since(RESET);
        // "Updated" tags: shown, hidden while a command runs, popped back in as the sweep passes
        const tag = !((tt >= CLICK1 && tt < e) || (tt >= CLICK2 && tt < c));
        const o = st.scr[i];
        if (o.ed !== ed) {
          o.ed = ed;
          flag(el, "ed", ed);
        }
        if (o.ct !== ct) {
          o.ct = ct;
          flag(el, "ct", ct);
        }
        if (o.flash !== flash) {
          o.flash = flash;
          flag(el, "is-flash", flash);
          flag(el, "is-swap", flash);
          if (st.ping[i] !== flash) {
            st.ping[i] = flash;
            flag(layers[i], "is-ping", flash);
          }
        }
        if (o.tag !== tag) {
          o.tag = tag;
          flag(el, "is-tag", tag);
        }
      });
    };

    const tick = (now: number) => {
      if (!running) return;
      const dt = Math.min(0.1, (now - last) / 1000);
      last = now;
      clock = (clock + dt) % LOOP;
      frame(clock);
      raf = requestAnimationFrame(tick);
    };
    const start = () => {
      if (running || !visible || document.hidden) return;
      running = true;
      measure();
      last = performance.now();
      raf = requestAnimationFrame(tick);
    };
    const stop = () => {
      running = false;
      cancelAnimationFrame(raf);
    };

    const io = new IntersectionObserver(
      ([e]) => {
        visible = e.isIntersecting;
        if (visible) start();
        else stop();
      },
      { threshold: 0.15 },
    );
    io.observe(ws);
    const vis = () => (document.hidden ? stop() : start());
    document.addEventListener("visibilitychange", vis);
    const ro = new ResizeObserver(() => running && measure());
    ro.observe(cam);
    document.fonts?.ready.then(() => running && measure());

    return () => {
      stop();
      io.disconnect();
      ro.disconnect();
      document.removeEventListener("visibilitychange", vis);
      cam.style.transform = "";
      ws.removeAttribute("data-live");
      ws.removeAttribute("data-think");
      meP.innerHTML = orig.me;
      replyP.innerHTML = orig.p;
      replyS.innerHTML = orig.s;
      scrs.forEach((el) => el.classList.remove("ed", "ct", "is-flash", "is-swap", "is-tag"));
      layers.forEach((el) => el.classList.remove("is-ping"));
      chips.forEach((el) => el.classList.remove("is-hover", "is-active"));
    };
  }, []);

  return (
    <div ref={cursorRef} className="tour__cursor" aria-hidden="true">
      <i className="tour__ripple" />
      <svg width="26" height="30" viewBox="0 0 26 30" fill="none">
        <path d="M3 2v22.5l6.2-5.6 4.4 9.6 4.3-2-4.3-9.2h8.5L3 2Z" fill="#fff" stroke="#111" strokeWidth="1.8" strokeLinejoin="round" />
      </svg>
    </div>
  );
}
