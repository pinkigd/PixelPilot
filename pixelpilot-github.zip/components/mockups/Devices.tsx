import type { CSSProperties } from "react";
import { cn } from "@/lib/cn";
import dBanff from "@/assets/rs-d-banff.jpg";
import dHero from "@/assets/rs-d-hero.jpg";
import dKyoto from "@/assets/rs-d-kyoto.jpg";
import dSantorini from "@/assets/rs-d-santorini.jpg";
import dSwiss from "@/assets/rs-d-swiss.jpg";
import mBan from "@/assets/rs-m-ban.jpg";
import mKyoto from "@/assets/rs-m-kyoto.png";
import mSantorini from "@/assets/rs-m-santorini.png";
import mSwiss from "@/assets/rs-m-swiss.png";
import tBan from "@/assets/rs-t-ban.jpg";
import tBanff from "@/assets/rs-t-banff.jpg";
import tKyoto from "@/assets/rs-t-kyoto.jpg";
import tSantorini from "@/assets/rs-t-santorini.jpg";
import tSwiss from "@/assets/rs-t-swiss.jpg";

type P = { className?: string; style?: CSSProperties };
type Img = { src: string; width: number; height: number };

/** photo crop that fills its (clipped / rounded) `.photo` box */
function Pic({ i }: { i: Img }) {
  // eslint-disable-next-line @next/next/no-img-element
  return <img src={i.src} width={i.width} height={i.height} alt="" draggable={false} style={{ display: "block", width: "100%", height: "100%", objectFit: "cover" }} />;
}

const Search = ({ size = 12, style }: { size?: number; style?: CSSProperties }) => (
  <svg width={size} height={size} viewBox="0 0 12 12" fill="none" aria-hidden="true" style={style}>
    <circle cx="7.4" cy="4.6" r="3.6" stroke="currentColor" strokeWidth="1.4" />
    <path d="M4.9 7.1 1.2 10.8" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
  </svg>
);

const Burger = ({ w = 13 }: { w?: number }) => (
  <svg width={w} height={w * 0.75} viewBox="0 0 12 9" fill="none" aria-hidden="true">
    <path d="M.8 1h10.4M.8 4.5h10.4M.8 8h10.4" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" />
  </svg>
);

const Arrow = ({ w = 12, sw = 1.4 }: { w?: number; sw?: number }) => (
  <svg width={w} height={w * 0.8} viewBox="0 0 12 10" fill="none" aria-hidden="true">
    <path d="M1 5h10M7 1l4 4-4 4" stroke="currentColor" strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

const Chev = () => (
  <svg width="4" height="7" viewBox="0 0 4 7" fill="none" aria-hidden="true">
    <path d="M.6.6 3.2 3.5.6 6.4" stroke="currentColor" strokeWidth="1" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

/* The three "Horizon" breakpoint mockups (Desktop 1440 / Tablet 768 / Mobile 390), shared by the landing
   "Responsive" stage and the Product "Every breakpoint" section (which just zooms them down). */

export function DesktopDevice({ className, style }: P) {
  return (
    <div className={cn("rm rm--d", className)} style={style}>
      <span className="logo">Horizon</span>
      <span className="nv t90" style={{ left: "220px" }}>
        Destinations
      </span>
      <span className="nv t90" style={{ left: "310px" }}>
        Experiences
      </span>
      <span className="nv t90" style={{ left: "400px" }}>
        About
      </span>
      <span style={{ left: "620px", top: "47px", lineHeight: 0 }}>
        <Search size={10} />
      </span>
      <span className="si">Sign in</span>
      <span className="burger burger--w">
        <Burger w={12} />
      </span>
      <span className="eb">TRAVEL FURTHER</span>
      <div className="hd">
        Discover
        <br />
        extraordinary
        <br />
        places
      </div>
      <span className="sb t80">Plan smarter. Travel deeper.</span>
      <i className="hero photo">
        <Pic i={dHero} />
      </i>
      <div className="srch">
        <span>{"⌕    Where do you want to go?"}</span>
        <b>
          <Arrow w={13} />
        </b>
      </div>
      <div className="dc" style={{ left: "156px" }}>
        <i className="photo">
          <Pic i={dSwiss} />
        </i>
        <b>Swiss Alps</b>
        <small>Switzerland</small>
      </div>
      <div className="dc" style={{ left: "296px" }}>
        <i className="photo">
          <Pic i={dKyoto} />
        </i>
        <b>Kyoto</b>
        <small>Japan</small>
      </div>
      <div className="dc" style={{ left: "436px" }}>
        <i className="photo">
          <Pic i={dSantorini} />
        </i>
        <b>Santorini</b>
        <small>Greece</small>
      </div>
      <div className="dc" style={{ left: "576px" }}>
        <i className="photo">
          <Pic i={dBanff} />
        </i>
        <b>Banff</b>
        <small>Canada</small>
      </div>
    </div>
  );
}

export function TabletDevice({ className, style }: P) {
  return (
    <div className={cn("rm rm--t", className)} style={style}>
      <span className="logo">Horizon</span>
      <span className="sc">
        <Search size={9} />
      </span>
      <span className="burger burger--g">
        <Burger w={10} />
      </span>
      <i className="ban photo">
        <Pic i={tBan} />
      </i>
      <span className="hd">Discover extraordinary places</span>
      <span className="sb t80">Plan smarter. Travel deeper.</span>
      <div className="srch">
        <span>{"⌕   Where do you want to go?"}</span>
        <b>
          <Arrow w={11} />
        </b>
      </div>
      <div className="dc" style={{ left: "26px", top: "282px" }}>
        <i className="photo">
          <Pic i={tSwiss} />
        </i>
        <b>Swiss Alps</b>
        <small>Switzerland</small>
      </div>
      <div className="dc" style={{ left: "172px", top: "282px" }}>
        <i className="photo">
          <Pic i={tKyoto} />
        </i>
        <b>Kyoto</b>
        <small>Japan</small>
      </div>
      <div className="dc" style={{ left: "26px", top: "386px" }}>
        <i className="photo">
          <Pic i={tSantorini} />
        </i>
        <b>Santorini</b>
        <small>Greece</small>
      </div>
      <div className="dc" style={{ left: "172px", top: "386px" }}>
        <i className="photo">
          <Pic i={tBanff} />
        </i>
        <b>Banff</b>
        <small>Canada</small>
      </div>
    </div>
  );
}

export function MobileDevice({ className, style }: P) {
  return (
    <div className={cn("rm rm--m", className)} style={style}>
      <i className="notch" />
      <span className="logo">Horizon</span>
      <span className="burger burger--g">
        <Burger w={10} />
      </span>
      <i className="ban photo">
        <Pic i={mBan} />
      </i>
      <div className="hd">
        Discover
        <br />
        extraordinary places
      </div>
      <span className="sb t80">Plan smarter. Travel deeper.</span>
      <div className="srch">
        <span>{"⌕  Where do you want to go?"}</span>
        <b>
          <Arrow w={9} sw={1.3} />
        </b>
      </div>
      <div className="row" style={{ top: "282px" }}>
        <i className="photo">
          <Pic i={mSwiss} />
        </i>
        <b>Swiss Alps</b>
        <small>Switzerland</small>
        <u>
          <Chev />
        </u>
      </div>
      <div className="row" style={{ top: "336px" }}>
        <i className="photo">
          <Pic i={mKyoto} />
        </i>
        <b>Kyoto</b>
        <small>Japan</small>
        <u>
          <Chev />
        </u>
      </div>
      <div className="row" style={{ top: "390px" }}>
        <i className="photo">
          <Pic i={mSantorini} />
        </i>
        <b>Santorini</b>
        <small>Greece</small>
        <u>
          <Chev />
        </u>
      </div>
      <div className="tabbar">
        <span style={{ left: "20px" }}>
          <svg width="10" height="9" viewBox="0 0 12 13" fill="none" aria-hidden="true">
            <path d="M1.1 5.9 6 1.3l4.9 4.6v6H1.1Z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round" />
          </svg>
          <small>Home</small>
        </span>
        <span style={{ left: "76px" }}>
          <Search size={7} />
          <small>Explore</small>
        </span>
        <span style={{ left: "132px" }}>
          <svg width="11" height="10" viewBox="0 0 16 15" fill="none" aria-hidden="true">
            <path
              d="M8 13.6S1 9.4 1 5.1C1 2.9 2.7 1.3 4.7 1.3c1.4 0 2.6.8 3.3 2 .7-1.2 1.9-2 3.3-2C13.3 1.3 15 2.9 15 5.1c0 4.3-7 8.5-7 8.5Z"
              stroke="currentColor"
              strokeWidth="1.4"
              strokeLinejoin="round"
            />
          </svg>
          <small>Saved</small>
        </span>
        <span style={{ left: "188px" }}>
          <svg width="9" height="9" viewBox="0 0 13 13" fill="none" aria-hidden="true">
            <circle cx="6.5" cy="6.5" r="5.8" stroke="currentColor" strokeWidth="1.3" />
            <circle cx="4.6" cy="6" r="1" fill="currentColor" />
            <circle cx="8.4" cy="6" r="1" fill="currentColor" />
          </svg>
          <small>Profile</small>
        </span>
      </div>
    </div>
  );
}
