export function DesignConnectors() {
  return (
    <>
      <svg className="dscon" style={{ left: "600px", top: "651px" }} width="114" height="224" viewBox="0 0 114 224" aria-hidden="true">
        <path d="M0 224H21V0H114" />
      </svg>
      <svg className="dscon" style={{ left: "320px", top: "899px" }} width="392" height="69" viewBox="0 0 392 69" aria-hidden="true">
        <path d="M0 0V69H392" />
      </svg>
    </>
  );
}
