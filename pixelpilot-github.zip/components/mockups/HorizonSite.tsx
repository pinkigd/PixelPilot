import avatar from "@/assets/ds-avatar.png";
import card1 from "@/assets/ds-card-1.jpg";
import card2 from "@/assets/ds-card-2.jpg";
import card3 from "@/assets/ds-card-3.jpg";
import hero from "@/assets/ds-hero.jpg";

/** the dashed "component selection" frame (1.5px stroke, 6 on / 3 off) in the primary token colour */
function DashRect({ w, h }: { w: number; h: number }) {
  return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`} aria-hidden="true">
      <rect x="0.75" y="0.75" width={w - 1.5} height={h - 1.5} fill="none" strokeWidth="1.3" strokeDasharray="5 3" strokeOpacity="0.85" style={{ stroke: "var(--ds-p, #ff7a59)" }} />
    </svg>
  );
}

export function HorizonSite() {
  return (
    <>
      <div className="fit horizon" aria-hidden="true">
        <span className="hz-serif" style={{ left: "46px", top: "30px", fontSize: "20px" }}>
          Horizon
        </span>
        <span style={{ left: "270px", top: "34px", fontSize: "12px", color: "rgba(15,23,42,.85)" }}>Destinations</span>
        <span style={{ left: "390px", top: "34px", fontSize: "12px", color: "rgba(15,23,42,.85)" }}>Experiences</span>
        <span style={{ left: "510px", top: "34px", fontSize: "12px", color: "rgba(15,23,42,.85)" }}>About</span>
        <svg style={{ left: "830px", top: "36px" }} width="11" height="11" viewBox="0 0 11 11" fill="none" stroke="#0f172a" strokeWidth="1.4" strokeLinecap="round">
          <circle cx="6.6" cy="4.4" r="3.2" />
          <path d="M4.3 6.7L1.2 9.8" />
        </svg>
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={avatar.src} width={30} height={30} alt="" style={{ left: "866px", top: "28px", width: "30px", height: "30px", borderRadius: "50%" }} />
        <svg style={{ left: "917px", top: "36px" }} width="13" height="10" viewBox="0 0 13 10" fill="none" stroke="#0f172a" strokeWidth="1.8" strokeLinecap="round">
          <path d="M1 1H12M1 5H12M1 9H12" />
        </svg>
        <span
          style={{ left: "46px", top: "98px", fontWeight: "500", fontSize: "10px", letterSpacing: "1.4px", color: "rgba(15,23,42,.6)" }}
        >
          EXPLORE A BRIGHTER TOMORROW
        </span>
        <span className="hz-serif" style={{ left: "46px", top: "124px", fontSize: "50px", lineHeight: "1", letterSpacing: "-1px" }}>
          Your next escape,
          <br />
          planned.
        </span>
        <span style={{ left: "46px", top: "248px", fontSize: "14px", lineHeight: "1.45", color: "rgba(15,23,42,.85)" }}>
          Discover extraordinary destinations, curated
          <br />
          for curious minds and better journeys.
        </span>
        <span className="hz-tag" style={{ left: "46px", top: "298px" }}>
          Button / Primary
        </span>
        <div className="hz-mark" style={{ left: "44px", top: "314px", width: "154px", height: "50px" }}>
          <DashRect w={154} h={50} />
        </div>
        <span
          style={{
            left: "48.5px",
            top: "318.5px",
            width: "142px",
            height: "38px",
            borderRadius: "999px",
            background: "var(--ds-p2, #f26a4b)",
            color: "#fff",
            fontWeight: "400",
            fontSize: "13px",
            display: "grid",
            placeItems: "center",
          }}
        >
          Book now
        </span>
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={hero.src} width={462} height={278} alt="" style={{ left: "460px", top: "82px", width: "462px", height: "278px", borderRadius: "12px", objectFit: "cover" }} />
        <span style={{ left: "46px", top: "410px", fontWeight: "500", fontSize: "18px" }}>Popular destinations</span>
        <span style={{ left: "838px", top: "414px", fontSize: "13px", color: "rgba(15,23,42,.85)", whiteSpace: "pre" }}>
          {"View all  →"}
        </span>
        <span className="hz-tag" style={{ left: "46px", top: "446px" }}>
          Card / Destination
        </span>
        <div className="hz-card" style={{ left: "46px", top: "462px" }}>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img className="hz-card-img" src={card1.src} width={288} height={140} alt="" />
          <b>Amalfi Coast</b>
          <span className="loc">⌾ Italy</span>
          <span className="rate">★ 4.9</span>
        </div>
        <div className="hz-mark" style={{ left: "42px", top: "458px", width: "296px", height: "204px" }}>
          <DashRect w={296} h={204} />
        </div>
        <div className="hz-card" style={{ left: "358px", top: "462px" }}>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img className="hz-card-img" src={card2.src} width={288} height={140} alt="" />
          <b>Banff National Park</b>
          <span className="loc">⌾ Canada</span>
          <span className="rate">★ 4.8</span>
        </div>
        <div className="hz-card" style={{ left: "670px", top: "462px" }}>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img className="hz-card-img" src={card3.src} width={288} height={140} alt="" />
          <b>Sahara Desert</b>
          <span className="loc">⌾ Morocco</span>
          <span className="rate">★ 4.7</span>
        </div>
      </div>
    </>
  );
}
