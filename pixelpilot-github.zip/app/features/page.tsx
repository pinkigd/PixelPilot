import type { Metadata } from "next";
import { CtaFooter } from "@/components/sections/CtaFooter";
import { Conversation } from "@/components/sections/features/Conversation";
import { DesignSystemFeature } from "@/components/sections/features/DesignSystemFeature";
import { Everything } from "@/components/sections/features/Everything";
import { FeaturesHero } from "@/components/sections/features/FeaturesHero";
import { Generate } from "@/components/sections/features/Generate";
import { Handoff } from "@/components/sections/features/Handoff";
import { ResponsiveFeature } from "@/components/sections/features/ResponsiveFeature";
import { VariationsFeature } from "@/components/sections/features/VariationsFeature";

export const metadata: Metadata = {
  title: "Features — PixelPilot",
  description:
    "Six features, one uninterrupted flow: generate, edit by conversation, stay on your design system, adapt to every breakpoint, explore variations and hand off.",
};

export default function FeaturesPage() {
  return (
    <main>
      <FeaturesHero />
      <Generate />
      <Conversation />
      <DesignSystemFeature />
      <ResponsiveFeature />
      <VariationsFeature />
      <Handoff />
      <Everything />
      <CtaFooter compact title={["Open a file and try it.", "The first screen is free."]} />
    </main>
  );
}
