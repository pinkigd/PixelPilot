import { CommandCenter } from "@/components/sections/CommandCenter";
import { CtaFooter } from "@/components/sections/CtaFooter";
import { DesignSystem } from "@/components/sections/DesignSystem";
import { Faq } from "@/components/sections/Faq";
import { Flow } from "@/components/sections/Flow";
import { Hero } from "@/components/sections/Hero";
import { Logos } from "@/components/sections/Logos";
import { Philosophy } from "@/components/sections/Philosophy";
import { Pricing } from "@/components/sections/Pricing";
import { Problem } from "@/components/sections/Problem";
import { Proof } from "@/components/sections/Proof";
import { Responsive } from "@/components/sections/Responsive";
import { Solution } from "@/components/sections/Solution";
import { Variations } from "@/components/sections/Variations";

export default function Page() {
  return (
    <main>
      <Hero />
      <Logos />
      <Problem />
      <Solution />
      <CommandCenter />
      <DesignSystem />
      <Flow />
      <Responsive />
      <Variations />
      <Proof />
      <Pricing />
      <Faq />
      <Philosophy />
      <CtaFooter />
    </main>
  );
}
