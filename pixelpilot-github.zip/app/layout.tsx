import type { Metadata, Viewport } from "next";
import { Scaler } from "@/components/ui/Scaler";
import "./globals.css";

export const metadata: Metadata = {
  title: "PixelPilot — Your AI copilot inside Figma",
  description: "Design faster. Think beyond pixels. Your AI copilot inside Figma — from prompt to polished UI.",
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#0b0a0a",
};

// Sets --k before first paint (same formula as <Scaler />) so 1100–1679px screens don't flash at the wrong scale.
const SET_K = `(function(){var r=document.documentElement,w=r.clientWidth;r.style.setProperty("--k",(w>=1100&&w<1680?(w-2)/1680:1).toFixed(4))})()`;

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: SET_K }} />
      </head>
      <body>
        <Scaler />
        {children}
      </body>
    </html>
  );
}
