import type { Metadata } from "next";
import { CtaFooter } from "@/components/sections/CtaFooter";
import { Breakpoints } from "@/components/sections/product/Breakpoints";
import { Capabilities } from "@/components/sections/product/Capabilities";
import { EditByConversation } from "@/components/sections/product/EditByConversation";
import { Enterprise } from "@/components/sections/product/Enterprise";
import { Included } from "@/components/sections/product/Included";
import { ProductHero } from "@/components/sections/product/ProductHero";

export const metadata: Metadata = {
  title: "Product — PixelPilot",
  description:
    "One copilot for every step of the work: generate, edit, adapt and hand off — without leaving your Figma file.",
};

export default function ProductPage() {
  return (
    <main>
      <ProductHero />
      <Capabilities />
      <EditByConversation />
      <Breakpoints />
      <Included />
      <Enterprise />
      <CtaFooter
        title={["See it on your own file.", "Start in two minutes."]}
      />
    </main>
  );
}
