import type { Metadata } from "next";
import { CtaFooter } from "@/components/sections/CtaFooter";
import { Faq } from "@/components/sections/Faq";
import { StatGrid } from "@/components/sections/Proof";
import { Eyebrow } from "@/components/ui/Eyebrow";
import { Dim, H2 } from "@/components/ui/H2";
import { Section } from "@/components/ui/Section";
import { Included } from "@/components/sections/product/Included";
import { InEveryPlan } from "@/components/sections/pricing/InEveryPlan";
import { PricingHero } from "@/components/sections/pricing/PricingHero";

export const metadata: Metadata = {
  title: "Pricing — PixelPilot",
  description:
    "Per editor, billed monthly or yearly. Starter is free; Pro and Team run inside Figma with no separate app.",
};

// NOTE: Figma only defines the answer to question 1; answers 2–6 are placeholder copy — replace with real content.
const BILLING_QAS = [
  {
    q: "How does per-editor billing work?",
    a: "You’re billed for editors who generate or edit with PixelPilot. Viewers and commenters are free, and you can reassign a seat any time.",
  },
  {
    q: "What happens if my team grows mid-month?",
    a: "New seats are added to your plan straight away and prorated for the rest of the billing cycle, so you only pay for the days they use.",
  },
  {
    q: "Can I switch between monthly and yearly?",
    a: "Yes, at any time from your billing settings. Moving to yearly applies the 20% saving from your next renewal.",
  },
  {
    q: "Do unused AI generations roll over?",
    a: "Starter generations reset at the start of each month and don’t roll over. Pro and Team have unlimited generations, so there’s nothing to track.",
  },
  {
    q: "What happens when my trial ends?",
    a: "You can continue on Pro, move to Starter, or cancel. Your files stay yours either way.",
  },
  {
    q: "Do you offer education or non-profit pricing?",
    a: "Yes. Students, educators and registered non-profits get Pro at a reduced rate — contact the team and we’ll set it up.",
  },
];

export default function PricingPage() {
  return (
    <main>
      <PricingHero />
      <Included
        id="compare"
        eyebrow="COMPARE PLANS"
        title={
          <>
            Compare <Dim className="inline">every feature.</Dim>
          </>
        }
        intro="Switch or cancel any time. Yearly billing saves 20% on Pro and Team."
      />
      <InEveryPlan />
      <Section id="results" inner="h-[891px] p-0 tablet:h-auto tablet:px-(--pad) tablet:pt-[88px] tablet:pb-20">
        <div className="absolute top-[140px] left-10 tablet:static">
          <Eyebrow className="flex">WHY TEAMS UPGRADE</Eyebrow>
          <H2 className="mt-[27px] tablet:mt-5">
            Pro pays for itself
            <Dim>in the first week.</Dim>
          </H2>
        </div>
        <StatGrid guides={false} className="absolute top-[400px] left-10 w-[1600px] tablet:static tablet:mt-10 tablet:w-full" />
      </Section>
      <Faq id="faq" qas={BILLING_QAS} title={["Billing questions,", "answered."]} accentGuide />
      <CtaFooter accentGuide="col" legalBar="pricing" title={["Try Pro free for 14 days.", "No card, no call."]} />
    </main>
  );
}
