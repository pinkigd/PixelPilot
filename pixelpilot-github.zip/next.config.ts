import type { NextConfig } from "next";

// `EXPORT=1 next build` → fully static site in ./out (relative asset paths, so it can be hosted in any folder)
const exporting = process.env.EXPORT === "1";

const nextConfig: NextConfig = {
  reactStrictMode: true,
  ...(exporting && { output: "export", assetPrefix: ".", distDir: ".next-export", images: { unoptimized: true } }),
};

export default nextConfig;
